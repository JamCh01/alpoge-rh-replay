// Lean compiler output
// Module: Development.AbelianVarietyTheory.Proofs.InertiaEigenvalues.EqTeichmullerOfFrobenius
// Imports: public import Init public meta import Init public import Mathlib public import Formalism.LocalRingCardinality.AdicCompletionLocal.LocTied public import Development.AbelianVarietyTheory.Definitions.NonGaloisDescent.ExistsOfLayers public import Development.AbelianVarietyTheory.Proofs.InertiaEigenvalues.ConstantCoeffTeichSub public import Development.AbelianVarietyTheory.Proofs.InertiaEigenvalues.AlgHomExtOfConstantCoeffZero public import Development.AbelianVarietyTheory.Proofs.InertiaEigenvalues.CyclotomicPowerSeriesAlgHomActionLawsStatement public import Development.AbelianVarietyTheory.Proofs.InertiaEigenvalues.IntegersCompleteDVR public import Development.AbelianVarietyTheory.Proofs.InertiaEigenvalues.ExistsIntegralCyclotomicChar public import Development.AbelianVarietyTheory.Proofs.InertiaEigenvalues.TiltWittEqZeroOfPrimeMulEqZero public import Development.AbelianVarietyTheory.Proofs.IwasawaDecomposition.RootOfUnityPrimeToTeichmullerLift
#include <lean/lean.h>
#if defined(__clang__)
#pragma clang diagnostic ignored "-Wunused-parameter"
#pragma clang diagnostic ignored "-Wunused-label"
#elif defined(__GNUC__) && !defined(__CLANG__)
#pragma GCC diagnostic ignored "-Wunused-parameter"
#pragma GCC diagnostic ignored "-Wunused-label"
#pragma GCC diagnostic ignored "-Wunused-but-set-variable"
#endif
#ifdef __cplusplus
extern "C" {
#endif
lean_object* lp_mathlib_ZMod_commRing(lean_object*);
lean_object* lp_mathlib_Ring_toAddGroupWithOne___redArg(lean_object*);
lean_object* lp_mathlib_AddGroupWithOne_toAddGroup___redArg(lean_object*);
lean_object* lp_mathlib_AlgHom_pi___redArg(lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_HWL_IoLayer_shift___redArg___lam__0(lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_HWL_IoLayer_shift___redArg(lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_HWL_IoLayer_shift(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_HWL_IoLayer_shift___boxed(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_HWL_IoLayer_shift___redArg___lam__0(lean_object* v_toSub_1_, lean_object* v_toOne_2_, lean_object* v_i_3_, lean_object* v___y_4_){
_start:
{
lean_object* v___x_5_; lean_object* v___x_6_; 
v___x_5_ = lean_apply_2(v_toSub_1_, v_i_3_, v_toOne_2_);
v___x_6_ = lean_apply_1(v___y_4_, v___x_5_);
return v___x_6_;
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_HWL_IoLayer_shift___redArg(lean_object* v_n_7_){
_start:
{
lean_object* v___x_8_; lean_object* v___x_9_; lean_object* v___x_10_; lean_object* v_toAddMonoidWithOne_11_; lean_object* v_toSub_12_; lean_object* v_toOne_13_; lean_object* v___f_14_; lean_object* v___x_15_; 
v___x_8_ = lp_mathlib_ZMod_commRing(v_n_7_);
v___x_9_ = lp_mathlib_Ring_toAddGroupWithOne___redArg(v___x_8_);
v___x_10_ = lp_mathlib_AddGroupWithOne_toAddGroup___redArg(v___x_9_);
v_toAddMonoidWithOne_11_ = lean_ctor_get(v___x_9_, 1);
lean_inc_ref(v_toAddMonoidWithOne_11_);
lean_dec_ref(v___x_9_);
v_toSub_12_ = lean_ctor_get(v___x_10_, 2);
lean_inc(v_toSub_12_);
lean_dec_ref(v___x_10_);
v_toOne_13_ = lean_ctor_get(v_toAddMonoidWithOne_11_, 2);
lean_inc(v_toOne_13_);
lean_dec_ref(v_toAddMonoidWithOne_11_);
v___f_14_ = lean_alloc_closure((void*)(lp_tree_GlobalTheory_HWL_IoLayer_shift___redArg___lam__0), 4, 2);
lean_closure_set(v___f_14_, 0, v_toSub_12_);
lean_closure_set(v___f_14_, 1, v_toOne_13_);
v___x_15_ = lp_mathlib_AlgHom_pi___redArg(v___f_14_);
return v___x_15_;
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_HWL_IoLayer_shift(lean_object* v_O_16_, lean_object* v_inst_17_, lean_object* v_n_18_){
_start:
{
lean_object* v___x_19_; 
v___x_19_ = lp_tree_GlobalTheory_HWL_IoLayer_shift___redArg(v_n_18_);
return v___x_19_;
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_HWL_IoLayer_shift___boxed(lean_object* v_O_20_, lean_object* v_inst_21_, lean_object* v_n_22_){
_start:
{
lean_object* v_res_23_; 
v_res_23_ = lp_tree_GlobalTheory_HWL_IoLayer_shift(v_O_20_, v_inst_21_, v_n_22_);
lean_dec_ref(v_inst_21_);
return v_res_23_;
}
}
lean_object* initialize_Init(uint8_t builtin);
lean_object* initialize_Init(uint8_t builtin);
lean_object* initialize_mathlib_Mathlib(uint8_t builtin);
lean_object* initialize_tree_Formalism_LocalRingCardinality_AdicCompletionLocal_LocTied(uint8_t builtin);
lean_object* initialize_tree_Development_AbelianVarietyTheory_Definitions_NonGaloisDescent_ExistsOfLayers(uint8_t builtin);
lean_object* initialize_tree_Development_AbelianVarietyTheory_Proofs_InertiaEigenvalues_ConstantCoeffTeichSub(uint8_t builtin);
lean_object* initialize_tree_Development_AbelianVarietyTheory_Proofs_InertiaEigenvalues_AlgHomExtOfConstantCoeffZero(uint8_t builtin);
lean_object* initialize_tree_Development_AbelianVarietyTheory_Proofs_InertiaEigenvalues_CyclotomicPowerSeriesAlgHomActionLawsStatement(uint8_t builtin);
lean_object* initialize_tree_Development_AbelianVarietyTheory_Proofs_InertiaEigenvalues_IntegersCompleteDVR(uint8_t builtin);
lean_object* initialize_tree_Development_AbelianVarietyTheory_Proofs_InertiaEigenvalues_ExistsIntegralCyclotomicChar(uint8_t builtin);
lean_object* initialize_tree_Development_AbelianVarietyTheory_Proofs_InertiaEigenvalues_TiltWittEqZeroOfPrimeMulEqZero(uint8_t builtin);
lean_object* initialize_tree_Development_AbelianVarietyTheory_Proofs_IwasawaDecomposition_RootOfUnityPrimeToTeichmullerLift(uint8_t builtin);
static bool _G_initialized = false;
LEAN_EXPORT lean_object* initialize_tree_Development_AbelianVarietyTheory_Proofs_InertiaEigenvalues_EqTeichmullerOfFrobenius(uint8_t builtin) {
lean_object * res;
if (_G_initialized) return lean_io_result_mk_ok(lean_box(0));
_G_initialized = true;
res = initialize_Init(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_Init(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_mathlib_Mathlib(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_Formalism_LocalRingCardinality_AdicCompletionLocal_LocTied(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_Development_AbelianVarietyTheory_Definitions_NonGaloisDescent_ExistsOfLayers(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_Development_AbelianVarietyTheory_Proofs_InertiaEigenvalues_ConstantCoeffTeichSub(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_Development_AbelianVarietyTheory_Proofs_InertiaEigenvalues_AlgHomExtOfConstantCoeffZero(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_Development_AbelianVarietyTheory_Proofs_InertiaEigenvalues_CyclotomicPowerSeriesAlgHomActionLawsStatement(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_Development_AbelianVarietyTheory_Proofs_InertiaEigenvalues_IntegersCompleteDVR(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_Development_AbelianVarietyTheory_Proofs_InertiaEigenvalues_ExistsIntegralCyclotomicChar(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_Development_AbelianVarietyTheory_Proofs_InertiaEigenvalues_TiltWittEqZeroOfPrimeMulEqZero(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_Development_AbelianVarietyTheory_Proofs_IwasawaDecomposition_RootOfUnityPrimeToTeichmullerLift(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
return lean_io_result_mk_ok(lean_box(0));
}
#ifdef __cplusplus
}
#endif
