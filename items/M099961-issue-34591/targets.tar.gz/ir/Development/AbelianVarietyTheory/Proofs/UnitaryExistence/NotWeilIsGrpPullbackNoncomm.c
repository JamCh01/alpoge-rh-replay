// Lean compiler output
// Module: Development.AbelianVarietyTheory.Proofs.UnitaryExistence.NotWeilIsGrpPullbackNoncomm
// Imports: public import Init public meta import Init public import Mathlib public import Development.AbelianVarietyTheory.Proofs.ModuliProofs.WeilIsGrpPullbackOfCommute public import ReciprocityTheory.ReductiveGroups.ArithmeticGeometry.BirationalGeometry.ToroidalCompactification.IsHolPeriods public import ReciprocityTheory.ReductiveGroups.ArithmeticGeometry.BirationalGeometry.ToroidalCompactification.HeckeKer public import ReciprocityTheory.ReductiveGroups.ArithmeticGeometry.BirationalGeometry.ToroidalCompactification.FlagBasis public import ReciprocityTheory.ReductiveGroups.ArithmeticGeometry.BirationalGeometry.ToroidalCompactification.SabComp public import ReciprocityTheory.ReductiveGroups.ArithmeticGeometry.BirationalGeometry.ToroidalCompactification.EigLatBasis public import ReciprocityTheory.ReductiveGroups.ArithmeticGeometry.BirationalGeometry.ToroidalCompactification.BCTools public import ReciprocityTheory.ReductiveGroups.ArithmeticGeometry.ExtensionDescent.SecBaseChangeAnySt public import ReciprocityTheory.ReductiveGroups.ArithmeticGeometry.SemiabelianSchemes.Biextensions.CubicalExtendsSt
#include <lean/lean.h>
#if defined(__clang__)
#pragma clang diagnostic ignored "-Wunused-parameter"
#pragma clang diagnostic ignored "-Wunused-label"
#elif defined(__GNUC__) && !defined(__CLANG__)
#pragma GCC diagnostic ignored "-Wunused-parameter"
#pragma GCC diagnostic ignored "-Wunused-label"
#pragma GCC diagnostic ignored "-Wunused-but-set-variable"
#endif
#ifdef __cplusplus
extern "C" {
#endif
lean_object* lp_mathlib_instDistribOfSemiring___redArg(lean_object*);
lean_object* lp_mathlib_Ring_toAddCommGroup___redArg(lean_object*);
lean_object* lp_mathlib_SubNegZeroMonoid_toNegZeroClass___redArg(lean_object*);
lean_object* lp_mathlib_instMulZeroClassOfSemiring___redArg(lean_object*);
lean_object* lp_mathlib_npowBinRecAuto___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
lean_object* lp_mathlib_DivInvMonoid_div_x27___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
lean_object* l_npowRec___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
lean_object* lp_mathlib_zpowRec___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
lean_object* lp_mathlib_CommRing_toNonUnitalCommRing___redArg(lean_object*);
lean_object* lp_mathlib_Monoid_toMulOneClass___redArg(lean_object*);
lean_object* lp_mathlib_NonUnitalNonAssocRing_toHasDistribNeg___redArg(lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_WeilNoncomm_oneChart___lam__0(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_WeilNoncomm_oneChart___lam__1(lean_object*);
static const lean_closure_object lp_tree_GlobalTheory_WeilNoncomm_oneChart___closed__0_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_closure_object) + sizeof(void*)*0, .m_other = 0, .m_tag = 245}, .m_fun = (void*)lp_tree_GlobalTheory_WeilNoncomm_oneChart___lam__1, .m_arity = 1, .m_num_fixed = 0, .m_objs = {} };
static const lean_object* lp_tree_GlobalTheory_WeilNoncomm_oneChart___closed__0 = (const lean_object*)&lp_tree_GlobalTheory_WeilNoncomm_oneChart___closed__0_value;
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_WeilNoncomm_oneChart(lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_WeilNoncomm_sgn___redArg(lean_object*, uint8_t);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_WeilNoncomm_sgn___redArg___boxed(lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_WeilNoncomm_sgn(lean_object*, lean_object*, uint8_t);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_WeilNoncomm_sgn___boxed(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_WeilNoncomm_sgn___at___00GlobalTheory_WeilNoncomm_twoCharts_spec__0(lean_object*, uint8_t);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_WeilNoncomm_sgn___at___00GlobalTheory_WeilNoncomm_twoCharts_spec__0___boxed(lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_WeilNoncomm_twoCharts___lam__0(lean_object*, uint8_t, uint8_t);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_WeilNoncomm_twoCharts___lam__0___boxed(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_WeilNoncomm_twoCharts___lam__1(uint8_t);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_WeilNoncomm_twoCharts___lam__1___boxed(lean_object*);
static const lean_closure_object lp_tree_GlobalTheory_WeilNoncomm_twoCharts___closed__0_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_closure_object) + sizeof(void*)*0, .m_other = 0, .m_tag = 245}, .m_fun = (void*)lp_tree_GlobalTheory_WeilNoncomm_twoCharts___lam__1___boxed, .m_arity = 1, .m_num_fixed = 0, .m_objs = {} };
static const lean_object* lp_tree_GlobalTheory_WeilNoncomm_twoCharts___closed__0 = (const lean_object*)&lp_tree_GlobalTheory_WeilNoncomm_twoCharts___closed__0_value;
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_WeilNoncomm_twoCharts(lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_WeilNoncomm_Heis_instMul___redArg___lam__0(lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_WeilNoncomm_Heis_instMul___redArg(lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_WeilNoncomm_Heis_instMul(lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_WeilNoncomm_Heis_instOne___redArg(lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_WeilNoncomm_Heis_instOne(lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_WeilNoncomm_Heis_instInv___redArg___lam__0(lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_WeilNoncomm_Heis_instInv___redArg(lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_WeilNoncomm_Heis_instInv(lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_WeilNoncomm_Heis_instGroup___redArg(lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_WeilNoncomm_Heis_instGroup(lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_WeilNoncomm_Heis_map___redArg___lam__0(lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_WeilNoncomm_Heis_map___redArg(lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_WeilNoncomm_Heis_map(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_WeilNoncomm_Heis_map___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_WeilNoncomm_Heis_map___at___00GlobalTheory_WeilNoncomm_heisFunctor_spec__0(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_WeilNoncomm_Heis_map___at___00GlobalTheory_WeilNoncomm_heisFunctor_spec__0___boxed(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_WeilNoncomm_heisFunctor___lam__0(lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_WeilNoncomm_heisFunctor___lam__0___boxed(lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_WeilNoncomm_heisFunctor___lam__1(lean_object*);
static const lean_closure_object lp_tree_GlobalTheory_WeilNoncomm_heisFunctor___closed__0_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_closure_object) + sizeof(void*)*0, .m_other = 0, .m_tag = 245}, .m_fun = (void*)lp_tree_GlobalTheory_WeilNoncomm_heisFunctor___lam__0___boxed, .m_arity = 4, .m_num_fixed = 0, .m_objs = {} };
static const lean_object* lp_tree_GlobalTheory_WeilNoncomm_heisFunctor___closed__0 = (const lean_object*)&lp_tree_GlobalTheory_WeilNoncomm_heisFunctor___closed__0_value;
static const lean_closure_object lp_tree_GlobalTheory_WeilNoncomm_heisFunctor___closed__1_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_closure_object) + sizeof(void*)*0, .m_other = 0, .m_tag = 245}, .m_fun = (void*)lp_tree_GlobalTheory_WeilNoncomm_heisFunctor___lam__1, .m_arity = 1, .m_num_fixed = 0, .m_objs = {} };
static const lean_object* lp_tree_GlobalTheory_WeilNoncomm_heisFunctor___closed__1 = (const lean_object*)&lp_tree_GlobalTheory_WeilNoncomm_heisFunctor___closed__1_value;
static const lean_ctor_object lp_tree_GlobalTheory_WeilNoncomm_heisFunctor___closed__2_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 0, .m_other = 2, .m_tag = 0}, .m_objs = {((lean_object*)&lp_tree_GlobalTheory_WeilNoncomm_heisFunctor___closed__1_value),((lean_object*)&lp_tree_GlobalTheory_WeilNoncomm_heisFunctor___closed__0_value)}};
static const lean_object* lp_tree_GlobalTheory_WeilNoncomm_heisFunctor___closed__2 = (const lean_object*)&lp_tree_GlobalTheory_WeilNoncomm_heisFunctor___closed__2_value;
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_WeilNoncomm_heisFunctor(lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_WeilNoncomm_heisFunctor___boxed(lean_object*);
LEAN_EXPORT lean_object* lp_tree_MonoidHom_mk_x27___at___00GlobalTheory_WeilNoncomm_Heis_map___at___00GlobalTheory_WeilNoncomm_heisFunctor_spec__0_spec__0___redArg(lean_object*);
LEAN_EXPORT lean_object* lp_tree_MonoidHom_mk_x27___at___00GlobalTheory_WeilNoncomm_Heis_map___at___00GlobalTheory_WeilNoncomm_heisFunctor_spec__0_spec__0___redArg___boxed(lean_object*);
LEAN_EXPORT lean_object* lp_tree_MonoidHom_mk_x27___at___00GlobalTheory_WeilNoncomm_Heis_map___at___00GlobalTheory_WeilNoncomm_heisFunctor_spec__0_spec__0(lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_MonoidHom_mk_x27___at___00GlobalTheory_WeilNoncomm_Heis_map___at___00GlobalTheory_WeilNoncomm_heisFunctor_spec__0_spec__0___boxed(lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_WeilNoncomm_oneChart___lam__0(lean_object* v_X_1_, lean_object* v_x_2_, lean_object* v_x_3_){
_start:
{
lean_object* v_presheaf_4_; lean_object* v_obj_5_; lean_object* v___x_6_; lean_object* v___x_7_; lean_object* v_toSemiring_8_; lean_object* v_toMonoid_9_; lean_object* v___x_10_; lean_object* v_toOne_11_; lean_object* v___x_13_; uint8_t v_isShared_14_; uint8_t v_isSharedCheck_18_; 
v_presheaf_4_ = lean_ctor_get(v_X_1_, 1);
lean_inc_ref(v_presheaf_4_);
lean_dec_ref(v_X_1_);
v_obj_5_ = lean_ctor_get(v_presheaf_4_, 0);
lean_inc(v_obj_5_);
lean_dec_ref(v_presheaf_4_);
v___x_6_ = lean_box(0);
v___x_7_ = lean_apply_1(v_obj_5_, v___x_6_);
v_toSemiring_8_ = lean_ctor_get(v___x_7_, 0);
lean_inc_ref(v_toSemiring_8_);
lean_dec_ref(v___x_7_);
v_toMonoid_9_ = lean_ctor_get(v_toSemiring_8_, 1);
lean_inc_ref(v_toMonoid_9_);
lean_dec_ref(v_toSemiring_8_);
v___x_10_ = lp_mathlib_Monoid_toMulOneClass___redArg(v_toMonoid_9_);
lean_dec_ref(v_toMonoid_9_);
v_toOne_11_ = lean_ctor_get(v___x_10_, 0);
v_isSharedCheck_18_ = !lean_is_exclusive(v___x_10_);
if (v_isSharedCheck_18_ == 0)
{
lean_object* v_unused_19_; 
v_unused_19_ = lean_ctor_get(v___x_10_, 1);
lean_dec(v_unused_19_);
v___x_13_ = v___x_10_;
v_isShared_14_ = v_isSharedCheck_18_;
goto v_resetjp_12_;
}
else
{
lean_inc(v_toOne_11_);
lean_dec(v___x_10_);
v___x_13_ = lean_box(0);
v_isShared_14_ = v_isSharedCheck_18_;
goto v_resetjp_12_;
}
v_resetjp_12_:
{
lean_object* v___x_16_; 
lean_inc(v_toOne_11_);
if (v_isShared_14_ == 0)
{
lean_ctor_set(v___x_13_, 1, v_toOne_11_);
v___x_16_ = v___x_13_;
goto v_reusejp_15_;
}
else
{
lean_object* v_reuseFailAlloc_17_; 
v_reuseFailAlloc_17_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_17_, 0, v_toOne_11_);
lean_ctor_set(v_reuseFailAlloc_17_, 1, v_toOne_11_);
v___x_16_ = v_reuseFailAlloc_17_;
goto v_reusejp_15_;
}
v_reusejp_15_:
{
return v___x_16_;
}
}
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_WeilNoncomm_oneChart___lam__1(lean_object* v_x_20_){
_start:
{
lean_object* v___x_21_; 
v___x_21_ = lean_box(0);
return v___x_21_;
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_WeilNoncomm_oneChart(lean_object* v_X_23_){
_start:
{
lean_object* v___f_24_; lean_object* v___f_25_; lean_object* v___x_26_; 
v___f_24_ = lean_alloc_closure((void*)(lp_tree_GlobalTheory_WeilNoncomm_oneChart___lam__0), 3, 1);
lean_closure_set(v___f_24_, 0, v_X_23_);
v___f_25_ = ((lean_object*)(lp_tree_GlobalTheory_WeilNoncomm_oneChart___closed__0));
v___x_26_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_26_, 0, v___f_25_);
lean_ctor_set(v___x_26_, 1, v___f_24_);
return v___x_26_;
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_WeilNoncomm_sgn___redArg(lean_object* v_inst_27_, uint8_t v_b_28_){
_start:
{
lean_object* v_toSemiring_29_; lean_object* v_toMonoid_30_; lean_object* v___x_31_; 
v_toSemiring_29_ = lean_ctor_get(v_inst_27_, 0);
v_toMonoid_30_ = lean_ctor_get(v_toSemiring_29_, 1);
v___x_31_ = lp_mathlib_CommRing_toNonUnitalCommRing___redArg(v_inst_27_);
if (v_b_28_ == 0)
{
lean_object* v___x_32_; lean_object* v_toOne_33_; lean_object* v___x_35_; uint8_t v_isShared_36_; uint8_t v_isSharedCheck_40_; 
lean_dec_ref(v___x_31_);
v___x_32_ = lp_mathlib_Monoid_toMulOneClass___redArg(v_toMonoid_30_);
v_toOne_33_ = lean_ctor_get(v___x_32_, 0);
v_isSharedCheck_40_ = !lean_is_exclusive(v___x_32_);
if (v_isSharedCheck_40_ == 0)
{
lean_object* v_unused_41_; 
v_unused_41_ = lean_ctor_get(v___x_32_, 1);
lean_dec(v_unused_41_);
v___x_35_ = v___x_32_;
v_isShared_36_ = v_isSharedCheck_40_;
goto v_resetjp_34_;
}
else
{
lean_inc(v_toOne_33_);
lean_dec(v___x_32_);
v___x_35_ = lean_box(0);
v_isShared_36_ = v_isSharedCheck_40_;
goto v_resetjp_34_;
}
v_resetjp_34_:
{
lean_object* v___x_38_; 
lean_inc(v_toOne_33_);
if (v_isShared_36_ == 0)
{
lean_ctor_set(v___x_35_, 1, v_toOne_33_);
v___x_38_ = v___x_35_;
goto v_reusejp_37_;
}
else
{
lean_object* v_reuseFailAlloc_39_; 
v_reuseFailAlloc_39_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_39_, 0, v_toOne_33_);
lean_ctor_set(v_reuseFailAlloc_39_, 1, v_toOne_33_);
v___x_38_ = v_reuseFailAlloc_39_;
goto v_reusejp_37_;
}
v_reusejp_37_:
{
return v___x_38_;
}
}
}
else
{
lean_object* v___x_42_; lean_object* v_toOne_43_; lean_object* v___x_45_; uint8_t v_isShared_46_; uint8_t v_isSharedCheck_52_; 
v___x_42_ = lp_mathlib_Monoid_toMulOneClass___redArg(v_toMonoid_30_);
v_toOne_43_ = lean_ctor_get(v___x_42_, 0);
v_isSharedCheck_52_ = !lean_is_exclusive(v___x_42_);
if (v_isSharedCheck_52_ == 0)
{
lean_object* v_unused_53_; 
v_unused_53_ = lean_ctor_get(v___x_42_, 1);
lean_dec(v_unused_53_);
v___x_45_ = v___x_42_;
v_isShared_46_ = v_isSharedCheck_52_;
goto v_resetjp_44_;
}
else
{
lean_inc(v_toOne_43_);
lean_dec(v___x_42_);
v___x_45_ = lean_box(0);
v_isShared_46_ = v_isSharedCheck_52_;
goto v_resetjp_44_;
}
v_resetjp_44_:
{
lean_object* v___x_103__overap_47_; lean_object* v___x_48_; lean_object* v___x_50_; 
v___x_103__overap_47_ = lp_mathlib_NonUnitalNonAssocRing_toHasDistribNeg___redArg(v___x_31_);
lean_dec_ref(v___x_31_);
v___x_48_ = lean_apply_1(v___x_103__overap_47_, v_toOne_43_);
lean_inc(v___x_48_);
if (v_isShared_46_ == 0)
{
lean_ctor_set(v___x_45_, 1, v___x_48_);
lean_ctor_set(v___x_45_, 0, v___x_48_);
v___x_50_ = v___x_45_;
goto v_reusejp_49_;
}
else
{
lean_object* v_reuseFailAlloc_51_; 
v_reuseFailAlloc_51_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_51_, 0, v___x_48_);
lean_ctor_set(v_reuseFailAlloc_51_, 1, v___x_48_);
v___x_50_ = v_reuseFailAlloc_51_;
goto v_reusejp_49_;
}
v_reusejp_49_:
{
return v___x_50_;
}
}
}
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_WeilNoncomm_sgn___redArg___boxed(lean_object* v_inst_54_, lean_object* v_b_55_){
_start:
{
uint8_t v_b_boxed_56_; lean_object* v_res_57_; 
v_b_boxed_56_ = lean_unbox(v_b_55_);
v_res_57_ = lp_tree_GlobalTheory_WeilNoncomm_sgn___redArg(v_inst_54_, v_b_boxed_56_);
lean_dec_ref(v_inst_54_);
return v_res_57_;
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_WeilNoncomm_sgn(lean_object* v_R_58_, lean_object* v_inst_59_, uint8_t v_b_60_){
_start:
{
lean_object* v___x_61_; 
v___x_61_ = lp_tree_GlobalTheory_WeilNoncomm_sgn___redArg(v_inst_59_, v_b_60_);
return v___x_61_;
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_WeilNoncomm_sgn___boxed(lean_object* v_R_62_, lean_object* v_inst_63_, lean_object* v_b_64_){
_start:
{
uint8_t v_b_boxed_65_; lean_object* v_res_66_; 
v_b_boxed_65_ = lean_unbox(v_b_64_);
v_res_66_ = lp_tree_GlobalTheory_WeilNoncomm_sgn(v_R_62_, v_inst_63_, v_b_boxed_65_);
lean_dec_ref(v_inst_63_);
return v_res_66_;
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_WeilNoncomm_sgn___at___00GlobalTheory_WeilNoncomm_twoCharts_spec__0(lean_object* v___x_67_, uint8_t v_b_68_){
_start:
{
lean_object* v_toSemiring_69_; lean_object* v_toMonoid_70_; lean_object* v___x_71_; 
v_toSemiring_69_ = lean_ctor_get(v___x_67_, 0);
v_toMonoid_70_ = lean_ctor_get(v_toSemiring_69_, 1);
v___x_71_ = lp_mathlib_CommRing_toNonUnitalCommRing___redArg(v___x_67_);
if (v_b_68_ == 0)
{
lean_object* v___x_72_; lean_object* v_toOne_73_; lean_object* v___x_75_; uint8_t v_isShared_76_; uint8_t v_isSharedCheck_80_; 
lean_dec_ref(v___x_71_);
v___x_72_ = lp_mathlib_Monoid_toMulOneClass___redArg(v_toMonoid_70_);
v_toOne_73_ = lean_ctor_get(v___x_72_, 0);
v_isSharedCheck_80_ = !lean_is_exclusive(v___x_72_);
if (v_isSharedCheck_80_ == 0)
{
lean_object* v_unused_81_; 
v_unused_81_ = lean_ctor_get(v___x_72_, 1);
lean_dec(v_unused_81_);
v___x_75_ = v___x_72_;
v_isShared_76_ = v_isSharedCheck_80_;
goto v_resetjp_74_;
}
else
{
lean_inc(v_toOne_73_);
lean_dec(v___x_72_);
v___x_75_ = lean_box(0);
v_isShared_76_ = v_isSharedCheck_80_;
goto v_resetjp_74_;
}
v_resetjp_74_:
{
lean_object* v___x_78_; 
lean_inc(v_toOne_73_);
if (v_isShared_76_ == 0)
{
lean_ctor_set(v___x_75_, 1, v_toOne_73_);
v___x_78_ = v___x_75_;
goto v_reusejp_77_;
}
else
{
lean_object* v_reuseFailAlloc_79_; 
v_reuseFailAlloc_79_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_79_, 0, v_toOne_73_);
lean_ctor_set(v_reuseFailAlloc_79_, 1, v_toOne_73_);
v___x_78_ = v_reuseFailAlloc_79_;
goto v_reusejp_77_;
}
v_reusejp_77_:
{
return v___x_78_;
}
}
}
else
{
lean_object* v___x_82_; lean_object* v_toOne_83_; lean_object* v___x_85_; uint8_t v_isShared_86_; uint8_t v_isSharedCheck_92_; 
v___x_82_ = lp_mathlib_Monoid_toMulOneClass___redArg(v_toMonoid_70_);
v_toOne_83_ = lean_ctor_get(v___x_82_, 0);
v_isSharedCheck_92_ = !lean_is_exclusive(v___x_82_);
if (v_isSharedCheck_92_ == 0)
{
lean_object* v_unused_93_; 
v_unused_93_ = lean_ctor_get(v___x_82_, 1);
lean_dec(v_unused_93_);
v___x_85_ = v___x_82_;
v_isShared_86_ = v_isSharedCheck_92_;
goto v_resetjp_84_;
}
else
{
lean_inc(v_toOne_83_);
lean_dec(v___x_82_);
v___x_85_ = lean_box(0);
v_isShared_86_ = v_isSharedCheck_92_;
goto v_resetjp_84_;
}
v_resetjp_84_:
{
lean_object* v___x_195__overap_87_; lean_object* v___x_88_; lean_object* v___x_90_; 
v___x_195__overap_87_ = lp_mathlib_NonUnitalNonAssocRing_toHasDistribNeg___redArg(v___x_71_);
lean_dec_ref(v___x_71_);
v___x_88_ = lean_apply_1(v___x_195__overap_87_, v_toOne_83_);
lean_inc(v___x_88_);
if (v_isShared_86_ == 0)
{
lean_ctor_set(v___x_85_, 1, v___x_88_);
lean_ctor_set(v___x_85_, 0, v___x_88_);
v___x_90_ = v___x_85_;
goto v_reusejp_89_;
}
else
{
lean_object* v_reuseFailAlloc_91_; 
v_reuseFailAlloc_91_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_91_, 0, v___x_88_);
lean_ctor_set(v_reuseFailAlloc_91_, 1, v___x_88_);
v___x_90_ = v_reuseFailAlloc_91_;
goto v_reusejp_89_;
}
v_reusejp_89_:
{
return v___x_90_;
}
}
}
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_WeilNoncomm_sgn___at___00GlobalTheory_WeilNoncomm_twoCharts_spec__0___boxed(lean_object* v___x_94_, lean_object* v_b_95_){
_start:
{
uint8_t v_b_boxed_96_; lean_object* v_res_97_; 
v_b_boxed_96_ = lean_unbox(v_b_95_);
v_res_97_ = lp_tree_GlobalTheory_WeilNoncomm_sgn___at___00GlobalTheory_WeilNoncomm_twoCharts_spec__0(v___x_94_, v_b_boxed_96_);
lean_dec_ref(v___x_94_);
return v_res_97_;
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_WeilNoncomm_twoCharts___lam__0(lean_object* v_X_98_, uint8_t v_i_99_, uint8_t v_j_100_){
_start:
{
lean_object* v_presheaf_101_; lean_object* v_obj_102_; lean_object* v___x_103_; lean_object* v___x_104_; 
v_presheaf_101_ = lean_ctor_get(v_X_98_, 1);
lean_inc_ref(v_presheaf_101_);
lean_dec_ref(v_X_98_);
v_obj_102_ = lean_ctor_get(v_presheaf_101_, 0);
lean_inc(v_obj_102_);
lean_dec_ref(v_presheaf_101_);
v___x_103_ = lean_box(0);
v___x_104_ = lean_apply_1(v_obj_102_, v___x_103_);
if (v_i_99_ == 0)
{
if (v_j_100_ == 0)
{
goto v___jp_108_;
}
else
{
goto v___jp_105_;
}
}
else
{
if (v_j_100_ == 0)
{
goto v___jp_105_;
}
else
{
goto v___jp_108_;
}
}
v___jp_105_:
{
uint8_t v___x_106_; lean_object* v___x_107_; 
v___x_106_ = 1;
v___x_107_ = lp_tree_GlobalTheory_WeilNoncomm_sgn___at___00GlobalTheory_WeilNoncomm_twoCharts_spec__0(v___x_104_, v___x_106_);
lean_dec_ref(v___x_104_);
return v___x_107_;
}
v___jp_108_:
{
uint8_t v___x_109_; lean_object* v___x_110_; 
v___x_109_ = 0;
v___x_110_ = lp_tree_GlobalTheory_WeilNoncomm_sgn___at___00GlobalTheory_WeilNoncomm_twoCharts_spec__0(v___x_104_, v___x_109_);
lean_dec_ref(v___x_104_);
return v___x_110_;
}
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_WeilNoncomm_twoCharts___lam__0___boxed(lean_object* v_X_111_, lean_object* v_i_112_, lean_object* v_j_113_){
_start:
{
uint8_t v_i_boxed_114_; uint8_t v_j_boxed_115_; lean_object* v_res_116_; 
v_i_boxed_114_ = lean_unbox(v_i_112_);
v_j_boxed_115_ = lean_unbox(v_j_113_);
v_res_116_ = lp_tree_GlobalTheory_WeilNoncomm_twoCharts___lam__0(v_X_111_, v_i_boxed_114_, v_j_boxed_115_);
return v_res_116_;
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_WeilNoncomm_twoCharts___lam__1(uint8_t v_x_117_){
_start:
{
lean_object* v___x_118_; 
v___x_118_ = lean_box(0);
return v___x_118_;
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_WeilNoncomm_twoCharts___lam__1___boxed(lean_object* v_x_119_){
_start:
{
uint8_t v_x_417__boxed_120_; lean_object* v_res_121_; 
v_x_417__boxed_120_ = lean_unbox(v_x_119_);
v_res_121_ = lp_tree_GlobalTheory_WeilNoncomm_twoCharts___lam__1(v_x_417__boxed_120_);
return v_res_121_;
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_WeilNoncomm_twoCharts(lean_object* v_X_123_){
_start:
{
lean_object* v___f_124_; lean_object* v___f_125_; lean_object* v___x_126_; 
v___f_124_ = lean_alloc_closure((void*)(lp_tree_GlobalTheory_WeilNoncomm_twoCharts___lam__0___boxed), 3, 1);
lean_closure_set(v___f_124_, 0, v_X_123_);
v___f_125_ = ((lean_object*)(lp_tree_GlobalTheory_WeilNoncomm_twoCharts___closed__0));
v___x_126_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_126_, 0, v___f_125_);
lean_ctor_set(v___x_126_, 1, v___f_124_);
return v___x_126_;
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_WeilNoncomm_Heis_instMul___redArg___lam__0(lean_object* v_toAdd_127_, lean_object* v_toMul_128_, lean_object* v_g_129_, lean_object* v_h_130_){
_start:
{
lean_object* v_a_131_; lean_object* v_b_132_; lean_object* v_c_133_; lean_object* v_a_134_; lean_object* v_b_135_; lean_object* v_c_136_; lean_object* v___x_138_; uint8_t v_isShared_139_; uint8_t v_isSharedCheck_148_; 
v_a_131_ = lean_ctor_get(v_g_129_, 0);
lean_inc(v_a_131_);
v_b_132_ = lean_ctor_get(v_g_129_, 1);
lean_inc(v_b_132_);
v_c_133_ = lean_ctor_get(v_g_129_, 2);
lean_inc(v_c_133_);
lean_dec_ref(v_g_129_);
v_a_134_ = lean_ctor_get(v_h_130_, 0);
v_b_135_ = lean_ctor_get(v_h_130_, 1);
v_c_136_ = lean_ctor_get(v_h_130_, 2);
v_isSharedCheck_148_ = !lean_is_exclusive(v_h_130_);
if (v_isSharedCheck_148_ == 0)
{
v___x_138_ = v_h_130_;
v_isShared_139_ = v_isSharedCheck_148_;
goto v_resetjp_137_;
}
else
{
lean_inc(v_c_136_);
lean_inc(v_b_135_);
lean_inc(v_a_134_);
lean_dec(v_h_130_);
v___x_138_ = lean_box(0);
v_isShared_139_ = v_isSharedCheck_148_;
goto v_resetjp_137_;
}
v_resetjp_137_:
{
lean_object* v___x_140_; lean_object* v___x_141_; lean_object* v___x_142_; lean_object* v___x_143_; lean_object* v___x_144_; lean_object* v___x_146_; 
lean_inc_n(v_toAdd_127_, 3);
lean_inc(v_a_131_);
v___x_140_ = lean_apply_2(v_toAdd_127_, v_a_131_, v_a_134_);
lean_inc(v_b_135_);
v___x_141_ = lean_apply_2(v_toAdd_127_, v_b_132_, v_b_135_);
v___x_142_ = lean_apply_2(v_toAdd_127_, v_c_133_, v_c_136_);
v___x_143_ = lean_apply_2(v_toMul_128_, v_a_131_, v_b_135_);
v___x_144_ = lean_apply_2(v_toAdd_127_, v___x_142_, v___x_143_);
if (v_isShared_139_ == 0)
{
lean_ctor_set(v___x_138_, 2, v___x_144_);
lean_ctor_set(v___x_138_, 1, v___x_141_);
lean_ctor_set(v___x_138_, 0, v___x_140_);
v___x_146_ = v___x_138_;
goto v_reusejp_145_;
}
else
{
lean_object* v_reuseFailAlloc_147_; 
v_reuseFailAlloc_147_ = lean_alloc_ctor(0, 3, 0);
lean_ctor_set(v_reuseFailAlloc_147_, 0, v___x_140_);
lean_ctor_set(v_reuseFailAlloc_147_, 1, v___x_141_);
lean_ctor_set(v_reuseFailAlloc_147_, 2, v___x_144_);
v___x_146_ = v_reuseFailAlloc_147_;
goto v_reusejp_145_;
}
v_reusejp_145_:
{
return v___x_146_;
}
}
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_WeilNoncomm_Heis_instMul___redArg(lean_object* v_inst_149_){
_start:
{
lean_object* v_toSemiring_150_; lean_object* v___x_151_; lean_object* v_toMul_152_; lean_object* v_toAdd_153_; lean_object* v___f_154_; 
v_toSemiring_150_ = lean_ctor_get(v_inst_149_, 0);
lean_inc_ref(v_toSemiring_150_);
lean_dec_ref(v_inst_149_);
v___x_151_ = lp_mathlib_instDistribOfSemiring___redArg(v_toSemiring_150_);
v_toMul_152_ = lean_ctor_get(v___x_151_, 0);
lean_inc(v_toMul_152_);
v_toAdd_153_ = lean_ctor_get(v___x_151_, 1);
lean_inc(v_toAdd_153_);
lean_dec_ref(v___x_151_);
v___f_154_ = lean_alloc_closure((void*)(lp_tree_GlobalTheory_WeilNoncomm_Heis_instMul___redArg___lam__0), 4, 2);
lean_closure_set(v___f_154_, 0, v_toAdd_153_);
lean_closure_set(v___f_154_, 1, v_toMul_152_);
return v___f_154_;
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_WeilNoncomm_Heis_instMul(lean_object* v_R_155_, lean_object* v_inst_156_){
_start:
{
lean_object* v___x_157_; 
v___x_157_ = lp_tree_GlobalTheory_WeilNoncomm_Heis_instMul___redArg(v_inst_156_);
return v___x_157_;
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_WeilNoncomm_Heis_instOne___redArg(lean_object* v_inst_158_){
_start:
{
lean_object* v_toSemiring_159_; lean_object* v___x_160_; lean_object* v_toZero_161_; lean_object* v___x_162_; 
v_toSemiring_159_ = lean_ctor_get(v_inst_158_, 0);
lean_inc_ref(v_toSemiring_159_);
lean_dec_ref(v_inst_158_);
v___x_160_ = lp_mathlib_instMulZeroClassOfSemiring___redArg(v_toSemiring_159_);
v_toZero_161_ = lean_ctor_get(v___x_160_, 1);
lean_inc_n(v_toZero_161_, 3);
lean_dec_ref(v___x_160_);
v___x_162_ = lean_alloc_ctor(0, 3, 0);
lean_ctor_set(v___x_162_, 0, v_toZero_161_);
lean_ctor_set(v___x_162_, 1, v_toZero_161_);
lean_ctor_set(v___x_162_, 2, v_toZero_161_);
return v___x_162_;
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_WeilNoncomm_Heis_instOne(lean_object* v_R_163_, lean_object* v_inst_164_){
_start:
{
lean_object* v___x_165_; 
v___x_165_ = lp_tree_GlobalTheory_WeilNoncomm_Heis_instOne___redArg(v_inst_164_);
return v___x_165_;
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_WeilNoncomm_Heis_instInv___redArg___lam__0(lean_object* v_toNeg_166_, lean_object* v_toMul_167_, lean_object* v_toAdd_168_, lean_object* v_g_169_){
_start:
{
lean_object* v_a_170_; lean_object* v_b_171_; lean_object* v_c_172_; lean_object* v___x_174_; uint8_t v_isShared_175_; uint8_t v_isSharedCheck_184_; 
v_a_170_ = lean_ctor_get(v_g_169_, 0);
v_b_171_ = lean_ctor_get(v_g_169_, 1);
v_c_172_ = lean_ctor_get(v_g_169_, 2);
v_isSharedCheck_184_ = !lean_is_exclusive(v_g_169_);
if (v_isSharedCheck_184_ == 0)
{
v___x_174_ = v_g_169_;
v_isShared_175_ = v_isSharedCheck_184_;
goto v_resetjp_173_;
}
else
{
lean_inc(v_c_172_);
lean_inc(v_b_171_);
lean_inc(v_a_170_);
lean_dec(v_g_169_);
v___x_174_ = lean_box(0);
v_isShared_175_ = v_isSharedCheck_184_;
goto v_resetjp_173_;
}
v_resetjp_173_:
{
lean_object* v___x_176_; lean_object* v___x_177_; lean_object* v___x_178_; lean_object* v___x_179_; lean_object* v___x_180_; lean_object* v___x_182_; 
lean_inc_n(v_toNeg_166_, 2);
lean_inc(v_a_170_);
v___x_176_ = lean_apply_1(v_toNeg_166_, v_a_170_);
lean_inc(v_b_171_);
v___x_177_ = lean_apply_1(v_toNeg_166_, v_b_171_);
v___x_178_ = lean_apply_1(v_toNeg_166_, v_c_172_);
v___x_179_ = lean_apply_2(v_toMul_167_, v_a_170_, v_b_171_);
v___x_180_ = lean_apply_2(v_toAdd_168_, v___x_178_, v___x_179_);
if (v_isShared_175_ == 0)
{
lean_ctor_set(v___x_174_, 2, v___x_180_);
lean_ctor_set(v___x_174_, 1, v___x_177_);
lean_ctor_set(v___x_174_, 0, v___x_176_);
v___x_182_ = v___x_174_;
goto v_reusejp_181_;
}
else
{
lean_object* v_reuseFailAlloc_183_; 
v_reuseFailAlloc_183_ = lean_alloc_ctor(0, 3, 0);
lean_ctor_set(v_reuseFailAlloc_183_, 0, v___x_176_);
lean_ctor_set(v_reuseFailAlloc_183_, 1, v___x_177_);
lean_ctor_set(v_reuseFailAlloc_183_, 2, v___x_180_);
v___x_182_ = v_reuseFailAlloc_183_;
goto v_reusejp_181_;
}
v_reusejp_181_:
{
return v___x_182_;
}
}
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_WeilNoncomm_Heis_instInv___redArg(lean_object* v_inst_185_){
_start:
{
lean_object* v___x_186_; lean_object* v___x_187_; lean_object* v_toNeg_188_; lean_object* v_toSemiring_189_; lean_object* v___x_190_; lean_object* v_toMul_191_; lean_object* v_toAdd_192_; lean_object* v___f_193_; 
v___x_186_ = lp_mathlib_Ring_toAddCommGroup___redArg(v_inst_185_);
v___x_187_ = lp_mathlib_SubNegZeroMonoid_toNegZeroClass___redArg(v___x_186_);
lean_dec_ref(v___x_186_);
v_toNeg_188_ = lean_ctor_get(v___x_187_, 1);
lean_inc(v_toNeg_188_);
lean_dec_ref(v___x_187_);
v_toSemiring_189_ = lean_ctor_get(v_inst_185_, 0);
lean_inc_ref(v_toSemiring_189_);
lean_dec_ref(v_inst_185_);
v___x_190_ = lp_mathlib_instDistribOfSemiring___redArg(v_toSemiring_189_);
v_toMul_191_ = lean_ctor_get(v___x_190_, 0);
lean_inc(v_toMul_191_);
v_toAdd_192_ = lean_ctor_get(v___x_190_, 1);
lean_inc(v_toAdd_192_);
lean_dec_ref(v___x_190_);
v___f_193_ = lean_alloc_closure((void*)(lp_tree_GlobalTheory_WeilNoncomm_Heis_instInv___redArg___lam__0), 4, 3);
lean_closure_set(v___f_193_, 0, v_toNeg_188_);
lean_closure_set(v___f_193_, 1, v_toMul_191_);
lean_closure_set(v___f_193_, 2, v_toAdd_192_);
return v___f_193_;
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_WeilNoncomm_Heis_instInv(lean_object* v_R_194_, lean_object* v_inst_195_){
_start:
{
lean_object* v___x_196_; 
v___x_196_ = lp_tree_GlobalTheory_WeilNoncomm_Heis_instInv___redArg(v_inst_195_);
return v___x_196_;
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_WeilNoncomm_Heis_instGroup___redArg(lean_object* v_inst_197_){
_start:
{
lean_object* v___x_198_; lean_object* v___x_199_; lean_object* v___x_200_; lean_object* v___x_201_; lean_object* v___x_202_; lean_object* v___x_203_; lean_object* v___x_204_; lean_object* v___x_205_; lean_object* v___x_206_; 
lean_inc_ref_n(v_inst_197_, 2);
v___x_198_ = lp_tree_GlobalTheory_WeilNoncomm_Heis_instMul___redArg(v_inst_197_);
v___x_199_ = lp_tree_GlobalTheory_WeilNoncomm_Heis_instInv___redArg(v_inst_197_);
v___x_200_ = lp_tree_GlobalTheory_WeilNoncomm_Heis_instOne___redArg(v_inst_197_);
lean_inc_ref_n(v___x_200_, 3);
lean_inc_ref_n(v___x_198_, 3);
v___x_201_ = lean_alloc_closure((void*)(lp_mathlib_npowBinRecAuto___boxed), 5, 3);
lean_closure_set(v___x_201_, 0, lean_box(0));
lean_closure_set(v___x_201_, 1, v___x_198_);
lean_closure_set(v___x_201_, 2, v___x_200_);
v___x_202_ = lean_alloc_ctor(0, 3, 0);
lean_ctor_set(v___x_202_, 0, v___x_198_);
lean_ctor_set(v___x_202_, 1, v___x_200_);
lean_ctor_set(v___x_202_, 2, v___x_201_);
lean_inc_ref_n(v___x_199_, 2);
lean_inc_ref(v___x_202_);
v___x_203_ = lean_alloc_closure((void*)(lp_mathlib_DivInvMonoid_div_x27___boxed), 5, 3);
lean_closure_set(v___x_203_, 0, lean_box(0));
lean_closure_set(v___x_203_, 1, v___x_202_);
lean_closure_set(v___x_203_, 2, v___x_199_);
v___x_204_ = lean_alloc_closure((void*)(l_npowRec___boxed), 5, 3);
lean_closure_set(v___x_204_, 0, lean_box(0));
lean_closure_set(v___x_204_, 1, v___x_200_);
lean_closure_set(v___x_204_, 2, v___x_198_);
v___x_205_ = lean_alloc_closure((void*)(lp_mathlib_zpowRec___boxed), 7, 5);
lean_closure_set(v___x_205_, 0, lean_box(0));
lean_closure_set(v___x_205_, 1, v___x_200_);
lean_closure_set(v___x_205_, 2, v___x_198_);
lean_closure_set(v___x_205_, 3, v___x_199_);
lean_closure_set(v___x_205_, 4, v___x_204_);
v___x_206_ = lean_alloc_ctor(0, 4, 0);
lean_ctor_set(v___x_206_, 0, v___x_202_);
lean_ctor_set(v___x_206_, 1, v___x_199_);
lean_ctor_set(v___x_206_, 2, v___x_203_);
lean_ctor_set(v___x_206_, 3, v___x_205_);
return v___x_206_;
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_WeilNoncomm_Heis_instGroup(lean_object* v_R_207_, lean_object* v_inst_208_){
_start:
{
lean_object* v___x_209_; 
v___x_209_ = lp_tree_GlobalTheory_WeilNoncomm_Heis_instGroup___redArg(v_inst_208_);
return v___x_209_;
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_WeilNoncomm_Heis_map___redArg___lam__0(lean_object* v_f_210_, lean_object* v_g_211_){
_start:
{
lean_object* v_a_212_; lean_object* v_b_213_; lean_object* v_c_214_; lean_object* v___x_216_; uint8_t v_isShared_217_; uint8_t v_isSharedCheck_224_; 
v_a_212_ = lean_ctor_get(v_g_211_, 0);
v_b_213_ = lean_ctor_get(v_g_211_, 1);
v_c_214_ = lean_ctor_get(v_g_211_, 2);
v_isSharedCheck_224_ = !lean_is_exclusive(v_g_211_);
if (v_isSharedCheck_224_ == 0)
{
v___x_216_ = v_g_211_;
v_isShared_217_ = v_isSharedCheck_224_;
goto v_resetjp_215_;
}
else
{
lean_inc(v_c_214_);
lean_inc(v_b_213_);
lean_inc(v_a_212_);
lean_dec(v_g_211_);
v___x_216_ = lean_box(0);
v_isShared_217_ = v_isSharedCheck_224_;
goto v_resetjp_215_;
}
v_resetjp_215_:
{
lean_object* v___x_218_; lean_object* v___x_219_; lean_object* v___x_220_; lean_object* v___x_222_; 
lean_inc_n(v_f_210_, 2);
v___x_218_ = lean_apply_1(v_f_210_, v_a_212_);
v___x_219_ = lean_apply_1(v_f_210_, v_b_213_);
v___x_220_ = lean_apply_1(v_f_210_, v_c_214_);
if (v_isShared_217_ == 0)
{
lean_ctor_set(v___x_216_, 2, v___x_220_);
lean_ctor_set(v___x_216_, 1, v___x_219_);
lean_ctor_set(v___x_216_, 0, v___x_218_);
v___x_222_ = v___x_216_;
goto v_reusejp_221_;
}
else
{
lean_object* v_reuseFailAlloc_223_; 
v_reuseFailAlloc_223_ = lean_alloc_ctor(0, 3, 0);
lean_ctor_set(v_reuseFailAlloc_223_, 0, v___x_218_);
lean_ctor_set(v_reuseFailAlloc_223_, 1, v___x_219_);
lean_ctor_set(v_reuseFailAlloc_223_, 2, v___x_220_);
v___x_222_ = v_reuseFailAlloc_223_;
goto v_reusejp_221_;
}
v_reusejp_221_:
{
return v___x_222_;
}
}
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_WeilNoncomm_Heis_map___redArg(lean_object* v_f_225_){
_start:
{
lean_object* v___f_226_; 
v___f_226_ = lean_alloc_closure((void*)(lp_tree_GlobalTheory_WeilNoncomm_Heis_map___redArg___lam__0), 2, 1);
lean_closure_set(v___f_226_, 0, v_f_225_);
return v___f_226_;
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_WeilNoncomm_Heis_map(lean_object* v_R_227_, lean_object* v_R_x27_228_, lean_object* v_inst_229_, lean_object* v_inst_230_, lean_object* v_f_231_){
_start:
{
lean_object* v___f_232_; 
v___f_232_ = lean_alloc_closure((void*)(lp_tree_GlobalTheory_WeilNoncomm_Heis_map___redArg___lam__0), 2, 1);
lean_closure_set(v___f_232_, 0, v_f_231_);
return v___f_232_;
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_WeilNoncomm_Heis_map___boxed(lean_object* v_R_233_, lean_object* v_R_x27_234_, lean_object* v_inst_235_, lean_object* v_inst_236_, lean_object* v_f_237_){
_start:
{
lean_object* v_res_238_; 
v_res_238_ = lp_tree_GlobalTheory_WeilNoncomm_Heis_map(v_R_233_, v_R_x27_234_, v_inst_235_, v_inst_236_, v_f_237_);
lean_dec_ref(v_inst_236_);
lean_dec_ref(v_inst_235_);
return v_res_238_;
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_WeilNoncomm_Heis_map___at___00GlobalTheory_WeilNoncomm_heisFunctor_spec__0(lean_object* v___x_239_, lean_object* v___x_240_, lean_object* v_f_241_){
_start:
{
lean_object* v___f_242_; 
v___f_242_ = lean_alloc_closure((void*)(lp_tree_GlobalTheory_WeilNoncomm_Heis_map___redArg___lam__0), 2, 1);
lean_closure_set(v___f_242_, 0, v_f_241_);
return v___f_242_;
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_WeilNoncomm_Heis_map___at___00GlobalTheory_WeilNoncomm_heisFunctor_spec__0___boxed(lean_object* v___x_243_, lean_object* v___x_244_, lean_object* v_f_245_){
_start:
{
lean_object* v_res_246_; 
v_res_246_ = lp_tree_GlobalTheory_WeilNoncomm_Heis_map___at___00GlobalTheory_WeilNoncomm_heisFunctor_spec__0(v___x_243_, v___x_244_, v_f_245_);
lean_dec_ref(v___x_244_);
lean_dec_ref(v___x_243_);
return v_res_246_;
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_WeilNoncomm_heisFunctor___lam__0(lean_object* v_X_247_, lean_object* v_Y_248_, lean_object* v_f_249_, lean_object* v___y_250_){
_start:
{
lean_object* v___x_251_; lean_object* v_left_252_; lean_object* v_c_253_; lean_object* v___x_254_; lean_object* v___x_255_; 
v___x_251_ = lean_box(0);
v_left_252_ = lean_ctor_get(v_f_249_, 0);
lean_inc(v_left_252_);
lean_dec_ref(v_f_249_);
v_c_253_ = lean_ctor_get(v_left_252_, 1);
lean_inc(v_c_253_);
lean_dec(v_left_252_);
v___x_254_ = lean_apply_1(v_c_253_, v___x_251_);
v___x_255_ = lp_tree_GlobalTheory_WeilNoncomm_Heis_map___redArg___lam__0(v___x_254_, v___y_250_);
return v___x_255_;
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_WeilNoncomm_heisFunctor___lam__0___boxed(lean_object* v_X_256_, lean_object* v_Y_257_, lean_object* v_f_258_, lean_object* v___y_259_){
_start:
{
lean_object* v_res_260_; 
v_res_260_ = lp_tree_GlobalTheory_WeilNoncomm_heisFunctor___lam__0(v_X_256_, v_Y_257_, v_f_258_, v___y_259_);
lean_dec_ref(v_Y_257_);
lean_dec_ref(v_X_256_);
return v_res_260_;
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_WeilNoncomm_heisFunctor___lam__1(lean_object* v_T_261_){
_start:
{
lean_object* v_left_262_; lean_object* v_presheaf_263_; lean_object* v_obj_264_; lean_object* v___x_265_; lean_object* v___x_266_; lean_object* v___x_267_; 
v_left_262_ = lean_ctor_get(v_T_261_, 0);
lean_inc(v_left_262_);
lean_dec_ref(v_T_261_);
v_presheaf_263_ = lean_ctor_get(v_left_262_, 1);
lean_inc_ref(v_presheaf_263_);
lean_dec(v_left_262_);
v_obj_264_ = lean_ctor_get(v_presheaf_263_, 0);
lean_inc(v_obj_264_);
lean_dec_ref(v_presheaf_263_);
v___x_265_ = lean_box(0);
v___x_266_ = lean_apply_1(v_obj_264_, v___x_265_);
v___x_267_ = lp_tree_GlobalTheory_WeilNoncomm_Heis_instGroup___redArg(v___x_266_);
return v___x_267_;
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_WeilNoncomm_heisFunctor(lean_object* v_S_273_){
_start:
{
lean_object* v___x_274_; 
v___x_274_ = ((lean_object*)(lp_tree_GlobalTheory_WeilNoncomm_heisFunctor___closed__2));
return v___x_274_;
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_WeilNoncomm_heisFunctor___boxed(lean_object* v_S_275_){
_start:
{
lean_object* v_res_276_; 
v_res_276_ = lp_tree_GlobalTheory_WeilNoncomm_heisFunctor(v_S_275_);
lean_dec_ref(v_S_275_);
return v_res_276_;
}
}
LEAN_EXPORT lean_object* lp_tree_MonoidHom_mk_x27___at___00GlobalTheory_WeilNoncomm_Heis_map___at___00GlobalTheory_WeilNoncomm_heisFunctor_spec__0_spec__0___redArg(lean_object* v_f_277_){
_start:
{
lean_inc_ref(v_f_277_);
return v_f_277_;
}
}
LEAN_EXPORT lean_object* lp_tree_MonoidHom_mk_x27___at___00GlobalTheory_WeilNoncomm_Heis_map___at___00GlobalTheory_WeilNoncomm_heisFunctor_spec__0_spec__0___redArg___boxed(lean_object* v_f_278_){
_start:
{
lean_object* v_res_279_; 
v_res_279_ = lp_tree_MonoidHom_mk_x27___at___00GlobalTheory_WeilNoncomm_Heis_map___at___00GlobalTheory_WeilNoncomm_heisFunctor_spec__0_spec__0___redArg(v_f_278_);
lean_dec_ref(v_f_278_);
return v_res_279_;
}
}
LEAN_EXPORT lean_object* lp_tree_MonoidHom_mk_x27___at___00GlobalTheory_WeilNoncomm_Heis_map___at___00GlobalTheory_WeilNoncomm_heisFunctor_spec__0_spec__0(lean_object* v___x_280_, lean_object* v___x_281_, lean_object* v_f_282_, lean_object* v_map__mul_283_){
_start:
{
lean_inc_ref(v_f_282_);
return v_f_282_;
}
}
LEAN_EXPORT lean_object* lp_tree_MonoidHom_mk_x27___at___00GlobalTheory_WeilNoncomm_Heis_map___at___00GlobalTheory_WeilNoncomm_heisFunctor_spec__0_spec__0___boxed(lean_object* v___x_284_, lean_object* v___x_285_, lean_object* v_f_286_, lean_object* v_map__mul_287_){
_start:
{
lean_object* v_res_288_; 
v_res_288_ = lp_tree_MonoidHom_mk_x27___at___00GlobalTheory_WeilNoncomm_Heis_map___at___00GlobalTheory_WeilNoncomm_heisFunctor_spec__0_spec__0(v___x_284_, v___x_285_, v_f_286_, v_map__mul_287_);
lean_dec_ref(v_f_286_);
lean_dec_ref(v___x_285_);
lean_dec_ref(v___x_284_);
return v_res_288_;
}
}
lean_object* initialize_Init(uint8_t builtin);
lean_object* initialize_Init(uint8_t builtin);
lean_object* initialize_mathlib_Mathlib(uint8_t builtin);
lean_object* initialize_tree_Development_AbelianVarietyTheory_Proofs_ModuliProofs_WeilIsGrpPullbackOfCommute(uint8_t builtin);
lean_object* initialize_tree_ReciprocityTheory_ReductiveGroups_ArithmeticGeometry_BirationalGeometry_ToroidalCompactification_IsHolPeriods(uint8_t builtin);
lean_object* initialize_tree_ReciprocityTheory_ReductiveGroups_ArithmeticGeometry_BirationalGeometry_ToroidalCompactification_HeckeKer(uint8_t builtin);
lean_object* initialize_tree_ReciprocityTheory_ReductiveGroups_ArithmeticGeometry_BirationalGeometry_ToroidalCompactification_FlagBasis(uint8_t builtin);
lean_object* initialize_tree_ReciprocityTheory_ReductiveGroups_ArithmeticGeometry_BirationalGeometry_ToroidalCompactification_SabComp(uint8_t builtin);
lean_object* initialize_tree_ReciprocityTheory_ReductiveGroups_ArithmeticGeometry_BirationalGeometry_ToroidalCompactification_EigLatBasis(uint8_t builtin);
lean_object* initialize_tree_ReciprocityTheory_ReductiveGroups_ArithmeticGeometry_BirationalGeometry_ToroidalCompactification_BCTools(uint8_t builtin);
lean_object* initialize_tree_ReciprocityTheory_ReductiveGroups_ArithmeticGeometry_ExtensionDescent_SecBaseChangeAnySt(uint8_t builtin);
lean_object* initialize_tree_ReciprocityTheory_ReductiveGroups_ArithmeticGeometry_SemiabelianSchemes_Biextensions_CubicalExtendsSt(uint8_t builtin);
static bool _G_initialized = false;
LEAN_EXPORT lean_object* initialize_tree_Development_AbelianVarietyTheory_Proofs_UnitaryExistence_NotWeilIsGrpPullbackNoncomm(uint8_t builtin) {
lean_object * res;
if (_G_initialized) return lean_io_result_mk_ok(lean_box(0));
_G_initialized = true;
res = initialize_Init(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_Init(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_mathlib_Mathlib(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_Development_AbelianVarietyTheory_Proofs_ModuliProofs_WeilIsGrpPullbackOfCommute(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_ReciprocityTheory_ReductiveGroups_ArithmeticGeometry_BirationalGeometry_ToroidalCompactification_IsHolPeriods(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_ReciprocityTheory_ReductiveGroups_ArithmeticGeometry_BirationalGeometry_ToroidalCompactification_HeckeKer(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_ReciprocityTheory_ReductiveGroups_ArithmeticGeometry_BirationalGeometry_ToroidalCompactification_FlagBasis(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_ReciprocityTheory_ReductiveGroups_ArithmeticGeometry_BirationalGeometry_ToroidalCompactification_SabComp(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_ReciprocityTheory_ReductiveGroups_ArithmeticGeometry_BirationalGeometry_ToroidalCompactification_EigLatBasis(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_ReciprocityTheory_ReductiveGroups_ArithmeticGeometry_BirationalGeometry_ToroidalCompactification_BCTools(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_ReciprocityTheory_ReductiveGroups_ArithmeticGeometry_ExtensionDescent_SecBaseChangeAnySt(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_ReciprocityTheory_ReductiveGroups_ArithmeticGeometry_SemiabelianSchemes_Biextensions_CubicalExtendsSt(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
return lean_io_result_mk_ok(lean_box(0));
}
#ifdef __cplusplus
}
#endif
