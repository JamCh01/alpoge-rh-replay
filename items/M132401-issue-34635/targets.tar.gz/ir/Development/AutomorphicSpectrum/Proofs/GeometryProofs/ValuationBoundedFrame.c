// Lean compiler output
// Module: Development.AutomorphicSpectrum.Proofs.GeometryProofs.ValuationBoundedFrame
// Imports: public import Init public meta import Init public import Mathlib public import Development.AutomorphicSpectrum.Proofs.GeometryProofs.ExistsSubMemEigW public import Development.AutomorphicSpectrum.Proofs.AlgebraProofs.SplitHermitianGeneratorsExistStatement public import Development.AutomorphicSpectrum.Proofs.AlgebraProofs.FamilyHodgeLatticeDataStatement public import Development.AutomorphicSpectrum.Proofs.GeometryProofs.IntersectionHiddenSecondStatement public import Development.AutomorphicSpectrum.Proofs.AlgebraProofs.FormalIsomorphismTransportStatement public import Development.AutomorphicSpectrum.Proofs.AlgebraProofs.BundleDegreeEqSumValuations public import Development.AutomorphicSpectrum.Proofs.AlgebraProofs.SubAndQuotientBundles
#include <lean/lean.h>
#if defined(__clang__)
#pragma clang diagnostic ignored "-Wunused-parameter"
#pragma clang diagnostic ignored "-Wunused-label"
#elif defined(__GNUC__) && !defined(__CLANG__)
#pragma GCC diagnostic ignored "-Wunused-parameter"
#pragma GCC diagnostic ignored "-Wunused-label"
#pragma GCC diagnostic ignored "-Wunused-but-set-variable"
#endif
#ifdef __cplusplus
extern "C" {
#endif
lean_object* lp_mathlib_Field_toSemifield___redArg(lean_object*);
lean_object* lp_mathlib_Semifield_toDivisionSemiring___redArg(lean_object*);
lean_object* lp_mathlib_Submodule_completeLattice___redArg(lean_object*, lean_object*, lean_object*);
lean_object* lp_mathlib_CompleteLattice_toCompletePartialOrder___redArg(lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_CompanionTheory_Ar_Flat_DegProd_eigSpan___redArg(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_CompanionTheory_Ar_Flat_DegProd_eigSpan___redArg___boxed(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_CompanionTheory_Ar_Flat_DegProd_eigSpan(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_CompanionTheory_Ar_Flat_DegProd_eigSpan___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_CompanionTheory_Ar_Flat_DegProd_eigSpan___redArg(lean_object* v_inst_1_, lean_object* v_inst_2_, lean_object* v_inst_3_){
_start:
{
lean_object* v___x_4_; lean_object* v___x_5_; lean_object* v_toSemiring_6_; lean_object* v_toAddMonoid_7_; lean_object* v___x_8_; lean_object* v___x_9_; lean_object* v_toSupSet_10_; lean_object* v___x_11_; 
v___x_4_ = lp_mathlib_Field_toSemifield___redArg(v_inst_1_);
v___x_5_ = lp_mathlib_Semifield_toDivisionSemiring___redArg(v___x_4_);
v_toSemiring_6_ = lean_ctor_get(v___x_5_, 0);
lean_inc_ref(v_toSemiring_6_);
lean_dec_ref(v___x_5_);
v_toAddMonoid_7_ = lean_ctor_get(v_inst_2_, 0);
v___x_8_ = lp_mathlib_Submodule_completeLattice___redArg(v_toSemiring_6_, v_toAddMonoid_7_, v_inst_3_);
lean_dec_ref(v_toSemiring_6_);
v___x_9_ = lp_mathlib_CompleteLattice_toCompletePartialOrder___redArg(v___x_8_);
v_toSupSet_10_ = lean_ctor_get(v___x_9_, 1);
lean_inc(v_toSupSet_10_);
lean_dec_ref(v___x_9_);
v___x_11_ = lean_apply_1(v_toSupSet_10_, lean_box(0));
return v___x_11_;
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_CompanionTheory_Ar_Flat_DegProd_eigSpan___redArg___boxed(lean_object* v_inst_12_, lean_object* v_inst_13_, lean_object* v_inst_14_){
_start:
{
lean_object* v_res_15_; 
v_res_15_ = lp_tree_GlobalTheory_CompanionTheory_Ar_Flat_DegProd_eigSpan___redArg(v_inst_12_, v_inst_13_, v_inst_14_);
lean_dec(v_inst_14_);
lean_dec_ref(v_inst_13_);
lean_dec_ref(v_inst_12_);
return v_res_15_;
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_CompanionTheory_Ar_Flat_DegProd_eigSpan(lean_object* v_O_16_, lean_object* v_inst_17_, lean_object* v_K_18_, lean_object* v_inst_19_, lean_object* v_V_20_, lean_object* v_inst_21_, lean_object* v_inst_22_, lean_object* v_00_u03c1_23_, lean_object* v_00_u03c7_24_){
_start:
{
lean_object* v___x_25_; lean_object* v___x_26_; lean_object* v_toSemiring_27_; lean_object* v_toAddMonoid_28_; lean_object* v___x_29_; lean_object* v___x_30_; lean_object* v_toSupSet_31_; lean_object* v___x_32_; 
v___x_25_ = lp_mathlib_Field_toSemifield___redArg(v_inst_19_);
v___x_26_ = lp_mathlib_Semifield_toDivisionSemiring___redArg(v___x_25_);
v_toSemiring_27_ = lean_ctor_get(v___x_26_, 0);
lean_inc_ref(v_toSemiring_27_);
lean_dec_ref(v___x_26_);
v_toAddMonoid_28_ = lean_ctor_get(v_inst_21_, 0);
v___x_29_ = lp_mathlib_Submodule_completeLattice___redArg(v_toSemiring_27_, v_toAddMonoid_28_, v_inst_22_);
lean_dec_ref(v_toSemiring_27_);
v___x_30_ = lp_mathlib_CompleteLattice_toCompletePartialOrder___redArg(v___x_29_);
v_toSupSet_31_ = lean_ctor_get(v___x_30_, 1);
lean_inc(v_toSupSet_31_);
lean_dec_ref(v___x_30_);
v___x_32_ = lean_apply_1(v_toSupSet_31_, lean_box(0));
return v___x_32_;
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_CompanionTheory_Ar_Flat_DegProd_eigSpan___boxed(lean_object* v_O_33_, lean_object* v_inst_34_, lean_object* v_K_35_, lean_object* v_inst_36_, lean_object* v_V_37_, lean_object* v_inst_38_, lean_object* v_inst_39_, lean_object* v_00_u03c1_40_, lean_object* v_00_u03c7_41_){
_start:
{
lean_object* v_res_42_; 
v_res_42_ = lp_tree_GlobalTheory_CompanionTheory_Ar_Flat_DegProd_eigSpan(v_O_33_, v_inst_34_, v_K_35_, v_inst_36_, v_V_37_, v_inst_38_, v_inst_39_, v_00_u03c1_40_, v_00_u03c7_41_);
lean_dec(v_00_u03c7_41_);
lean_dec(v_00_u03c1_40_);
lean_dec(v_inst_39_);
lean_dec_ref(v_inst_38_);
lean_dec_ref(v_inst_36_);
lean_dec_ref(v_inst_34_);
return v_res_42_;
}
}
lean_object* initialize_Init(uint8_t builtin);
lean_object* initialize_Init(uint8_t builtin);
lean_object* initialize_mathlib_Mathlib(uint8_t builtin);
lean_object* initialize_tree_Development_AutomorphicSpectrum_Proofs_GeometryProofs_ExistsSubMemEigW(uint8_t builtin);
lean_object* initialize_tree_Development_AutomorphicSpectrum_Proofs_AlgebraProofs_SplitHermitianGeneratorsExistStatement(uint8_t builtin);
lean_object* initialize_tree_Development_AutomorphicSpectrum_Proofs_AlgebraProofs_FamilyHodgeLatticeDataStatement(uint8_t builtin);
lean_object* initialize_tree_Development_AutomorphicSpectrum_Proofs_GeometryProofs_IntersectionHiddenSecondStatement(uint8_t builtin);
lean_object* initialize_tree_Development_AutomorphicSpectrum_Proofs_AlgebraProofs_FormalIsomorphismTransportStatement(uint8_t builtin);
lean_object* initialize_tree_Development_AutomorphicSpectrum_Proofs_AlgebraProofs_BundleDegreeEqSumValuations(uint8_t builtin);
lean_object* initialize_tree_Development_AutomorphicSpectrum_Proofs_AlgebraProofs_SubAndQuotientBundles(uint8_t builtin);
static bool _G_initialized = false;
LEAN_EXPORT lean_object* initialize_tree_Development_AutomorphicSpectrum_Proofs_GeometryProofs_ValuationBoundedFrame(uint8_t builtin) {
lean_object * res;
if (_G_initialized) return lean_io_result_mk_ok(lean_box(0));
_G_initialized = true;
res = initialize_Init(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_Init(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_mathlib_Mathlib(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_Development_AutomorphicSpectrum_Proofs_GeometryProofs_ExistsSubMemEigW(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_Development_AutomorphicSpectrum_Proofs_AlgebraProofs_SplitHermitianGeneratorsExistStatement(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_Development_AutomorphicSpectrum_Proofs_AlgebraProofs_FamilyHodgeLatticeDataStatement(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_Development_AutomorphicSpectrum_Proofs_GeometryProofs_IntersectionHiddenSecondStatement(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_Development_AutomorphicSpectrum_Proofs_AlgebraProofs_FormalIsomorphismTransportStatement(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_Development_AutomorphicSpectrum_Proofs_AlgebraProofs_BundleDegreeEqSumValuations(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_Development_AutomorphicSpectrum_Proofs_AlgebraProofs_SubAndQuotientBundles(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
return lean_io_result_mk_ok(lean_box(0));
}
#ifdef __cplusplus
}
#endif
