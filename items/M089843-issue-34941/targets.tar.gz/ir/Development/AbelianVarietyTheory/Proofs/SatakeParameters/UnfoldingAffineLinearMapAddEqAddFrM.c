// Lean compiler output
// Module: Development.AbelianVarietyTheory.Proofs.SatakeParameters.UnfoldingAffineLinearMapAddEqAddFrM
// Imports: public import Init public meta import Init public import Mathlib public import Development.AbelianVarietyTheory.BlockTheory.ThetaLiftGeometry.UnfoldedLatticeData
#include <lean/lean.h>
#if defined(__clang__)
#pragma clang diagnostic ignored "-Wunused-parameter"
#pragma clang diagnostic ignored "-Wunused-label"
#elif defined(__GNUC__) && !defined(__CLANG__)
#pragma GCC diagnostic ignored "-Wunused-parameter"
#pragma GCC diagnostic ignored "-Wunused-label"
#pragma GCC diagnostic ignored "-Wunused-but-set-variable"
#endif
#ifdef __cplusplus
extern "C" {
#endif
lean_object* lp_mathlib_Equiv_refl(lean_object*);
lean_object* lean_nat_add(lean_object*, lean_object*);
lean_object* l_instDecidableEqFin___boxed(lean_object*, lean_object*, lean_object*);
lean_object* l_List_finRange(lean_object*);
lean_object* lp_mathlib_Matrix_toLin_x27___redArg(lean_object*, lean_object*, lean_object*);
uint8_t lp_tree_Formalism_L2_Col_Loc_instDecidableIsFree(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
lean_object* lp_mathlib_instMulZeroClassOfSemiring___redArg(lean_object*);
uint8_t lean_nat_dec_lt(lean_object*, lean_object*);
lean_object* lean_nat_sub(lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_PadicUnfold_eSt(lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_PadicUnfold_eSt___boxed(lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_PadicUnfold_frM___redArg___lam__0(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_PadicUnfold_frM___redArg___lam__0___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
static lean_once_cell_t lp_tree_GlobalTheory_PadicUnfold_frM___redArg___closed__0_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* lp_tree_GlobalTheory_PadicUnfold_frM___redArg___closed__0;
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_PadicUnfold_frM___redArg(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_PadicUnfold_frM___redArg___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_PadicUnfold_frM(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_PadicUnfold_frM___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_PadicUnfold_Ncong(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_PadicUnfold_Ncong___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_PadicUnfold_eSt(lean_object* v_n_1_, lean_object* v_l_2_){
_start:
{
uint8_t v___x_3_; 
v___x_3_ = lean_nat_dec_lt(v_l_2_, v_n_1_);
if (v___x_3_ == 0)
{
lean_object* v___x_4_; lean_object* v___x_5_; lean_object* v___x_6_; 
v___x_4_ = lean_nat_sub(v_l_2_, v_n_1_);
v___x_5_ = lean_unsigned_to_nat(1u);
v___x_6_ = lean_nat_add(v___x_4_, v___x_5_);
lean_dec(v___x_4_);
return v___x_6_;
}
else
{
lean_object* v___x_7_; 
v___x_7_ = lean_unsigned_to_nat(0u);
return v___x_7_;
}
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_PadicUnfold_eSt___boxed(lean_object* v_n_8_, lean_object* v_l_9_){
_start:
{
lean_object* v_res_10_; 
v_res_10_ = lp_tree_GlobalTheory_PadicUnfold_eSt(v_n_8_, v_l_9_);
lean_dec(v_l_9_);
lean_dec(v_n_8_);
return v_res_10_;
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_PadicUnfold_frM___redArg___lam__0(lean_object* v_n_x27_11_, lean_object* v_n_12_, lean_object* v_c_13_, lean_object* v_toSemiring_14_, lean_object* v_00_u03c4_15_, lean_object* v_l_16_, lean_object* v_s_17_){
_start:
{
uint8_t v___x_18_; 
v___x_18_ = lp_tree_Formalism_L2_Col_Loc_instDecidableIsFree(v_n_x27_11_, v_n_12_, v_c_13_, v_l_16_, v_s_17_);
if (v___x_18_ == 0)
{
lean_object* v___x_19_; lean_object* v_toZero_20_; 
lean_dec(v_s_17_);
lean_dec(v_l_16_);
lean_dec(v_00_u03c4_15_);
v___x_19_ = lp_mathlib_instMulZeroClassOfSemiring___redArg(v_toSemiring_14_);
v_toZero_20_ = lean_ctor_get(v___x_19_, 1);
lean_inc(v_toZero_20_);
lean_dec_ref(v___x_19_);
return v_toZero_20_;
}
else
{
lean_object* v___x_21_; lean_object* v___x_22_; 
lean_dec_ref(v_toSemiring_14_);
v___x_21_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_21_, 0, v_l_16_);
lean_ctor_set(v___x_21_, 1, v_s_17_);
v___x_22_ = lean_apply_1(v_00_u03c4_15_, v___x_21_);
return v___x_22_;
}
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_PadicUnfold_frM___redArg___lam__0___boxed(lean_object* v_n_x27_23_, lean_object* v_n_24_, lean_object* v_c_25_, lean_object* v_toSemiring_26_, lean_object* v_00_u03c4_27_, lean_object* v_l_28_, lean_object* v_s_29_){
_start:
{
lean_object* v_res_30_; 
v_res_30_ = lp_tree_GlobalTheory_PadicUnfold_frM___redArg___lam__0(v_n_x27_23_, v_n_24_, v_c_25_, v_toSemiring_26_, v_00_u03c4_27_, v_l_28_, v_s_29_);
lean_dec(v_c_25_);
lean_dec(v_n_24_);
lean_dec(v_n_x27_23_);
return v_res_30_;
}
}
static lean_object* _init_lp_tree_GlobalTheory_PadicUnfold_frM___redArg___closed__0(void){
_start:
{
lean_object* v___x_31_; 
v___x_31_ = lp_mathlib_Equiv_refl(lean_box(0));
return v___x_31_;
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_PadicUnfold_frM___redArg(lean_object* v_inst_32_, lean_object* v_n_x27_33_, lean_object* v_c_x27_34_, lean_object* v_n_35_, lean_object* v_c_36_, lean_object* v_00_u03c4_37_){
_start:
{
lean_object* v_toSemiring_38_; lean_object* v___x_39_; lean_object* v_toFun_40_; lean_object* v___x_41_; lean_object* v___x_42_; lean_object* v___x_43_; lean_object* v___x_44_; lean_object* v_toLinearMap_45_; lean_object* v___f_46_; lean_object* v___x_47_; lean_object* v___x_48_; 
v_toSemiring_38_ = lean_ctor_get(v_inst_32_, 0);
lean_inc_ref_n(v_toSemiring_38_, 2);
lean_dec_ref(v_inst_32_);
v___x_39_ = lean_obj_once(&lp_tree_GlobalTheory_PadicUnfold_frM___redArg___closed__0, &lp_tree_GlobalTheory_PadicUnfold_frM___redArg___closed__0_once, _init_lp_tree_GlobalTheory_PadicUnfold_frM___redArg___closed__0);
v_toFun_40_ = lean_ctor_get(v___x_39_, 0);
v___x_41_ = lean_nat_add(v_n_x27_33_, v_c_x27_34_);
lean_inc(v___x_41_);
v___x_42_ = lean_alloc_closure((void*)(l_instDecidableEqFin___boxed), 3, 1);
lean_closure_set(v___x_42_, 0, v___x_41_);
v___x_43_ = l_List_finRange(v___x_41_);
v___x_44_ = lp_mathlib_Matrix_toLin_x27___redArg(v_toSemiring_38_, v___x_42_, v___x_43_);
v_toLinearMap_45_ = lean_ctor_get(v___x_44_, 0);
lean_inc(v_toLinearMap_45_);
lean_dec_ref(v___x_44_);
v___f_46_ = lean_alloc_closure((void*)(lp_tree_GlobalTheory_PadicUnfold_frM___redArg___lam__0___boxed), 7, 5);
lean_closure_set(v___f_46_, 0, v_n_x27_33_);
lean_closure_set(v___f_46_, 1, v_n_35_);
lean_closure_set(v___f_46_, 2, v_c_36_);
lean_closure_set(v___f_46_, 3, v_toSemiring_38_);
lean_closure_set(v___f_46_, 4, v_00_u03c4_37_);
lean_inc(v_toFun_40_);
v___x_47_ = lean_apply_1(v_toFun_40_, v___f_46_);
v___x_48_ = lean_apply_1(v_toLinearMap_45_, v___x_47_);
return v___x_48_;
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_PadicUnfold_frM___redArg___boxed(lean_object* v_inst_49_, lean_object* v_n_x27_50_, lean_object* v_c_x27_51_, lean_object* v_n_52_, lean_object* v_c_53_, lean_object* v_00_u03c4_54_){
_start:
{
lean_object* v_res_55_; 
v_res_55_ = lp_tree_GlobalTheory_PadicUnfold_frM___redArg(v_inst_49_, v_n_x27_50_, v_c_x27_51_, v_n_52_, v_c_53_, v_00_u03c4_54_);
lean_dec(v_c_x27_51_);
return v_res_55_;
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_PadicUnfold_frM(lean_object* v_k_56_, lean_object* v_inst_57_, lean_object* v_n_x27_58_, lean_object* v_c_x27_59_, lean_object* v_n_60_, lean_object* v_c_61_, lean_object* v_00_u03c4_62_){
_start:
{
lean_object* v___x_63_; 
v___x_63_ = lp_tree_GlobalTheory_PadicUnfold_frM___redArg(v_inst_57_, v_n_x27_58_, v_c_x27_59_, v_n_60_, v_c_61_, v_00_u03c4_62_);
return v___x_63_;
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_PadicUnfold_frM___boxed(lean_object* v_k_64_, lean_object* v_inst_65_, lean_object* v_n_x27_66_, lean_object* v_c_x27_67_, lean_object* v_n_68_, lean_object* v_c_69_, lean_object* v_00_u03c4_70_){
_start:
{
lean_object* v_res_71_; 
v_res_71_ = lp_tree_GlobalTheory_PadicUnfold_frM(v_k_64_, v_inst_65_, v_n_x27_66_, v_c_x27_67_, v_n_68_, v_c_69_, v_00_u03c4_70_);
lean_dec(v_c_x27_67_);
return v_res_71_;
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_PadicUnfold_Ncong(lean_object* v_g_72_, lean_object* v_inst_73_, lean_object* v_n_74_, lean_object* v_c_75_, lean_object* v_M_76_){
_start:
{
lean_object* v___x_77_; 
v___x_77_ = lean_box(0);
return v___x_77_;
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_PadicUnfold_Ncong___boxed(lean_object* v_g_78_, lean_object* v_inst_79_, lean_object* v_n_80_, lean_object* v_c_81_, lean_object* v_M_82_){
_start:
{
lean_object* v_res_83_; 
v_res_83_ = lp_tree_GlobalTheory_PadicUnfold_Ncong(v_g_78_, v_inst_79_, v_n_80_, v_c_81_, v_M_82_);
lean_dec(v_M_82_);
lean_dec(v_c_81_);
lean_dec(v_n_80_);
lean_dec(v_g_78_);
return v_res_83_;
}
}
lean_object* initialize_Init(uint8_t builtin);
lean_object* initialize_Init(uint8_t builtin);
lean_object* initialize_mathlib_Mathlib(uint8_t builtin);
lean_object* initialize_tree_Development_AbelianVarietyTheory_BlockTheory_ThetaLiftGeometry_UnfoldedLatticeData(uint8_t builtin);
static bool _G_initialized = false;
LEAN_EXPORT lean_object* initialize_tree_Development_AbelianVarietyTheory_Proofs_SatakeParameters_UnfoldingAffineLinearMapAddEqAddFrM(uint8_t builtin) {
lean_object * res;
if (_G_initialized) return lean_io_result_mk_ok(lean_box(0));
_G_initialized = true;
res = initialize_Init(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_Init(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_mathlib_Mathlib(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_Development_AbelianVarietyTheory_BlockTheory_ThetaLiftGeometry_UnfoldedLatticeData(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
return lean_io_result_mk_ok(lean_box(0));
}
#ifdef __cplusplus
}
#endif
