// Lean compiler output
// Module: Development.AbelianVarietyTheory.Proofs.FlagMeasures.LintegralFlagUnipotentEqStabilizerTimesSection
// Imports: public import Init public meta import Init public import Mathlib public import Development.AbelianVarietyTheory.Definitions.SemilocalFrames.IsNormalFormStabilizerMeasure public import Development.AbelianVarietyTheory.Definitions.SemilocalFrames.CmHalfIntegralGeneratorMemAlgebraicClosure public import Development.AbelianVarietyTheory.Proofs.FlagMeasures.IsotropicLeviEmbeddingHomomorphismProperties public import Development.AbelianVarietyTheory.Proofs.FlagMeasures.IsotropicStabilizerRadicalStructure public import Development.AbelianVarietyTheory.Proofs.FlagMeasures.ContinuousUpperOff public import Development.AbelianVarietyTheory.Proofs.FlagMeasures.LintegralRadicalEqTopSectionSplitStatement
#include <lean/lean.h>
#if defined(__clang__)
#pragma clang diagnostic ignored "-Wunused-parameter"
#pragma clang diagnostic ignored "-Wunused-label"
#elif defined(__GNUC__) && !defined(__CLANG__)
#pragma GCC diagnostic ignored "-Wunused-parameter"
#pragma GCC diagnostic ignored "-Wunused-label"
#pragma GCC diagnostic ignored "-Wunused-but-set-variable"
#endif
#ifdef __cplusplus
extern "C" {
#endif
lean_object* lp_tree_GlobalTheory_Amp_skewM___redArg(lean_object*, lean_object*, lean_object*, lean_object*);
lean_object* lp_mathlib_Multiset_map___redArg(lean_object*, lean_object*);
lean_object* lp_mathlib_Real_definition___lam__0_00___x40_Mathlib_Data_Real_Basic_1138242547____hygCtx___hyg_8_(lean_object*, lean_object*, lean_object*);
extern lean_object* lp_mathlib_Real_definition_00___x40_Mathlib_Data_Real_Basic_1850581184____hygCtx___hyg_8_;
lean_object* lp_mathlib_Complex_ofReal(lean_object*);
lean_object* l_List_foldrTR___redArg(lean_object*, lean_object*, lean_object*);
lean_object* lp_mathlib_Real_definition___lam__0_00___x40_Mathlib_Data_Real_Basic_2451848184____hygCtx___hyg_8_(lean_object*, lean_object*);
lean_object* lp_mathlib_Complex_mulAux___at___00Zsqrtd_lift___at___00GaussianInt_toComplex_spec__0_spec__1(lean_object*, lean_object*, lean_object*);
lean_object* l_List_finRange(lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_Amp_RadConj_skewL___lam__0(lean_object*, lean_object*, lean_object*);
static const lean_closure_object lp_tree_GlobalTheory_Amp_RadConj_skewL___closed__0_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_closure_object) + sizeof(void*)*0, .m_other = 0, .m_tag = 245}, .m_fun = (void*)lp_tree_GlobalTheory_Amp_RadConj_skewL___lam__0, .m_arity = 3, .m_num_fixed = 0, .m_objs = {} };
static const lean_object* lp_tree_GlobalTheory_Amp_RadConj_skewL___closed__0 = (const lean_object*)&lp_tree_GlobalTheory_Amp_RadConj_skewL___closed__0_value;
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_Amp_RadConj_skewL(lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_Amp_RadConj_skewL___boxed(lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_Amp_RadConj_skewR___lam__0(lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_Amp_RadConj_skewR___lam__1(lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_Amp_RadConj_skewR___lam__2(lean_object*);
static const lean_closure_object lp_tree_GlobalTheory_Amp_RadConj_skewR___closed__0_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_closure_object) + sizeof(void*)*0, .m_other = 0, .m_tag = 245}, .m_fun = (void*)lp_tree_GlobalTheory_Amp_RadConj_skewR___lam__2, .m_arity = 1, .m_num_fixed = 0, .m_objs = {} };
static const lean_object* lp_tree_GlobalTheory_Amp_RadConj_skewR___closed__0 = (const lean_object*)&lp_tree_GlobalTheory_Amp_RadConj_skewR___closed__0_value;
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_Amp_RadConj_skewR(lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_Amp_RadConj_skewR___boxed(lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_Amp_RadConj_rowL___redArg___lam__0(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_Multiset_sum___at___00Finset_sum___at___00GlobalTheory_Amp_RadConj_rowL_spec__0_spec__0___lam__0(lean_object*, lean_object*, lean_object*);
static lean_once_cell_t lp_tree_Multiset_sum___at___00Finset_sum___at___00GlobalTheory_Amp_RadConj_rowL_spec__0_spec__0___lam__1___closed__0_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* lp_tree_Multiset_sum___at___00Finset_sum___at___00GlobalTheory_Amp_RadConj_rowL_spec__0_spec__0___lam__1___closed__0;
LEAN_EXPORT lean_object* lp_tree_Multiset_sum___at___00Finset_sum___at___00GlobalTheory_Amp_RadConj_rowL_spec__0_spec__0___lam__1(lean_object*);
LEAN_EXPORT lean_object* lp_tree_Multiset_sum___at___00Finset_sum___at___00GlobalTheory_Amp_RadConj_rowL_spec__0_spec__0___lam__1___boxed(lean_object*);
static const lean_closure_object lp_tree_Multiset_sum___at___00Finset_sum___at___00GlobalTheory_Amp_RadConj_rowL_spec__0_spec__0___closed__0_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_closure_object) + sizeof(void*)*0, .m_other = 0, .m_tag = 245}, .m_fun = (void*)lp_tree_Multiset_sum___at___00Finset_sum___at___00GlobalTheory_Amp_RadConj_rowL_spec__0_spec__0___lam__0, .m_arity = 3, .m_num_fixed = 0, .m_objs = {} };
static const lean_object* lp_tree_Multiset_sum___at___00Finset_sum___at___00GlobalTheory_Amp_RadConj_rowL_spec__0_spec__0___closed__0 = (const lean_object*)&lp_tree_Multiset_sum___at___00Finset_sum___at___00GlobalTheory_Amp_RadConj_rowL_spec__0_spec__0___closed__0_value;
static const lean_closure_object lp_tree_Multiset_sum___at___00Finset_sum___at___00GlobalTheory_Amp_RadConj_rowL_spec__0_spec__0___closed__1_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_closure_object) + sizeof(void*)*0, .m_other = 0, .m_tag = 245}, .m_fun = (void*)lp_tree_Multiset_sum___at___00Finset_sum___at___00GlobalTheory_Amp_RadConj_rowL_spec__0_spec__0___lam__1___boxed, .m_arity = 1, .m_num_fixed = 0, .m_objs = {} };
static const lean_object* lp_tree_Multiset_sum___at___00Finset_sum___at___00GlobalTheory_Amp_RadConj_rowL_spec__0_spec__0___closed__1 = (const lean_object*)&lp_tree_Multiset_sum___at___00Finset_sum___at___00GlobalTheory_Amp_RadConj_rowL_spec__0_spec__0___closed__1_value;
LEAN_EXPORT lean_object* lp_tree_Multiset_sum___at___00Finset_sum___at___00GlobalTheory_Amp_RadConj_rowL_spec__0_spec__0(lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_Finset_sum___at___00GlobalTheory_Amp_RadConj_rowL_spec__0___redArg(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_Amp_RadConj_rowL___redArg___lam__1(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_Amp_RadConj_rowL___redArg(lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_Amp_RadConj_rowL(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_Amp_RadConj_rowL___boxed(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_Finset_sum___at___00GlobalTheory_Amp_RadConj_rowL_spec__0(lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_Amp_RadConj_skewL___lam__0(lean_object* v_p_1_, lean_object* v___y_2_, lean_object* v___y_3_){
_start:
{
lean_object* v_fst_4_; lean_object* v_snd_5_; lean_object* v___x_6_; 
v_fst_4_ = lean_ctor_get(v_p_1_, 0);
lean_inc(v_fst_4_);
v_snd_5_ = lean_ctor_get(v_p_1_, 1);
lean_inc(v_snd_5_);
lean_dec_ref(v_p_1_);
v___x_6_ = lp_tree_GlobalTheory_Amp_skewM___redArg(v_fst_4_, v_snd_5_, v___y_2_, v___y_3_);
return v___x_6_;
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_Amp_RadConj_skewL(lean_object* v_r_8_){
_start:
{
lean_object* v___f_9_; 
v___f_9_ = ((lean_object*)(lp_tree_GlobalTheory_Amp_RadConj_skewL___closed__0));
return v___f_9_;
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_Amp_RadConj_skewL___boxed(lean_object* v_r_10_){
_start:
{
lean_object* v_res_11_; 
v_res_11_ = lp_tree_GlobalTheory_Amp_RadConj_skewL(v_r_10_);
lean_dec(v_r_10_);
return v_res_11_;
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_Amp_RadConj_skewR___lam__0(lean_object* v_S_12_, lean_object* v_p_13_){
_start:
{
lean_object* v_fst_14_; lean_object* v_snd_15_; lean_object* v___x_16_; 
v_fst_14_ = lean_ctor_get(v_p_13_, 0);
lean_inc(v_fst_14_);
v_snd_15_ = lean_ctor_get(v_p_13_, 1);
lean_inc(v_snd_15_);
lean_dec_ref(v_p_13_);
v___x_16_ = lean_apply_2(v_S_12_, v_fst_14_, v_snd_15_);
return v___x_16_;
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_Amp_RadConj_skewR___lam__1(lean_object* v_S_17_, lean_object* v_a_18_){
_start:
{
lean_object* v___x_19_; lean_object* v_im_20_; 
lean_inc(v_a_18_);
v___x_19_ = lean_apply_2(v_S_17_, v_a_18_, v_a_18_);
v_im_20_ = lean_ctor_get(v___x_19_, 1);
lean_inc(v_im_20_);
lean_dec_ref(v___x_19_);
return v_im_20_;
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_Amp_RadConj_skewR___lam__2(lean_object* v_S_21_){
_start:
{
lean_object* v___f_22_; lean_object* v___f_23_; lean_object* v___x_24_; 
lean_inc_ref(v_S_21_);
v___f_22_ = lean_alloc_closure((void*)(lp_tree_GlobalTheory_Amp_RadConj_skewR___lam__0), 2, 1);
lean_closure_set(v___f_22_, 0, v_S_21_);
v___f_23_ = lean_alloc_closure((void*)(lp_tree_GlobalTheory_Amp_RadConj_skewR___lam__1), 2, 1);
lean_closure_set(v___f_23_, 0, v_S_21_);
v___x_24_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_24_, 0, v___f_22_);
lean_ctor_set(v___x_24_, 1, v___f_23_);
return v___x_24_;
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_Amp_RadConj_skewR(lean_object* v_r_26_){
_start:
{
lean_object* v___f_27_; 
v___f_27_ = ((lean_object*)(lp_tree_GlobalTheory_Amp_RadConj_skewR___closed__0));
return v___f_27_;
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_Amp_RadConj_skewR___boxed(lean_object* v_r_28_){
_start:
{
lean_object* v_res_29_; 
v_res_29_ = lp_tree_GlobalTheory_Amp_RadConj_skewR(v_r_28_);
lean_dec(v_r_28_);
return v_res_29_;
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_Amp_RadConj_rowL___redArg___lam__0(lean_object* v_u_30_, lean_object* v_a_31_, lean_object* v_B_32_, lean_object* v_c_33_, lean_object* v___y_34_){
_start:
{
lean_object* v___x_35_; lean_object* v_re_36_; lean_object* v_im_37_; lean_object* v___f_38_; lean_object* v___x_39_; lean_object* v___x_40_; 
lean_inc(v_c_33_);
v___x_35_ = lean_apply_2(v_u_30_, v_a_31_, v_c_33_);
v_re_36_ = lean_ctor_get(v___x_35_, 0);
lean_inc(v_re_36_);
v_im_37_ = lean_ctor_get(v___x_35_, 1);
lean_inc(v_im_37_);
lean_dec_ref(v___x_35_);
v___f_38_ = lean_alloc_closure((void*)(lp_mathlib_Real_definition___lam__0_00___x40_Mathlib_Data_Real_Basic_2451848184____hygCtx___hyg_8_), 2, 1);
lean_closure_set(v___f_38_, 0, v_im_37_);
v___x_39_ = lean_apply_2(v_B_32_, v_c_33_, v___y_34_);
v___x_40_ = lp_mathlib_Complex_mulAux___at___00Zsqrtd_lift___at___00GaussianInt_toComplex_spec__0_spec__1(v_re_36_, v___f_38_, v___x_39_);
return v___x_40_;
}
}
LEAN_EXPORT lean_object* lp_tree_Multiset_sum___at___00Finset_sum___at___00GlobalTheory_Amp_RadConj_rowL_spec__0_spec__0___lam__0(lean_object* v_x1_41_, lean_object* v_x2_42_, lean_object* v___y_43_){
_start:
{
lean_object* v___x_44_; lean_object* v_re_45_; lean_object* v_im_46_; lean_object* v___x_47_; lean_object* v_re_48_; lean_object* v_im_49_; lean_object* v___x_51_; uint8_t v_isShared_52_; uint8_t v_isSharedCheck_58_; 
lean_inc(v___y_43_);
v___x_44_ = lean_apply_1(v_x1_41_, v___y_43_);
v_re_45_ = lean_ctor_get(v___x_44_, 0);
lean_inc(v_re_45_);
v_im_46_ = lean_ctor_get(v___x_44_, 1);
lean_inc(v_im_46_);
lean_dec_ref(v___x_44_);
v___x_47_ = lean_apply_1(v_x2_42_, v___y_43_);
v_re_48_ = lean_ctor_get(v___x_47_, 0);
v_im_49_ = lean_ctor_get(v___x_47_, 1);
v_isSharedCheck_58_ = !lean_is_exclusive(v___x_47_);
if (v_isSharedCheck_58_ == 0)
{
v___x_51_ = v___x_47_;
v_isShared_52_ = v_isSharedCheck_58_;
goto v_resetjp_50_;
}
else
{
lean_inc(v_im_49_);
lean_inc(v_re_48_);
lean_dec(v___x_47_);
v___x_51_ = lean_box(0);
v_isShared_52_ = v_isSharedCheck_58_;
goto v_resetjp_50_;
}
v_resetjp_50_:
{
lean_object* v___f_53_; lean_object* v___f_54_; lean_object* v___x_56_; 
v___f_53_ = lean_alloc_closure((void*)(lp_mathlib_Real_definition___lam__0_00___x40_Mathlib_Data_Real_Basic_1138242547____hygCtx___hyg_8_), 3, 2);
lean_closure_set(v___f_53_, 0, v_re_45_);
lean_closure_set(v___f_53_, 1, v_re_48_);
v___f_54_ = lean_alloc_closure((void*)(lp_mathlib_Real_definition___lam__0_00___x40_Mathlib_Data_Real_Basic_1138242547____hygCtx___hyg_8_), 3, 2);
lean_closure_set(v___f_54_, 0, v_im_46_);
lean_closure_set(v___f_54_, 1, v_im_49_);
if (v_isShared_52_ == 0)
{
lean_ctor_set(v___x_51_, 1, v___f_54_);
lean_ctor_set(v___x_51_, 0, v___f_53_);
v___x_56_ = v___x_51_;
goto v_reusejp_55_;
}
else
{
lean_object* v_reuseFailAlloc_57_; 
v_reuseFailAlloc_57_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_57_, 0, v___f_53_);
lean_ctor_set(v_reuseFailAlloc_57_, 1, v___f_54_);
v___x_56_ = v_reuseFailAlloc_57_;
goto v_reusejp_55_;
}
v_reusejp_55_:
{
return v___x_56_;
}
}
}
}
static lean_object* _init_lp_tree_Multiset_sum___at___00Finset_sum___at___00GlobalTheory_Amp_RadConj_rowL_spec__0_spec__0___lam__1___closed__0(void){
_start:
{
lean_object* v___x_59_; lean_object* v___x_60_; 
v___x_59_ = lp_mathlib_Real_definition_00___x40_Mathlib_Data_Real_Basic_1850581184____hygCtx___hyg_8_;
v___x_60_ = lp_mathlib_Complex_ofReal(v___x_59_);
return v___x_60_;
}
}
LEAN_EXPORT lean_object* lp_tree_Multiset_sum___at___00Finset_sum___at___00GlobalTheory_Amp_RadConj_rowL_spec__0_spec__0___lam__1(lean_object* v_x_61_){
_start:
{
lean_object* v___x_62_; 
v___x_62_ = lean_obj_once(&lp_tree_Multiset_sum___at___00Finset_sum___at___00GlobalTheory_Amp_RadConj_rowL_spec__0_spec__0___lam__1___closed__0, &lp_tree_Multiset_sum___at___00Finset_sum___at___00GlobalTheory_Amp_RadConj_rowL_spec__0_spec__0___lam__1___closed__0_once, _init_lp_tree_Multiset_sum___at___00Finset_sum___at___00GlobalTheory_Amp_RadConj_rowL_spec__0_spec__0___lam__1___closed__0);
return v___x_62_;
}
}
LEAN_EXPORT lean_object* lp_tree_Multiset_sum___at___00Finset_sum___at___00GlobalTheory_Amp_RadConj_rowL_spec__0_spec__0___lam__1___boxed(lean_object* v_x_63_){
_start:
{
lean_object* v_res_64_; 
v_res_64_ = lp_tree_Multiset_sum___at___00Finset_sum___at___00GlobalTheory_Amp_RadConj_rowL_spec__0_spec__0___lam__1(v_x_63_);
lean_dec(v_x_63_);
return v_res_64_;
}
}
LEAN_EXPORT lean_object* lp_tree_Multiset_sum___at___00Finset_sum___at___00GlobalTheory_Amp_RadConj_rowL_spec__0_spec__0(lean_object* v_s_67_, lean_object* v___y_68_){
_start:
{
lean_object* v___f_69_; lean_object* v___f_70_; lean_object* v___x_452__overap_71_; lean_object* v___x_72_; 
v___f_69_ = ((lean_object*)(lp_tree_Multiset_sum___at___00Finset_sum___at___00GlobalTheory_Amp_RadConj_rowL_spec__0_spec__0___closed__0));
v___f_70_ = ((lean_object*)(lp_tree_Multiset_sum___at___00Finset_sum___at___00GlobalTheory_Amp_RadConj_rowL_spec__0_spec__0___closed__1));
v___x_452__overap_71_ = l_List_foldrTR___redArg(v___f_69_, v___f_70_, v_s_67_);
v___x_72_ = lean_apply_1(v___x_452__overap_71_, v___y_68_);
return v___x_72_;
}
}
LEAN_EXPORT lean_object* lp_tree_Finset_sum___at___00GlobalTheory_Amp_RadConj_rowL_spec__0___redArg(lean_object* v_s_73_, lean_object* v_f_74_, lean_object* v___y_75_){
_start:
{
lean_object* v___x_76_; lean_object* v___x_77_; 
v___x_76_ = lp_mathlib_Multiset_map___redArg(v_f_74_, v_s_73_);
v___x_77_ = lp_tree_Multiset_sum___at___00Finset_sum___at___00GlobalTheory_Amp_RadConj_rowL_spec__0_spec__0(v___x_76_, v___y_75_);
return v___x_77_;
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_Amp_RadConj_rowL___redArg___lam__1(lean_object* v_u_78_, lean_object* v_r_79_, lean_object* v_B_80_, lean_object* v_a_81_, lean_object* v___y_82_){
_start:
{
lean_object* v___f_83_; lean_object* v___x_84_; lean_object* v___x_85_; 
v___f_83_ = lean_alloc_closure((void*)(lp_tree_GlobalTheory_Amp_RadConj_rowL___redArg___lam__0), 5, 3);
lean_closure_set(v___f_83_, 0, v_u_78_);
lean_closure_set(v___f_83_, 1, v_a_81_);
lean_closure_set(v___f_83_, 2, v_B_80_);
v___x_84_ = l_List_finRange(v_r_79_);
v___x_85_ = lp_tree_Finset_sum___at___00GlobalTheory_Amp_RadConj_rowL_spec__0___redArg(v___x_84_, v___f_83_, v___y_82_);
return v___x_85_;
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_Amp_RadConj_rowL___redArg(lean_object* v_r_86_, lean_object* v_u_87_){
_start:
{
lean_object* v___f_88_; 
v___f_88_ = lean_alloc_closure((void*)(lp_tree_GlobalTheory_Amp_RadConj_rowL___redArg___lam__1), 5, 2);
lean_closure_set(v___f_88_, 0, v_u_87_);
lean_closure_set(v___f_88_, 1, v_r_86_);
return v___f_88_;
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_Amp_RadConj_rowL(lean_object* v_r_89_, lean_object* v_m_90_, lean_object* v_u_91_){
_start:
{
lean_object* v___f_92_; 
v___f_92_ = lean_alloc_closure((void*)(lp_tree_GlobalTheory_Amp_RadConj_rowL___redArg___lam__1), 5, 2);
lean_closure_set(v___f_92_, 0, v_u_91_);
lean_closure_set(v___f_92_, 1, v_r_89_);
return v___f_92_;
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_Amp_RadConj_rowL___boxed(lean_object* v_r_93_, lean_object* v_m_94_, lean_object* v_u_95_){
_start:
{
lean_object* v_res_96_; 
v_res_96_ = lp_tree_GlobalTheory_Amp_RadConj_rowL(v_r_93_, v_m_94_, v_u_95_);
lean_dec(v_m_94_);
return v_res_96_;
}
}
LEAN_EXPORT lean_object* lp_tree_Finset_sum___at___00GlobalTheory_Amp_RadConj_rowL_spec__0(lean_object* v_00_u03b9_97_, lean_object* v_s_98_, lean_object* v_f_99_, lean_object* v___y_100_){
_start:
{
lean_object* v___x_101_; 
v___x_101_ = lp_tree_Finset_sum___at___00GlobalTheory_Amp_RadConj_rowL_spec__0___redArg(v_s_98_, v_f_99_, v___y_100_);
return v___x_101_;
}
}
lean_object* initialize_Init(uint8_t builtin);
lean_object* initialize_Init(uint8_t builtin);
lean_object* initialize_mathlib_Mathlib(uint8_t builtin);
lean_object* initialize_tree_Development_AbelianVarietyTheory_Definitions_SemilocalFrames_IsNormalFormStabilizerMeasure(uint8_t builtin);
lean_object* initialize_tree_Development_AbelianVarietyTheory_Definitions_SemilocalFrames_CmHalfIntegralGeneratorMemAlgebraicClosure(uint8_t builtin);
lean_object* initialize_tree_Development_AbelianVarietyTheory_Proofs_FlagMeasures_IsotropicLeviEmbeddingHomomorphismProperties(uint8_t builtin);
lean_object* initialize_tree_Development_AbelianVarietyTheory_Proofs_FlagMeasures_IsotropicStabilizerRadicalStructure(uint8_t builtin);
lean_object* initialize_tree_Development_AbelianVarietyTheory_Proofs_FlagMeasures_ContinuousUpperOff(uint8_t builtin);
lean_object* initialize_tree_Development_AbelianVarietyTheory_Proofs_FlagMeasures_LintegralRadicalEqTopSectionSplitStatement(uint8_t builtin);
static bool _G_initialized = false;
LEAN_EXPORT lean_object* initialize_tree_Development_AbelianVarietyTheory_Proofs_FlagMeasures_LintegralFlagUnipotentEqStabilizerTimesSection(uint8_t builtin) {
lean_object * res;
if (_G_initialized) return lean_io_result_mk_ok(lean_box(0));
_G_initialized = true;
res = initialize_Init(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_Init(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_mathlib_Mathlib(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_Development_AbelianVarietyTheory_Definitions_SemilocalFrames_IsNormalFormStabilizerMeasure(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_Development_AbelianVarietyTheory_Definitions_SemilocalFrames_CmHalfIntegralGeneratorMemAlgebraicClosure(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_Development_AbelianVarietyTheory_Proofs_FlagMeasures_IsotropicLeviEmbeddingHomomorphismProperties(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_Development_AbelianVarietyTheory_Proofs_FlagMeasures_IsotropicStabilizerRadicalStructure(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_Development_AbelianVarietyTheory_Proofs_FlagMeasures_ContinuousUpperOff(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_Development_AbelianVarietyTheory_Proofs_FlagMeasures_LintegralRadicalEqTopSectionSplitStatement(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
return lean_io_result_mk_ok(lean_box(0));
}
#ifdef __cplusplus
}
#endif
