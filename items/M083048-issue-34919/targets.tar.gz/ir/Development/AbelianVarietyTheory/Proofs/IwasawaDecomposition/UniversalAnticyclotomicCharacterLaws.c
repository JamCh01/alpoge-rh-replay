// Lean compiler output
// Module: Development.AbelianVarietyTheory.Proofs.IwasawaDecomposition.UniversalAnticyclotomicCharacterLaws
// Imports: public import Init public meta import Init public import Mathlib public import Formalism.SharpRestriction.LevelLetterCocycles.DataN public import Formalism.LocalToGlobal.UnitaryNorms.CharHost public import Development.AbelianVarietyTheory.PublishedTheorems.AutomorphicForms₂.AbsPowOneNotIsAlgRat public import Development.AbelianVarietyTheory.Proofs.IwasawaDecomposition.UnderEqIffConjPl public import Development.AbelianVarietyTheory.Definitions.NonGaloisDescent.GaloisSideTwistedSelmerAuxiliaryPrimes
#include <lean/lean.h>
#if defined(__clang__)
#pragma clang diagnostic ignored "-Wunused-parameter"
#pragma clang diagnostic ignored "-Wunused-label"
#elif defined(__GNUC__) && !defined(__CLANG__)
#pragma GCC diagnostic ignored "-Wunused-parameter"
#pragma GCC diagnostic ignored "-Wunused-label"
#pragma GCC diagnostic ignored "-Wunused-but-set-variable"
#endif
#ifdef __cplusplus
extern "C" {
#endif
uint8_t lean_nat_dec_eq(lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_GalChar_delAt___redArg(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_GalChar_delAt___redArg___boxed(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_GalChar_delAt(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_GalChar_delAt___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_GalChar_delAt___redArg(lean_object* v_H_1_, lean_object* v_C_2_, lean_object* v_l_3_){
_start:
{
lean_object* v_pde_4_; uint8_t v___x_5_; 
v_pde_4_ = lean_ctor_get(v_H_1_, 7);
v___x_5_ = lean_nat_dec_eq(v_l_3_, v_pde_4_);
if (v___x_5_ == 0)
{
lean_object* v_del_6_; 
v_del_6_ = lean_ctor_get(v_C_2_, 5);
lean_inc_ref(v_del_6_);
return v_del_6_;
}
else
{
lean_object* v_del_x27_7_; 
v_del_x27_7_ = lean_ctor_get(v_C_2_, 6);
lean_inc_ref(v_del_x27_7_);
return v_del_x27_7_;
}
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_GalChar_delAt___redArg___boxed(lean_object* v_H_8_, lean_object* v_C_9_, lean_object* v_l_10_){
_start:
{
lean_object* v_res_11_; 
v_res_11_ = lp_tree_GlobalTheory_GalChar_delAt___redArg(v_H_8_, v_C_9_, v_l_10_);
lean_dec(v_l_10_);
lean_dec_ref(v_C_9_);
lean_dec_ref(v_H_8_);
return v_res_11_;
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_GalChar_delAt(lean_object* v_R_12_, lean_object* v_H_13_, lean_object* v_e_14_, lean_object* v_C_15_, lean_object* v_l_16_){
_start:
{
lean_object* v___x_17_; 
v___x_17_ = lp_tree_GlobalTheory_GalChar_delAt___redArg(v_H_13_, v_C_15_, v_l_16_);
return v___x_17_;
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_GalChar_delAt___boxed(lean_object* v_R_18_, lean_object* v_H_19_, lean_object* v_e_20_, lean_object* v_C_21_, lean_object* v_l_22_){
_start:
{
lean_object* v_res_23_; 
v_res_23_ = lp_tree_GlobalTheory_GalChar_delAt(v_R_18_, v_H_19_, v_e_20_, v_C_21_, v_l_22_);
lean_dec(v_l_22_);
lean_dec_ref(v_C_21_);
lean_dec_ref(v_e_20_);
lean_dec_ref(v_H_19_);
lean_dec_ref(v_R_18_);
return v_res_23_;
}
}
lean_object* initialize_Init(uint8_t builtin);
lean_object* initialize_Init(uint8_t builtin);
lean_object* initialize_mathlib_Mathlib(uint8_t builtin);
lean_object* initialize_tree_Formalism_SharpRestriction_LevelLetterCocycles_DataN(uint8_t builtin);
lean_object* initialize_tree_Formalism_LocalToGlobal_UnitaryNorms_CharHost(uint8_t builtin);
lean_object* initialize_tree_Development_AbelianVarietyTheory_PublishedTheorems_AutomorphicForms_u2082_AbsPowOneNotIsAlgRat(uint8_t builtin);
lean_object* initialize_tree_Development_AbelianVarietyTheory_Proofs_IwasawaDecomposition_UnderEqIffConjPl(uint8_t builtin);
lean_object* initialize_tree_Development_AbelianVarietyTheory_Definitions_NonGaloisDescent_GaloisSideTwistedSelmerAuxiliaryPrimes(uint8_t builtin);
static bool _G_initialized = false;
LEAN_EXPORT lean_object* initialize_tree_Development_AbelianVarietyTheory_Proofs_IwasawaDecomposition_UniversalAnticyclotomicCharacterLaws(uint8_t builtin) {
lean_object * res;
if (_G_initialized) return lean_io_result_mk_ok(lean_box(0));
_G_initialized = true;
res = initialize_Init(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_Init(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_mathlib_Mathlib(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_Formalism_SharpRestriction_LevelLetterCocycles_DataN(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_Formalism_LocalToGlobal_UnitaryNorms_CharHost(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_Development_AbelianVarietyTheory_PublishedTheorems_AutomorphicForms_u2082_AbsPowOneNotIsAlgRat(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_Development_AbelianVarietyTheory_Proofs_IwasawaDecomposition_UnderEqIffConjPl(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_Development_AbelianVarietyTheory_Definitions_NonGaloisDescent_GaloisSideTwistedSelmerAuxiliaryPrimes(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
return lean_io_result_mk_ok(lean_box(0));
}
#ifdef __cplusplus
}
#endif
