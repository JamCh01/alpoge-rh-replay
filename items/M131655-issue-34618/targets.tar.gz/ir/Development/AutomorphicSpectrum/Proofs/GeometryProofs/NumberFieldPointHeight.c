// Lean compiler output
// Module: Development.AutomorphicSpectrum.Proofs.GeometryProofs.NumberFieldPointHeight
// Imports: public import Init public meta import Init public import Mathlib public import Development.AutomorphicSpectrum.Definitions.GlobalGeometry.ArchBetween public import Development.AutomorphicSpectrum.Proofs.GeometryProofs.LineHeightInvariantScaling public import GroundTheory.HeightsAndTheta.Heights.HeightComparison.HeightAssemblyFinal public import GroundTheory.HeightsAndTheta.Heights.OrbitLimits.PCurveRatSectionSum public import GroundTheory.HeightsAndTheta.Heights.ElementarySymmetric.PFlZArithVar public import GroundTheory.HeightsAndTheta.Heights.Antisymmetric.PNefOnFibresRelabel public import GroundTheory.HeightsAndTheta.Heights.WeightedHomogeneous.Reading
#include <lean/lean.h>
#if defined(__clang__)
#pragma clang diagnostic ignored "-Wunused-parameter"
#pragma clang diagnostic ignored "-Wunused-label"
#elif defined(__GNUC__) && !defined(__CLANG__)
#pragma GCC diagnostic ignored "-Wunused-parameter"
#pragma GCC diagnostic ignored "-Wunused-label"
#pragma GCC diagnostic ignored "-Wunused-but-set-variable"
#endif
#ifdef __cplusplus
extern "C" {
#endif
lean_object* lp_mathlib_Equiv_sigmaCongrRight___redArg(lean_object*);
lean_object* l_Function_comp(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
lean_object* lp_mathlib_Equiv_symm___redArg(lean_object*);
lean_object* lp_mathlib_Quot_congr___redArg(lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_CompanionTheory_Ar_Ht_PointCurve_sig___redArg(lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_CompanionTheory_Ar_Ht_PointCurve_sig(lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_CompanionTheory_Ar_Ht_PointCurve_sig___boxed(lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_CompanionTheory_Ar_Ht_PointCurve_pushLine___redArg___lam__0(lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_CompanionTheory_Ar_Ht_PointCurve_pushLine___redArg___lam__1(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_CompanionTheory_Ar_Ht_PointCurve_pushLine___redArg(lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_CompanionTheory_Ar_Ht_PointCurve_pushLine(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_CompanionTheory_Ar_Ht_PointCurve_pushLine___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_CompanionTheory_Ar_Ht_PointCurve_ptsEquiv___redArg___lam__0(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_CompanionTheory_Ar_Ht_PointCurve_ptsEquiv___redArg___lam__1(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_CompanionTheory_Ar_Ht_PointCurve_ptsEquiv___redArg(lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_CompanionTheory_Ar_Ht_PointCurve_ptsEquiv(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_CompanionTheory_Ar_Ht_PointCurve_ptsEquiv___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_CompanionTheory_Ar_Ht_PointCurve_projEquiv___redArg(lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_CompanionTheory_Ar_Ht_PointCurve_projEquiv(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_CompanionTheory_Ar_Ht_PointCurve_projEquiv___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_CompanionTheory_Ar_Ht_PointCurve_sig___redArg(lean_object* v_e_1_){
_start:
{
lean_object* v___x_2_; 
v___x_2_ = lp_mathlib_Equiv_sigmaCongrRight___redArg(v_e_1_);
return v___x_2_;
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_CompanionTheory_Ar_Ht_PointCurve_sig(lean_object* v_K_3_, lean_object* v_00_u03b9_4_, lean_object* v_n_5_, lean_object* v_e_6_){
_start:
{
lean_object* v___x_7_; 
v___x_7_ = lp_mathlib_Equiv_sigmaCongrRight___redArg(v_e_6_);
return v___x_7_;
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_CompanionTheory_Ar_Ht_PointCurve_sig___boxed(lean_object* v_K_8_, lean_object* v_00_u03b9_9_, lean_object* v_n_10_, lean_object* v_e_11_){
_start:
{
lean_object* v_res_12_; 
v_res_12_ = lp_tree_GlobalTheory_CompanionTheory_Ar_Ht_PointCurve_sig(v_K_8_, v_00_u03b9_9_, v_n_10_, v_e_11_);
lean_dec_ref(v_n_10_);
return v_res_12_;
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_CompanionTheory_Ar_Ht_PointCurve_pushLine___redArg___lam__0(lean_object* v___x_13_, lean_object* v___y_14_){
_start:
{
lean_object* v_toFun_15_; lean_object* v___x_16_; 
v_toFun_15_ = lean_ctor_get(v___x_13_, 0);
lean_inc(v_toFun_15_);
lean_dec_ref(v___x_13_);
v___x_16_ = lean_apply_1(v_toFun_15_, v___y_14_);
return v___x_16_;
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_CompanionTheory_Ar_Ht_PointCurve_pushLine___redArg___lam__1(lean_object* v_e_17_, lean_object* v_h_18_, lean_object* v_z_19_){
_start:
{
lean_object* v___x_20_; lean_object* v___f_21_; lean_object* v___x_22_; lean_object* v___x_23_; 
v___x_20_ = lp_mathlib_Equiv_sigmaCongrRight___redArg(v_e_17_);
v___f_21_ = lean_alloc_closure((void*)(lp_tree_GlobalTheory_CompanionTheory_Ar_Ht_PointCurve_pushLine___redArg___lam__0), 2, 1);
lean_closure_set(v___f_21_, 0, v___x_20_);
v___x_22_ = lean_alloc_closure((void*)(l_Function_comp), 6, 5);
lean_closure_set(v___x_22_, 0, lean_box(0));
lean_closure_set(v___x_22_, 1, lean_box(0));
lean_closure_set(v___x_22_, 2, lean_box(0));
lean_closure_set(v___x_22_, 3, v_z_19_);
lean_closure_set(v___x_22_, 4, v___f_21_);
v___x_23_ = lean_apply_1(v_h_18_, v___x_22_);
return v___x_23_;
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_CompanionTheory_Ar_Ht_PointCurve_pushLine___redArg(lean_object* v_e_24_, lean_object* v_A_25_){
_start:
{
lean_object* v_a_26_; lean_object* v_h_27_; lean_object* v___x_29_; uint8_t v_isShared_30_; uint8_t v_isSharedCheck_35_; 
v_a_26_ = lean_ctor_get(v_A_25_, 0);
v_h_27_ = lean_ctor_get(v_A_25_, 1);
v_isSharedCheck_35_ = !lean_is_exclusive(v_A_25_);
if (v_isSharedCheck_35_ == 0)
{
v___x_29_ = v_A_25_;
v_isShared_30_ = v_isSharedCheck_35_;
goto v_resetjp_28_;
}
else
{
lean_inc(v_h_27_);
lean_inc(v_a_26_);
lean_dec(v_A_25_);
v___x_29_ = lean_box(0);
v_isShared_30_ = v_isSharedCheck_35_;
goto v_resetjp_28_;
}
v_resetjp_28_:
{
lean_object* v___f_31_; lean_object* v___x_33_; 
v___f_31_ = lean_alloc_closure((void*)(lp_tree_GlobalTheory_CompanionTheory_Ar_Ht_PointCurve_pushLine___redArg___lam__1), 3, 2);
lean_closure_set(v___f_31_, 0, v_e_24_);
lean_closure_set(v___f_31_, 1, v_h_27_);
if (v_isShared_30_ == 0)
{
lean_ctor_set(v___x_29_, 1, v___f_31_);
v___x_33_ = v___x_29_;
goto v_reusejp_32_;
}
else
{
lean_object* v_reuseFailAlloc_34_; 
v_reuseFailAlloc_34_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_34_, 0, v_a_26_);
lean_ctor_set(v_reuseFailAlloc_34_, 1, v___f_31_);
v___x_33_ = v_reuseFailAlloc_34_;
goto v_reusejp_32_;
}
v_reusejp_32_:
{
return v___x_33_;
}
}
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_CompanionTheory_Ar_Ht_PointCurve_pushLine(lean_object* v_K_36_, lean_object* v_inst_37_, lean_object* v_00_u03b9_38_, lean_object* v_n_39_, lean_object* v_e_40_, lean_object* v_A_41_){
_start:
{
lean_object* v___x_42_; 
v___x_42_ = lp_tree_GlobalTheory_CompanionTheory_Ar_Ht_PointCurve_pushLine___redArg(v_e_40_, v_A_41_);
return v___x_42_;
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_CompanionTheory_Ar_Ht_PointCurve_pushLine___boxed(lean_object* v_K_43_, lean_object* v_inst_44_, lean_object* v_00_u03b9_45_, lean_object* v_n_46_, lean_object* v_e_47_, lean_object* v_A_48_){
_start:
{
lean_object* v_res_49_; 
v_res_49_ = lp_tree_GlobalTheory_CompanionTheory_Ar_Ht_PointCurve_pushLine(v_K_43_, v_inst_44_, v_00_u03b9_45_, v_n_46_, v_e_47_, v_A_48_);
lean_dec_ref(v_n_46_);
lean_dec(v_inst_44_);
return v_res_49_;
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_CompanionTheory_Ar_Ht_PointCurve_ptsEquiv___redArg___lam__0(lean_object* v_e_50_, lean_object* v_z_51_, lean_object* v___y_52_){
_start:
{
lean_object* v___x_53_; lean_object* v___x_54_; lean_object* v_toFun_55_; lean_object* v___x_56_; lean_object* v___x_57_; 
v___x_53_ = lp_mathlib_Equiv_sigmaCongrRight___redArg(v_e_50_);
v___x_54_ = lp_mathlib_Equiv_symm___redArg(v___x_53_);
v_toFun_55_ = lean_ctor_get(v___x_54_, 0);
lean_inc(v_toFun_55_);
lean_dec_ref(v___x_54_);
v___x_56_ = lean_apply_1(v_toFun_55_, v___y_52_);
v___x_57_ = lean_apply_1(v_z_51_, v___x_56_);
return v___x_57_;
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_CompanionTheory_Ar_Ht_PointCurve_ptsEquiv___redArg___lam__1(lean_object* v_e_58_, lean_object* v_z_59_, lean_object* v___y_60_){
_start:
{
lean_object* v___x_61_; lean_object* v_toFun_62_; lean_object* v___x_63_; lean_object* v___x_64_; 
v___x_61_ = lp_mathlib_Equiv_sigmaCongrRight___redArg(v_e_58_);
v_toFun_62_ = lean_ctor_get(v___x_61_, 0);
lean_inc(v_toFun_62_);
lean_dec_ref(v___x_61_);
v___x_63_ = lean_apply_1(v_toFun_62_, v___y_60_);
v___x_64_ = lean_apply_1(v_z_59_, v___x_63_);
return v___x_64_;
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_CompanionTheory_Ar_Ht_PointCurve_ptsEquiv___redArg(lean_object* v_e_65_){
_start:
{
lean_object* v___f_66_; lean_object* v___f_67_; lean_object* v___x_68_; 
lean_inc_ref(v_e_65_);
v___f_66_ = lean_alloc_closure((void*)(lp_tree_GlobalTheory_CompanionTheory_Ar_Ht_PointCurve_ptsEquiv___redArg___lam__0), 3, 1);
lean_closure_set(v___f_66_, 0, v_e_65_);
v___f_67_ = lean_alloc_closure((void*)(lp_tree_GlobalTheory_CompanionTheory_Ar_Ht_PointCurve_ptsEquiv___redArg___lam__1), 3, 1);
lean_closure_set(v___f_67_, 0, v_e_65_);
v___x_68_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_68_, 0, v___f_66_);
lean_ctor_set(v___x_68_, 1, v___f_67_);
return v___x_68_;
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_CompanionTheory_Ar_Ht_PointCurve_ptsEquiv(lean_object* v_K_69_, lean_object* v_inst_70_, lean_object* v_00_u03b9_71_, lean_object* v_inst_72_, lean_object* v_n_73_, lean_object* v_e_74_, lean_object* v_P_75_){
_start:
{
lean_object* v___x_76_; 
v___x_76_ = lp_tree_GlobalTheory_CompanionTheory_Ar_Ht_PointCurve_ptsEquiv___redArg(v_e_74_);
return v___x_76_;
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_CompanionTheory_Ar_Ht_PointCurve_ptsEquiv___boxed(lean_object* v_K_77_, lean_object* v_inst_78_, lean_object* v_00_u03b9_79_, lean_object* v_inst_80_, lean_object* v_n_81_, lean_object* v_e_82_, lean_object* v_P_83_){
_start:
{
lean_object* v_res_84_; 
v_res_84_ = lp_tree_GlobalTheory_CompanionTheory_Ar_Ht_PointCurve_ptsEquiv(v_K_77_, v_inst_78_, v_00_u03b9_79_, v_inst_80_, v_n_81_, v_e_82_, v_P_83_);
lean_dec_ref(v_n_81_);
lean_dec(v_inst_80_);
lean_dec(v_inst_78_);
return v_res_84_;
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_CompanionTheory_Ar_Ht_PointCurve_projEquiv___redArg(lean_object* v_e_85_){
_start:
{
lean_object* v___x_86_; lean_object* v___x_87_; 
v___x_86_ = lp_tree_GlobalTheory_CompanionTheory_Ar_Ht_PointCurve_ptsEquiv___redArg(v_e_85_);
v___x_87_ = lp_mathlib_Quot_congr___redArg(v___x_86_);
return v___x_87_;
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_CompanionTheory_Ar_Ht_PointCurve_projEquiv(lean_object* v_K_88_, lean_object* v_inst_89_, lean_object* v_00_u03b9_90_, lean_object* v_inst_91_, lean_object* v_n_92_, lean_object* v_e_93_, lean_object* v_P_94_){
_start:
{
lean_object* v___x_95_; 
v___x_95_ = lp_tree_GlobalTheory_CompanionTheory_Ar_Ht_PointCurve_projEquiv___redArg(v_e_93_);
return v___x_95_;
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_CompanionTheory_Ar_Ht_PointCurve_projEquiv___boxed(lean_object* v_K_96_, lean_object* v_inst_97_, lean_object* v_00_u03b9_98_, lean_object* v_inst_99_, lean_object* v_n_100_, lean_object* v_e_101_, lean_object* v_P_102_){
_start:
{
lean_object* v_res_103_; 
v_res_103_ = lp_tree_GlobalTheory_CompanionTheory_Ar_Ht_PointCurve_projEquiv(v_K_96_, v_inst_97_, v_00_u03b9_98_, v_inst_99_, v_n_100_, v_e_101_, v_P_102_);
lean_dec_ref(v_n_100_);
lean_dec(v_inst_99_);
lean_dec(v_inst_97_);
return v_res_103_;
}
}
lean_object* initialize_Init(uint8_t builtin);
lean_object* initialize_Init(uint8_t builtin);
lean_object* initialize_mathlib_Mathlib(uint8_t builtin);
lean_object* initialize_tree_Development_AutomorphicSpectrum_Definitions_GlobalGeometry_ArchBetween(uint8_t builtin);
lean_object* initialize_tree_Development_AutomorphicSpectrum_Proofs_GeometryProofs_LineHeightInvariantScaling(uint8_t builtin);
lean_object* initialize_tree_GroundTheory_HeightsAndTheta_Heights_HeightComparison_HeightAssemblyFinal(uint8_t builtin);
lean_object* initialize_tree_GroundTheory_HeightsAndTheta_Heights_OrbitLimits_PCurveRatSectionSum(uint8_t builtin);
lean_object* initialize_tree_GroundTheory_HeightsAndTheta_Heights_ElementarySymmetric_PFlZArithVar(uint8_t builtin);
lean_object* initialize_tree_GroundTheory_HeightsAndTheta_Heights_Antisymmetric_PNefOnFibresRelabel(uint8_t builtin);
lean_object* initialize_tree_GroundTheory_HeightsAndTheta_Heights_WeightedHomogeneous_Reading(uint8_t builtin);
static bool _G_initialized = false;
LEAN_EXPORT lean_object* initialize_tree_Development_AutomorphicSpectrum_Proofs_GeometryProofs_NumberFieldPointHeight(uint8_t builtin) {
lean_object * res;
if (_G_initialized) return lean_io_result_mk_ok(lean_box(0));
_G_initialized = true;
res = initialize_Init(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_Init(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_mathlib_Mathlib(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_Development_AutomorphicSpectrum_Definitions_GlobalGeometry_ArchBetween(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_Development_AutomorphicSpectrum_Proofs_GeometryProofs_LineHeightInvariantScaling(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_GroundTheory_HeightsAndTheta_Heights_HeightComparison_HeightAssemblyFinal(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_GroundTheory_HeightsAndTheta_Heights_OrbitLimits_PCurveRatSectionSum(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_GroundTheory_HeightsAndTheta_Heights_ElementarySymmetric_PFlZArithVar(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_GroundTheory_HeightsAndTheta_Heights_Antisymmetric_PNefOnFibresRelabel(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_GroundTheory_HeightsAndTheta_Heights_WeightedHomogeneous_Reading(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
return lean_io_result_mk_ok(lean_box(0));
}
#ifdef __cplusplus
}
#endif
