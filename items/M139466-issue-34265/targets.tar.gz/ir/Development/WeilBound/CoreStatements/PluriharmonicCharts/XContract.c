// Lean compiler output
// Module: Development.WeilBound.CoreStatements.PluriharmonicCharts.XContract
// Imports: public import Init public meta import Init public import Mathlib public import Development.AutomorphicSpectrum.Definitions.MetricPeriods.Pull1 public import Development.AutomorphicSpectrum.Statements.MetricStatements.AgreementIffGuarded public import GroundTheory.HeightsAndTheta.Heights.HilbertSamuel.PNefAmpleGeneric public import GroundTheory.HeightsAndTheta.Heights.HilbertSamuel.ExistsLinearIndependentOfGenerates public import ReciprocityTheory.AnalyticForms.RegularLocalRings.IntToRat
#include <lean/lean.h>
#if defined(__clang__)
#pragma clang diagnostic ignored "-Wunused-parameter"
#pragma clang diagnostic ignored "-Wunused-label"
#elif defined(__GNUC__) && !defined(__CLANG__)
#pragma GCC diagnostic ignored "-Wunused-parameter"
#pragma GCC diagnostic ignored "-Wunused-label"
#pragma GCC diagnostic ignored "-Wunused-but-set-variable"
#endif
#ifdef __cplusplus
extern "C" {
#endif
lean_object* initialize_Init(uint8_t builtin);
lean_object* initialize_Init(uint8_t builtin);
lean_object* initialize_mathlib_Mathlib(uint8_t builtin);
lean_object* initialize_tree_Development_AutomorphicSpectrum_Definitions_MetricPeriods_Pull1(uint8_t builtin);
lean_object* initialize_tree_Development_AutomorphicSpectrum_Statements_MetricStatements_AgreementIffGuarded(uint8_t builtin);
lean_object* initialize_tree_GroundTheory_HeightsAndTheta_Heights_HilbertSamuel_PNefAmpleGeneric(uint8_t builtin);
lean_object* initialize_tree_GroundTheory_HeightsAndTheta_Heights_HilbertSamuel_ExistsLinearIndependentOfGenerates(uint8_t builtin);
lean_object* initialize_tree_ReciprocityTheory_AnalyticForms_RegularLocalRings_IntToRat(uint8_t builtin);
static bool _G_initialized = false;
LEAN_EXPORT lean_object* initialize_tree_Development_WeilBound_CoreStatements_PluriharmonicCharts_XContract(uint8_t builtin) {
lean_object * res;
if (_G_initialized) return lean_io_result_mk_ok(lean_box(0));
_G_initialized = true;
res = initialize_Init(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_Init(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_mathlib_Mathlib(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_Development_AutomorphicSpectrum_Definitions_MetricPeriods_Pull1(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_Development_AutomorphicSpectrum_Statements_MetricStatements_AgreementIffGuarded(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_GroundTheory_HeightsAndTheta_Heights_HilbertSamuel_PNefAmpleGeneric(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_GroundTheory_HeightsAndTheta_Heights_HilbertSamuel_ExistsLinearIndependentOfGenerates(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_ReciprocityTheory_AnalyticForms_RegularLocalRings_IntToRat(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
return lean_io_result_mk_ok(lean_box(0));
}
#ifdef __cplusplus
}
#endif
