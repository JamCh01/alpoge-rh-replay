// Lean compiler output
// Module: Development.AbelianVarietyTheory.Proofs.DivisorProofs.ExistsMonotoneBlocksSameHarishChandraCharacter
// Imports: public import Init public meta import Init public import Mathlib public import Formalism.PadicSubsetSums.CentralIdempotents.GaloisConjCentralIdempotent public import Development.AbelianVarietyTheory.BlockTheory.DivisorBase.CuspidalProductMultiplicity public import Formalism.LocalToGlobal.NormalizedHeckeFactors.CoeffZeroNeOfMonicIrr public import Development.AbelianVarietyTheory.Proofs.InertiaEigenvalues.HasLabelTransportEquiv
#include <lean/lean.h>
#if defined(__clang__)
#pragma clang diagnostic ignored "-Wunused-parameter"
#pragma clang diagnostic ignored "-Wunused-label"
#elif defined(__GNUC__) && !defined(__CLANG__)
#pragma GCC diagnostic ignored "-Wunused-parameter"
#pragma GCC diagnostic ignored "-Wunused-label"
#pragma GCC diagnostic ignored "-Wunused-but-set-variable"
#endif
#ifdef __cplusplus
extern "C" {
#endif
lean_object* lp_tree_Formalism_IrreducibleCountingLemmas_TYPES_glEquiv___redArg(lean_object*);
lean_object* lp_mathlib_Equiv_symm___redArg(lean_object*);
lean_object* lp_mathlib_Equiv_subtypeEquiv___redArg(lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_HCSort_blockEquiv___redArg(lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_HCSort_blockEquiv(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_HCSort_blockEquiv___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_HCSort_hcEquiv___redArg___lam__0(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_HCSort_hcEquiv___redArg___lam__1(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_HCSort_hcEquiv___redArg(lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_HCSort_hcEquiv(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_HCSort_hcEquiv___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_HCSort_blockEquiv___redArg(lean_object* v_e_1_){
_start:
{
lean_object* v___x_2_; 
v___x_2_ = lp_mathlib_Equiv_subtypeEquiv___redArg(v_e_1_);
return v___x_2_;
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_HCSort_blockEquiv(lean_object* v_00_u03b9_3_, lean_object* v_00_u03ba_4_, lean_object* v_s_5_, lean_object* v_e_6_, lean_object* v_b_7_, lean_object* v_c_8_){
_start:
{
lean_object* v___x_9_; 
v___x_9_ = lp_mathlib_Equiv_subtypeEquiv___redArg(v_e_6_);
return v___x_9_;
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_HCSort_blockEquiv___boxed(lean_object* v_00_u03b9_10_, lean_object* v_00_u03ba_11_, lean_object* v_s_12_, lean_object* v_e_13_, lean_object* v_b_14_, lean_object* v_c_15_){
_start:
{
lean_object* v_res_16_; 
v_res_16_ = lp_tree_GlobalTheory_HCSort_blockEquiv(v_00_u03b9_10_, v_00_u03ba_11_, v_s_12_, v_e_13_, v_b_14_, v_c_15_);
lean_dec(v_c_15_);
lean_dec_ref(v_b_14_);
lean_dec(v_s_12_);
return v_res_16_;
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_HCSort_hcEquiv___redArg___lam__0(lean_object* v_e_17_, lean_object* v_F_18_, lean_object* v___y_19_){
_start:
{
lean_object* v___x_20_; lean_object* v_toFun_21_; lean_object* v___x_22_; lean_object* v___x_23_; 
v___x_20_ = lp_tree_Formalism_IrreducibleCountingLemmas_TYPES_glEquiv___redArg(v_e_17_);
v_toFun_21_ = lean_ctor_get(v___x_20_, 0);
lean_inc(v_toFun_21_);
lean_dec_ref(v___x_20_);
v___x_22_ = lean_apply_1(v_toFun_21_, v___y_19_);
v___x_23_ = lean_apply_1(v_F_18_, v___x_22_);
return v___x_23_;
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_HCSort_hcEquiv___redArg___lam__1(lean_object* v_e_24_, lean_object* v_F_25_, lean_object* v___y_26_){
_start:
{
lean_object* v___x_27_; lean_object* v___x_28_; lean_object* v_toFun_29_; lean_object* v___x_30_; lean_object* v___x_31_; 
v___x_27_ = lp_tree_Formalism_IrreducibleCountingLemmas_TYPES_glEquiv___redArg(v_e_24_);
v___x_28_ = lp_mathlib_Equiv_symm___redArg(v___x_27_);
v_toFun_29_ = lean_ctor_get(v___x_28_, 0);
lean_inc(v_toFun_29_);
lean_dec_ref(v___x_28_);
v___x_30_ = lean_apply_1(v_toFun_29_, v___y_26_);
v___x_31_ = lean_apply_1(v_F_25_, v___x_30_);
return v___x_31_;
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_HCSort_hcEquiv___redArg(lean_object* v_e_32_){
_start:
{
lean_object* v___f_33_; lean_object* v___f_34_; lean_object* v___x_35_; 
lean_inc_ref(v_e_32_);
v___f_33_ = lean_alloc_closure((void*)(lp_tree_GlobalTheory_HCSort_hcEquiv___redArg___lam__0), 3, 1);
lean_closure_set(v___f_33_, 0, v_e_32_);
v___f_34_ = lean_alloc_closure((void*)(lp_tree_GlobalTheory_HCSort_hcEquiv___redArg___lam__1), 3, 1);
lean_closure_set(v___f_34_, 0, v_e_32_);
v___x_35_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_35_, 0, v___f_34_);
lean_ctor_set(v___x_35_, 1, v___f_33_);
return v___x_35_;
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_HCSort_hcEquiv(lean_object* v_K_36_, lean_object* v_inst_37_, lean_object* v_inst_38_, lean_object* v_inst_39_, lean_object* v_00_u03b9_40_, lean_object* v_00_u03ba_41_, lean_object* v_inst_42_, lean_object* v_inst_43_, lean_object* v_inst_44_, lean_object* v_inst_45_, lean_object* v_s_46_, lean_object* v_e_47_, lean_object* v_b_48_, lean_object* v_lam_49_){
_start:
{
lean_object* v___x_50_; 
v___x_50_ = lp_tree_GlobalTheory_HCSort_hcEquiv___redArg(v_e_47_);
return v___x_50_;
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_HCSort_hcEquiv___boxed(lean_object* v_K_51_, lean_object* v_inst_52_, lean_object* v_inst_53_, lean_object* v_inst_54_, lean_object* v_00_u03b9_55_, lean_object* v_00_u03ba_56_, lean_object* v_inst_57_, lean_object* v_inst_58_, lean_object* v_inst_59_, lean_object* v_inst_60_, lean_object* v_s_61_, lean_object* v_e_62_, lean_object* v_b_63_, lean_object* v_lam_64_){
_start:
{
lean_object* v_res_65_; 
v_res_65_ = lp_tree_GlobalTheory_HCSort_hcEquiv(v_K_51_, v_inst_52_, v_inst_53_, v_inst_54_, v_00_u03b9_55_, v_00_u03ba_56_, v_inst_57_, v_inst_58_, v_inst_59_, v_inst_60_, v_s_61_, v_e_62_, v_b_63_, v_lam_64_);
lean_dec_ref(v_lam_64_);
lean_dec_ref(v_b_63_);
lean_dec(v_s_61_);
lean_dec_ref(v_inst_60_);
lean_dec(v_inst_59_);
lean_dec_ref(v_inst_58_);
lean_dec(v_inst_57_);
lean_dec_ref(v_inst_54_);
lean_dec(v_inst_53_);
lean_dec_ref(v_inst_52_);
return v_res_65_;
}
}
lean_object* initialize_Init(uint8_t builtin);
lean_object* initialize_Init(uint8_t builtin);
lean_object* initialize_mathlib_Mathlib(uint8_t builtin);
lean_object* initialize_tree_Formalism_PadicSubsetSums_CentralIdempotents_GaloisConjCentralIdempotent(uint8_t builtin);
lean_object* initialize_tree_Development_AbelianVarietyTheory_BlockTheory_DivisorBase_CuspidalProductMultiplicity(uint8_t builtin);
lean_object* initialize_tree_Formalism_LocalToGlobal_NormalizedHeckeFactors_CoeffZeroNeOfMonicIrr(uint8_t builtin);
lean_object* initialize_tree_Development_AbelianVarietyTheory_Proofs_InertiaEigenvalues_HasLabelTransportEquiv(uint8_t builtin);
static bool _G_initialized = false;
LEAN_EXPORT lean_object* initialize_tree_Development_AbelianVarietyTheory_Proofs_DivisorProofs_ExistsMonotoneBlocksSameHarishChandraCharacter(uint8_t builtin) {
lean_object * res;
if (_G_initialized) return lean_io_result_mk_ok(lean_box(0));
_G_initialized = true;
res = initialize_Init(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_Init(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_mathlib_Mathlib(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_Formalism_PadicSubsetSums_CentralIdempotents_GaloisConjCentralIdempotent(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_Development_AbelianVarietyTheory_BlockTheory_DivisorBase_CuspidalProductMultiplicity(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_Formalism_LocalToGlobal_NormalizedHeckeFactors_CoeffZeroNeOfMonicIrr(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_Development_AbelianVarietyTheory_Proofs_InertiaEigenvalues_HasLabelTransportEquiv(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
return lean_io_result_mk_ok(lean_box(0));
}
#ifdef __cplusplus
}
#endif
