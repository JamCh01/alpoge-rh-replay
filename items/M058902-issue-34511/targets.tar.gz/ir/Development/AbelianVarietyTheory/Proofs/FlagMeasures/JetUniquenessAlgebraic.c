// Lean compiler output
// Module: Development.AbelianVarietyTheory.Proofs.FlagMeasures.JetUniquenessAlgebraic
// Imports: public import Init public meta import Init public import Mathlib public import Development.AbelianVarietyTheory.Definitions.SemilocalFrames.ActSingleNeZero public import Development.AbelianVarietyTheory.Statements.CuspFrameWeights.EigenfunctionFiniteCoefficients public import Formalism.RealPlaceAnalysis.RealPlaceTaylor.FirstSlotSliceSlotMixedCasimirZero public import Formalism.RealPlaceAnalysis.RealPlaceTaylor.IsCompactInvariantOrthogonalInf public import Formalism.RealPlaceAnalysis.FinalF public import Development.AbelianVarietyTheory.Proofs.FlagMeasures.SymmetricKMapEqZeroOfVminusSlicesStatement
#include <lean/lean.h>
#if defined(__clang__)
#pragma clang diagnostic ignored "-Wunused-parameter"
#pragma clang diagnostic ignored "-Wunused-label"
#elif defined(__GNUC__) && !defined(__CLANG__)
#pragma GCC diagnostic ignored "-Wunused-parameter"
#pragma GCC diagnostic ignored "-Wunused-label"
#pragma GCC diagnostic ignored "-Wunused-but-set-variable"
#endif
#ifdef __cplusplus
extern "C" {
#endif
lean_object* lp_mathlib_Function_eval(lean_object*, lean_object*, lean_object*, lean_object*);
lean_object* lp_mathlib_LinearMap_comp___redArg___lam__0(lean_object*, lean_object*, lean_object*);
lean_object* l_List_ofFn___redArg(lean_object*, lean_object*);
lean_object* l_List_reverse___redArg(lean_object*);
lean_object* lp_tree_Formalism_REAL_ew___redArg(lean_object*, lean_object*);
lean_object* lp_tree_Formalism_REAL_arrTo___redArg(lean_object*);
lean_object* lp_mathlib_LinearMap_pi___redArg___lam__0(lean_object*, lean_object*, lean_object*);
lean_object* lp_tree_Formalism_REAL_arrOf___redArg(lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_Jet_UniqAlg_jmW___redArg(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_Jet_UniqAlg_jmW(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_Jet_UniqAlg_jmW___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_Jet_UniqAlg_mapArr___redArg___lam__0(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_Jet_UniqAlg_mapArr___redArg(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_Jet_UniqAlg_mapArr(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_Jet_UniqAlg_mapArr___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_Jet_UniqAlg_jmW___redArg(lean_object* v_E_1_, lean_object* v_j_2_, lean_object* v_00_u03b1_3_){
_start:
{
lean_object* v___x_4_; lean_object* v___x_5_; lean_object* v___x_6_; 
v___x_4_ = l_List_ofFn___redArg(v_j_2_, v_00_u03b1_3_);
v___x_5_ = l_List_reverse___redArg(v___x_4_);
v___x_6_ = lp_tree_Formalism_REAL_ew___redArg(v_E_1_, v___x_5_);
return v___x_6_;
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_Jet_UniqAlg_jmW(lean_object* v_V_7_, lean_object* v_inst_8_, lean_object* v_inst_9_, lean_object* v_n_10_, lean_object* v_E_11_, lean_object* v_j_12_, lean_object* v_00_u03b1_13_){
_start:
{
lean_object* v___x_14_; 
v___x_14_ = lp_tree_GlobalTheory_Jet_UniqAlg_jmW___redArg(v_E_11_, v_j_12_, v_00_u03b1_13_);
return v___x_14_;
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_Jet_UniqAlg_jmW___boxed(lean_object* v_V_15_, lean_object* v_inst_16_, lean_object* v_inst_17_, lean_object* v_n_18_, lean_object* v_E_19_, lean_object* v_j_20_, lean_object* v_00_u03b1_21_){
_start:
{
lean_object* v_res_22_; 
v_res_22_ = lp_tree_GlobalTheory_Jet_UniqAlg_jmW(v_V_15_, v_inst_16_, v_inst_17_, v_n_18_, v_E_19_, v_j_20_, v_00_u03b1_21_);
lean_dec(v_n_18_);
lean_dec(v_inst_17_);
lean_dec_ref(v_inst_16_);
return v_res_22_;
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_Jet_UniqAlg_mapArr___redArg___lam__0(lean_object* v_00_u03b9_23_, lean_object* v_00_u03b1_24_, lean_object* v___y_25_){
_start:
{
lean_object* v___x_26_; lean_object* v___x_27_; 
v___x_26_ = lean_alloc_closure((void*)(lp_mathlib_Function_eval), 4, 3);
lean_closure_set(v___x_26_, 0, lean_box(0));
lean_closure_set(v___x_26_, 1, lean_box(0));
lean_closure_set(v___x_26_, 2, v_00_u03b1_24_);
v___x_27_ = lp_mathlib_LinearMap_comp___redArg___lam__0(v___x_26_, v_00_u03b9_23_, v___y_25_);
return v___x_27_;
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_Jet_UniqAlg_mapArr___redArg(lean_object* v_inst_28_, lean_object* v_inst_29_, lean_object* v_00_u03b9_30_){
_start:
{
lean_object* v___f_31_; lean_object* v___x_32_; lean_object* v___f_33_; lean_object* v___x_34_; lean_object* v___f_35_; lean_object* v___f_36_; 
v___f_31_ = lean_alloc_closure((void*)(lp_tree_GlobalTheory_Jet_UniqAlg_mapArr___redArg___lam__0), 3, 1);
lean_closure_set(v___f_31_, 0, v_00_u03b9_30_);
v___x_32_ = lp_tree_Formalism_REAL_arrTo___redArg(v_inst_29_);
v___f_33_ = lean_alloc_closure((void*)(lp_mathlib_LinearMap_pi___redArg___lam__0), 3, 1);
lean_closure_set(v___f_33_, 0, v___f_31_);
v___x_34_ = lp_tree_Formalism_REAL_arrOf___redArg(v_inst_28_);
v___f_35_ = lean_alloc_closure((void*)(lp_mathlib_LinearMap_comp___redArg___lam__0), 3, 2);
lean_closure_set(v___f_35_, 0, v___x_34_);
lean_closure_set(v___f_35_, 1, v___f_33_);
v___f_36_ = lean_alloc_closure((void*)(lp_mathlib_LinearMap_comp___redArg___lam__0), 3, 2);
lean_closure_set(v___f_36_, 0, v___f_35_);
lean_closure_set(v___f_36_, 1, v___x_32_);
return v___f_36_;
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_Jet_UniqAlg_mapArr(lean_object* v_V_37_, lean_object* v_V_x27_38_, lean_object* v_inst_39_, lean_object* v_inst_40_, lean_object* v_inst_41_, lean_object* v_inst_42_, lean_object* v_00_u03b9_43_, lean_object* v_n_44_, lean_object* v_j_45_){
_start:
{
lean_object* v___x_46_; 
v___x_46_ = lp_tree_GlobalTheory_Jet_UniqAlg_mapArr___redArg(v_inst_39_, v_inst_41_, v_00_u03b9_43_);
return v___x_46_;
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_Jet_UniqAlg_mapArr___boxed(lean_object* v_V_47_, lean_object* v_V_x27_48_, lean_object* v_inst_49_, lean_object* v_inst_50_, lean_object* v_inst_51_, lean_object* v_inst_52_, lean_object* v_00_u03b9_53_, lean_object* v_n_54_, lean_object* v_j_55_){
_start:
{
lean_object* v_res_56_; 
v_res_56_ = lp_tree_GlobalTheory_Jet_UniqAlg_mapArr(v_V_47_, v_V_x27_48_, v_inst_49_, v_inst_50_, v_inst_51_, v_inst_52_, v_00_u03b9_53_, v_n_54_, v_j_55_);
lean_dec(v_j_55_);
lean_dec(v_n_54_);
lean_dec(v_inst_52_);
lean_dec(v_inst_50_);
return v_res_56_;
}
}
lean_object* initialize_Init(uint8_t builtin);
lean_object* initialize_Init(uint8_t builtin);
lean_object* initialize_mathlib_Mathlib(uint8_t builtin);
lean_object* initialize_tree_Development_AbelianVarietyTheory_Definitions_SemilocalFrames_ActSingleNeZero(uint8_t builtin);
lean_object* initialize_tree_Development_AbelianVarietyTheory_Statements_CuspFrameWeights_EigenfunctionFiniteCoefficients(uint8_t builtin);
lean_object* initialize_tree_Formalism_RealPlaceAnalysis_RealPlaceTaylor_FirstSlotSliceSlotMixedCasimirZero(uint8_t builtin);
lean_object* initialize_tree_Formalism_RealPlaceAnalysis_RealPlaceTaylor_IsCompactInvariantOrthogonalInf(uint8_t builtin);
lean_object* initialize_tree_Formalism_RealPlaceAnalysis_FinalF(uint8_t builtin);
lean_object* initialize_tree_Development_AbelianVarietyTheory_Proofs_FlagMeasures_SymmetricKMapEqZeroOfVminusSlicesStatement(uint8_t builtin);
static bool _G_initialized = false;
LEAN_EXPORT lean_object* initialize_tree_Development_AbelianVarietyTheory_Proofs_FlagMeasures_JetUniquenessAlgebraic(uint8_t builtin) {
lean_object * res;
if (_G_initialized) return lean_io_result_mk_ok(lean_box(0));
_G_initialized = true;
res = initialize_Init(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_Init(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_mathlib_Mathlib(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_Development_AbelianVarietyTheory_Definitions_SemilocalFrames_ActSingleNeZero(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_Development_AbelianVarietyTheory_Statements_CuspFrameWeights_EigenfunctionFiniteCoefficients(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_Formalism_RealPlaceAnalysis_RealPlaceTaylor_FirstSlotSliceSlotMixedCasimirZero(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_Formalism_RealPlaceAnalysis_RealPlaceTaylor_IsCompactInvariantOrthogonalInf(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_Formalism_RealPlaceAnalysis_FinalF(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_Development_AbelianVarietyTheory_Proofs_FlagMeasures_SymmetricKMapEqZeroOfVminusSlicesStatement(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
return lean_io_result_mk_ok(lean_box(0));
}
#ifdef __cplusplus
}
#endif
