// Lean compiler output
// Module: Formalism.SharpRestriction.ValuationFrobeniusEpsilon.GradedCompletionLemmas
// Imports: public import Init public meta import Init public import Mathlib public import Formalism.LocalRingCardinality.RhoDetPrimeEqMuTildeMulChiPow public import Formalism.SharpRestriction.ParConsts public import Formalism.SharpRestriction.ValuationFrobeniusEpsilon.InstLocalRingSymplecticCoefficients
#include <lean/lean.h>
#if defined(__clang__)
#pragma clang diagnostic ignored "-Wunused-parameter"
#pragma clang diagnostic ignored "-Wunused-label"
#elif defined(__GNUC__) && !defined(__CLANG__)
#pragma GCC diagnostic ignored "-Wunused-parameter"
#pragma GCC diagnostic ignored "-Wunused-label"
#pragma GCC diagnostic ignored "-Wunused-but-set-variable"
#endif
#ifdef __cplusplus
extern "C" {
#endif
lean_object* lean_nat_to_int(lean_object*);
lean_object* lean_int_mul(lean_object*, lean_object*);
lean_object* lp_mathlib_Multiset_map___redArg(lean_object*, lean_object*);
lean_object* lean_int_add(lean_object*, lean_object*);
lean_object* l_List_foldrTR___redArg(lean_object*, lean_object*, lean_object*);
uint8_t lean_int_dec_eq(lean_object*, lean_object*);
lean_object* l_List_finRange(lean_object*);
uint8_t lp_mathlib_Fintype_decidablePiFintype___redArg(lean_object*, lean_object*, lean_object*, lean_object*);
lean_object* lp_mathlib_instMulZeroClassOfSemiring___redArg(lean_object*);
lean_object* lp_mathlib_Field_toSemifield___redArg(lean_object*);
lean_object* lp_mathlib_Semifield_toDivisionSemiring___redArg(lean_object*);
lean_object* lp_mathlib_Matrix_addMonoid___redArg(lean_object*);
lean_object* lp_mathlib_instDistribOfSemiring___redArg(lean_object*);
lean_object* lp_mathlib_Field_toDivisionRing___redArg(lean_object*);
lean_object* lp_mathlib_Ring_toAddCommGroup___redArg(lean_object*);
lean_object* lp_mathlib_SubNegZeroMonoid_toNegZeroClass___redArg(lean_object*);
lean_object* lp_mathlib_Ring_toAddGroupWithOne___redArg(lean_object*);
lean_object* lp_mathlib_Monoid_toMulOneClass___redArg(lean_object*);
lean_object* l_Fin_succ___redArg(lean_object*);
lean_object* lean_nat_add(lean_object*, lean_object*);
lean_object* lp_mathlib_Fin_contractNth___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
lean_object* lean_nat_mod(lean_object*, lean_object*);
lean_object* lp_mathlib_Finset_sum___redArg(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_Formalism_MainNotions_UnusedSlot38_monoWt___redArg___lam__0(lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_Multiset_sum___at___00Finset_sum___at___00Finsupp_sum___at___00Formalism_MainNotions_UnusedSlot38_monoWt_spec__0_spec__0_spec__1___lam__0(lean_object*, lean_object*, lean_object*);
static lean_once_cell_t lp_tree_Multiset_sum___at___00Finset_sum___at___00Finsupp_sum___at___00Formalism_MainNotions_UnusedSlot38_monoWt_spec__0_spec__0_spec__1___lam__1___closed__0_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* lp_tree_Multiset_sum___at___00Finset_sum___at___00Finsupp_sum___at___00Formalism_MainNotions_UnusedSlot38_monoWt_spec__0_spec__0_spec__1___lam__1___closed__0;
LEAN_EXPORT lean_object* lp_tree_Multiset_sum___at___00Finset_sum___at___00Finsupp_sum___at___00Formalism_MainNotions_UnusedSlot38_monoWt_spec__0_spec__0_spec__1___lam__1(lean_object*);
LEAN_EXPORT lean_object* lp_tree_Multiset_sum___at___00Finset_sum___at___00Finsupp_sum___at___00Formalism_MainNotions_UnusedSlot38_monoWt_spec__0_spec__0_spec__1___lam__1___boxed(lean_object*);
static const lean_closure_object lp_tree_Multiset_sum___at___00Finset_sum___at___00Finsupp_sum___at___00Formalism_MainNotions_UnusedSlot38_monoWt_spec__0_spec__0_spec__1___closed__0_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_closure_object) + sizeof(void*)*0, .m_other = 0, .m_tag = 245}, .m_fun = (void*)lp_tree_Multiset_sum___at___00Finset_sum___at___00Finsupp_sum___at___00Formalism_MainNotions_UnusedSlot38_monoWt_spec__0_spec__0_spec__1___lam__0, .m_arity = 3, .m_num_fixed = 0, .m_objs = {} };
static const lean_object* lp_tree_Multiset_sum___at___00Finset_sum___at___00Finsupp_sum___at___00Formalism_MainNotions_UnusedSlot38_monoWt_spec__0_spec__0_spec__1___closed__0 = (const lean_object*)&lp_tree_Multiset_sum___at___00Finset_sum___at___00Finsupp_sum___at___00Formalism_MainNotions_UnusedSlot38_monoWt_spec__0_spec__0_spec__1___closed__0_value;
static const lean_closure_object lp_tree_Multiset_sum___at___00Finset_sum___at___00Finsupp_sum___at___00Formalism_MainNotions_UnusedSlot38_monoWt_spec__0_spec__0_spec__1___closed__1_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_closure_object) + sizeof(void*)*0, .m_other = 0, .m_tag = 245}, .m_fun = (void*)lp_tree_Multiset_sum___at___00Finset_sum___at___00Finsupp_sum___at___00Formalism_MainNotions_UnusedSlot38_monoWt_spec__0_spec__0_spec__1___lam__1___boxed, .m_arity = 1, .m_num_fixed = 0, .m_objs = {} };
static const lean_object* lp_tree_Multiset_sum___at___00Finset_sum___at___00Finsupp_sum___at___00Formalism_MainNotions_UnusedSlot38_monoWt_spec__0_spec__0_spec__1___closed__1 = (const lean_object*)&lp_tree_Multiset_sum___at___00Finset_sum___at___00Finsupp_sum___at___00Formalism_MainNotions_UnusedSlot38_monoWt_spec__0_spec__0_spec__1___closed__1_value;
LEAN_EXPORT lean_object* lp_tree_Multiset_sum___at___00Finset_sum___at___00Finsupp_sum___at___00Formalism_MainNotions_UnusedSlot38_monoWt_spec__0_spec__0_spec__1(lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_Finset_sum___at___00Finsupp_sum___at___00Formalism_MainNotions_UnusedSlot38_monoWt_spec__0_spec__0___redArg(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_Finsupp_sum___at___00Formalism_MainNotions_UnusedSlot38_monoWt_spec__0___redArg___lam__0(lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_Finsupp_sum___at___00Formalism_MainNotions_UnusedSlot38_monoWt_spec__0___redArg(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_Formalism_MainNotions_UnusedSlot38_monoWt___redArg(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_Formalism_MainNotions_UnusedSlot38_monoWt(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_Formalism_MainNotions_UnusedSlot38_monoWt___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_Finsupp_sum___at___00Formalism_MainNotions_UnusedSlot38_monoWt_spec__0(lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_Finset_sum___at___00Finsupp_sum___at___00Formalism_MainNotions_UnusedSlot38_monoWt_spec__0_spec__0(lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_Formalism_MainNotions_UnusedSlot38_Pj(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_Formalism_MainNotions_UnusedSlot38_Pj___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_Formalism_MainNotions_UnusedSlot38_Psub(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_Formalism_MainNotions_UnusedSlot38_Psub___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_Formalism_MainNotions_UnusedSlot38_P0sub(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_Formalism_MainNotions_UnusedSlot38_P0sub___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT uint8_t lp_tree_Formalism_MainNotions_UnusedSlot38_comp___redArg___lam__0(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_Formalism_MainNotions_UnusedSlot38_comp___redArg___lam__0___boxed(lean_object*, lean_object*, lean_object*);
static const lean_closure_object lp_tree_Formalism_MainNotions_UnusedSlot38_comp___redArg___closed__0_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_closure_object) + sizeof(void*)*0, .m_other = 0, .m_tag = 245}, .m_fun = (void*)lp_tree_Formalism_MainNotions_UnusedSlot38_comp___redArg___lam__0___boxed, .m_arity = 3, .m_num_fixed = 0, .m_objs = {} };
static const lean_object* lp_tree_Formalism_MainNotions_UnusedSlot38_comp___redArg___closed__0 = (const lean_object*)&lp_tree_Formalism_MainNotions_UnusedSlot38_comp___redArg___closed__0_value;
LEAN_EXPORT lean_object* lp_tree_Formalism_MainNotions_UnusedSlot38_comp___redArg(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_Formalism_MainNotions_UnusedSlot38_comp(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_Formalism_MainNotions_UnusedSlot38_dC___redArg___lam__0(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_Formalism_MainNotions_UnusedSlot38_dC___redArg___lam__1(lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_Formalism_MainNotions_UnusedSlot38_dC___redArg___lam__1___boxed(lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_Formalism_MainNotions_UnusedSlot38_dC___redArg___lam__2(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_Formalism_MainNotions_UnusedSlot38_dC___redArg___lam__2___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_Formalism_MainNotions_UnusedSlot38_dC___redArg___lam__3(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_Formalism_MainNotions_UnusedSlot38_dC___redArg___lam__3___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_Formalism_MainNotions_UnusedSlot38_dC___redArg(lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_Formalism_MainNotions_UnusedSlot38_dC___redArg___boxed(lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_Formalism_MainNotions_UnusedSlot38_dC(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_Formalism_MainNotions_UnusedSlot38_dC___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_Formalism_MainNotions_UnusedSlot38_CochSub(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_Formalism_MainNotions_UnusedSlot38_CochSub___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_Formalism_MainNotions_UnusedSlot38_wtSub(lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_Formalism_MainNotions_UnusedSlot38_wtSub___boxed(lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_Formalism_MainNotions_UnusedSlot38_bSub(lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_Formalism_MainNotions_UnusedSlot38_bSub___boxed(lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_Formalism_MainNotions_UnusedSlot38_nSub(lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_Formalism_MainNotions_UnusedSlot38_nSub___boxed(lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_Formalism_MainNotions_UnusedSlot38_dimb(uint8_t);
LEAN_EXPORT lean_object* lp_tree_Formalism_MainNotions_UnusedSlot38_dimb___boxed(lean_object*);
LEAN_EXPORT lean_object* lp_tree_Subgroup_subtype___at___00Formalism_MainNotions_UnusedSlot38_kerAbL_spec__0___lam__0(lean_object*);
LEAN_EXPORT lean_object* lp_tree_Subgroup_subtype___at___00Formalism_MainNotions_UnusedSlot38_kerAbL_spec__0___lam__0___boxed(lean_object*);
static const lean_closure_object lp_tree_Subgroup_subtype___at___00Formalism_MainNotions_UnusedSlot38_kerAbL_spec__0___closed__0_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_closure_object) + sizeof(void*)*0, .m_other = 0, .m_tag = 245}, .m_fun = (void*)lp_tree_Subgroup_subtype___at___00Formalism_MainNotions_UnusedSlot38_kerAbL_spec__0___lam__0___boxed, .m_arity = 1, .m_num_fixed = 0, .m_objs = {} };
static const lean_object* lp_tree_Subgroup_subtype___at___00Formalism_MainNotions_UnusedSlot38_kerAbL_spec__0___closed__0 = (const lean_object*)&lp_tree_Subgroup_subtype___at___00Formalism_MainNotions_UnusedSlot38_kerAbL_spec__0___closed__0_value;
LEAN_EXPORT lean_object* lp_tree_Subgroup_subtype___at___00Formalism_MainNotions_UnusedSlot38_kerAbL_spec__0(lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_Subgroup_subtype___at___00Formalism_MainNotions_UnusedSlot38_kerAbL_spec__0___boxed(lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_Subgroup_map___at___00Formalism_MainNotions_UnusedSlot38_kerAbL_spec__4(lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_Subgroup_map___at___00Formalism_MainNotions_UnusedSlot38_kerAbL_spec__4___boxed(lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_Submonoid_copy___at___00iInf___at___00Formalism_MainNotions_UnusedSlot38_kerAbL_spec__3_spec__7(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_Submonoid_copy___at___00iInf___at___00Formalism_MainNotions_UnusedSlot38_kerAbL_spec__3_spec__7___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_iInf___at___00iInf___at___00Formalism_MainNotions_UnusedSlot38_kerAbL_spec__3_spec__5(lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_iInf___at___00iInf___at___00Formalism_MainNotions_UnusedSlot38_kerAbL_spec__3_spec__5___boxed(lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_iInf___at___00Formalism_MainNotions_UnusedSlot38_kerAbL_spec__3___redArg___lam__0(lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_iInf___at___00Formalism_MainNotions_UnusedSlot38_kerAbL_spec__3___redArg___lam__1(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_iInf___at___00Formalism_MainNotions_UnusedSlot38_kerAbL_spec__3___redArg___lam__1___boxed(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_iInf___at___00iInf___at___00Formalism_MainNotions_UnusedSlot38_kerAbL_spec__3_spec__6(lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_iInf___at___00iInf___at___00Formalism_MainNotions_UnusedSlot38_kerAbL_spec__3_spec__6___boxed(lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_iInf___at___00Formalism_MainNotions_UnusedSlot38_kerAbL_spec__3___redArg(lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_iInf___at___00Formalism_MainNotions_UnusedSlot38_kerAbL_spec__3___redArg___boxed(lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_Formalism_MainNotions_UnusedSlot38_kerAbL(lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_Formalism_MainNotions_UnusedSlot38_kerAbL___boxed(lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_MulHomClass_toMulHom___at___00MonoidHomClass_toMonoidHom___at___00Formalism_MainNotions_UnusedSlot38_kerAbL_spec__1_spec__1___redArg___lam__0(lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_MulHomClass_toMulHom___at___00MonoidHomClass_toMonoidHom___at___00Formalism_MainNotions_UnusedSlot38_kerAbL_spec__1_spec__1___redArg(lean_object*);
LEAN_EXPORT lean_object* lp_tree_MulHomClass_toMulHom___at___00MonoidHomClass_toMonoidHom___at___00Formalism_MainNotions_UnusedSlot38_kerAbL_spec__1_spec__1(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_MulHomClass_toMulHom___at___00MonoidHomClass_toMonoidHom___at___00Formalism_MainNotions_UnusedSlot38_kerAbL_spec__1_spec__1___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_MonoidHomClass_toMonoidHom___at___00Formalism_MainNotions_UnusedSlot38_kerAbL_spec__1___redArg(lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_MonoidHomClass_toMonoidHom___at___00Formalism_MainNotions_UnusedSlot38_kerAbL_spec__1___redArg___boxed(lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_MonoidHomClass_toMonoidHom___at___00Formalism_MainNotions_UnusedSlot38_kerAbL_spec__1(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_MonoidHomClass_toMonoidHom___at___00Formalism_MainNotions_UnusedSlot38_kerAbL_spec__1___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_Submonoid_comap___at___00MonoidHom_mker___at___00MonoidHom_ker___at___00Formalism_MainNotions_UnusedSlot38_kerAbL_spec__2_spec__3_spec__5(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_Submonoid_comap___at___00MonoidHom_mker___at___00MonoidHom_ker___at___00Formalism_MainNotions_UnusedSlot38_kerAbL_spec__2_spec__3_spec__5___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_MonoidHom_mker___at___00MonoidHom_ker___at___00Formalism_MainNotions_UnusedSlot38_kerAbL_spec__2_spec__3___redArg(lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_MonoidHom_mker___at___00MonoidHom_ker___at___00Formalism_MainNotions_UnusedSlot38_kerAbL_spec__2_spec__3___redArg___boxed(lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_MonoidHom_ker___at___00Formalism_MainNotions_UnusedSlot38_kerAbL_spec__2(lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_MonoidHom_ker___at___00Formalism_MainNotions_UnusedSlot38_kerAbL_spec__2___boxed(lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_iInf___at___00Formalism_MainNotions_UnusedSlot38_kerAbL_spec__3(lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_iInf___at___00Formalism_MainNotions_UnusedSlot38_kerAbL_spec__3___boxed(lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_MonoidHom_mker___at___00MonoidHom_ker___at___00Formalism_MainNotions_UnusedSlot38_kerAbL_spec__2_spec__3(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_MonoidHom_mker___at___00MonoidHom_ker___at___00Formalism_MainNotions_UnusedSlot38_kerAbL_spec__2_spec__3___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_Formalism_MainNotions_UnusedSlot38_CochG(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_Formalism_MainNotions_UnusedSlot38_CochG___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_Formalism_MainNotions_UnusedSlot38_monoWt___redArg___lam__0(lean_object* v_wt_1_, lean_object* v_i_2_, lean_object* v_e_3_, lean_object* v___y_4_){
_start:
{
lean_object* v___x_5_; lean_object* v___x_6_; lean_object* v___x_7_; 
v___x_5_ = lean_nat_to_int(v_e_3_);
v___x_6_ = lean_apply_2(v_wt_1_, v_i_2_, v___y_4_);
v___x_7_ = lean_int_mul(v___x_5_, v___x_6_);
lean_dec(v___x_6_);
lean_dec(v___x_5_);
return v___x_7_;
}
}
LEAN_EXPORT lean_object* lp_tree_Multiset_sum___at___00Finset_sum___at___00Finsupp_sum___at___00Formalism_MainNotions_UnusedSlot38_monoWt_spec__0_spec__0_spec__1___lam__0(lean_object* v_x1_8_, lean_object* v_x2_9_, lean_object* v___y_10_){
_start:
{
lean_object* v___x_11_; lean_object* v___x_12_; lean_object* v___x_13_; 
lean_inc(v___y_10_);
v___x_11_ = lean_apply_1(v_x1_8_, v___y_10_);
v___x_12_ = lean_apply_1(v_x2_9_, v___y_10_);
v___x_13_ = lean_int_add(v___x_11_, v___x_12_);
lean_dec(v___x_12_);
lean_dec(v___x_11_);
return v___x_13_;
}
}
static lean_object* _init_lp_tree_Multiset_sum___at___00Finset_sum___at___00Finsupp_sum___at___00Formalism_MainNotions_UnusedSlot38_monoWt_spec__0_spec__0_spec__1___lam__1___closed__0(void){
_start:
{
lean_object* v___x_14_; lean_object* v___x_15_; 
v___x_14_ = lean_unsigned_to_nat(0u);
v___x_15_ = lean_nat_to_int(v___x_14_);
return v___x_15_;
}
}
LEAN_EXPORT lean_object* lp_tree_Multiset_sum___at___00Finset_sum___at___00Finsupp_sum___at___00Formalism_MainNotions_UnusedSlot38_monoWt_spec__0_spec__0_spec__1___lam__1(lean_object* v_x_16_){
_start:
{
lean_object* v___x_17_; 
v___x_17_ = lean_obj_once(&lp_tree_Multiset_sum___at___00Finset_sum___at___00Finsupp_sum___at___00Formalism_MainNotions_UnusedSlot38_monoWt_spec__0_spec__0_spec__1___lam__1___closed__0, &lp_tree_Multiset_sum___at___00Finset_sum___at___00Finsupp_sum___at___00Formalism_MainNotions_UnusedSlot38_monoWt_spec__0_spec__0_spec__1___lam__1___closed__0_once, _init_lp_tree_Multiset_sum___at___00Finset_sum___at___00Finsupp_sum___at___00Formalism_MainNotions_UnusedSlot38_monoWt_spec__0_spec__0_spec__1___lam__1___closed__0);
return v___x_17_;
}
}
LEAN_EXPORT lean_object* lp_tree_Multiset_sum___at___00Finset_sum___at___00Finsupp_sum___at___00Formalism_MainNotions_UnusedSlot38_monoWt_spec__0_spec__0_spec__1___lam__1___boxed(lean_object* v_x_18_){
_start:
{
lean_object* v_res_19_; 
v_res_19_ = lp_tree_Multiset_sum___at___00Finset_sum___at___00Finsupp_sum___at___00Formalism_MainNotions_UnusedSlot38_monoWt_spec__0_spec__0_spec__1___lam__1(v_x_18_);
lean_dec(v_x_18_);
return v_res_19_;
}
}
LEAN_EXPORT lean_object* lp_tree_Multiset_sum___at___00Finset_sum___at___00Finsupp_sum___at___00Formalism_MainNotions_UnusedSlot38_monoWt_spec__0_spec__0_spec__1(lean_object* v_s_22_, lean_object* v___y_23_){
_start:
{
lean_object* v___f_24_; lean_object* v___f_25_; lean_object* v___x_342__overap_26_; lean_object* v___x_27_; 
v___f_24_ = ((lean_object*)(lp_tree_Multiset_sum___at___00Finset_sum___at___00Finsupp_sum___at___00Formalism_MainNotions_UnusedSlot38_monoWt_spec__0_spec__0_spec__1___closed__0));
v___f_25_ = ((lean_object*)(lp_tree_Multiset_sum___at___00Finset_sum___at___00Finsupp_sum___at___00Formalism_MainNotions_UnusedSlot38_monoWt_spec__0_spec__0_spec__1___closed__1));
v___x_342__overap_26_ = l_List_foldrTR___redArg(v___f_24_, v___f_25_, v_s_22_);
v___x_27_ = lean_apply_1(v___x_342__overap_26_, v___y_23_);
return v___x_27_;
}
}
LEAN_EXPORT lean_object* lp_tree_Finset_sum___at___00Finsupp_sum___at___00Formalism_MainNotions_UnusedSlot38_monoWt_spec__0_spec__0___redArg(lean_object* v_s_28_, lean_object* v_f_29_, lean_object* v___y_30_){
_start:
{
lean_object* v___x_31_; lean_object* v___x_32_; 
v___x_31_ = lp_mathlib_Multiset_map___redArg(v_f_29_, v_s_28_);
v___x_32_ = lp_tree_Multiset_sum___at___00Finset_sum___at___00Finsupp_sum___at___00Formalism_MainNotions_UnusedSlot38_monoWt_spec__0_spec__0_spec__1(v___x_31_, v___y_30_);
return v___x_32_;
}
}
LEAN_EXPORT lean_object* lp_tree_Finsupp_sum___at___00Formalism_MainNotions_UnusedSlot38_monoWt_spec__0___redArg___lam__0(lean_object* v_toFun_33_, lean_object* v_g_34_, lean_object* v_a_35_, lean_object* v___y_36_){
_start:
{
lean_object* v___x_37_; lean_object* v___x_38_; 
lean_inc(v_a_35_);
v___x_37_ = lean_apply_1(v_toFun_33_, v_a_35_);
v___x_38_ = lean_apply_3(v_g_34_, v_a_35_, v___x_37_, v___y_36_);
return v___x_38_;
}
}
LEAN_EXPORT lean_object* lp_tree_Finsupp_sum___at___00Formalism_MainNotions_UnusedSlot38_monoWt_spec__0___redArg(lean_object* v_f_39_, lean_object* v_g_40_, lean_object* v___y_41_){
_start:
{
lean_object* v_support_42_; lean_object* v_toFun_43_; lean_object* v___f_44_; lean_object* v___x_45_; 
v_support_42_ = lean_ctor_get(v_f_39_, 0);
lean_inc(v_support_42_);
v_toFun_43_ = lean_ctor_get(v_f_39_, 1);
lean_inc(v_toFun_43_);
lean_dec_ref(v_f_39_);
v___f_44_ = lean_alloc_closure((void*)(lp_tree_Finsupp_sum___at___00Formalism_MainNotions_UnusedSlot38_monoWt_spec__0___redArg___lam__0), 4, 2);
lean_closure_set(v___f_44_, 0, v_toFun_43_);
lean_closure_set(v___f_44_, 1, v_g_40_);
v___x_45_ = lp_tree_Finset_sum___at___00Finsupp_sum___at___00Formalism_MainNotions_UnusedSlot38_monoWt_spec__0_spec__0___redArg(v_support_42_, v___f_44_, v___y_41_);
return v___x_45_;
}
}
LEAN_EXPORT lean_object* lp_tree_Formalism_MainNotions_UnusedSlot38_monoWt___redArg(lean_object* v_wt_46_, lean_object* v_m_47_, lean_object* v_a_48_){
_start:
{
lean_object* v___f_49_; lean_object* v___x_50_; 
v___f_49_ = lean_alloc_closure((void*)(lp_tree_Formalism_MainNotions_UnusedSlot38_monoWt___redArg___lam__0), 4, 1);
lean_closure_set(v___f_49_, 0, v_wt_46_);
v___x_50_ = lp_tree_Finsupp_sum___at___00Formalism_MainNotions_UnusedSlot38_monoWt_spec__0___redArg(v_m_47_, v___f_49_, v_a_48_);
return v___x_50_;
}
}
LEAN_EXPORT lean_object* lp_tree_Formalism_MainNotions_UnusedSlot38_monoWt(lean_object* v_a_51_, lean_object* v_rk_52_, lean_object* v_wt_53_, lean_object* v_m_54_, lean_object* v_a_55_){
_start:
{
lean_object* v___x_56_; 
v___x_56_ = lp_tree_Formalism_MainNotions_UnusedSlot38_monoWt___redArg(v_wt_53_, v_m_54_, v_a_55_);
return v___x_56_;
}
}
LEAN_EXPORT lean_object* lp_tree_Formalism_MainNotions_UnusedSlot38_monoWt___boxed(lean_object* v_a_57_, lean_object* v_rk_58_, lean_object* v_wt_59_, lean_object* v_m_60_, lean_object* v_a_61_){
_start:
{
lean_object* v_res_62_; 
v_res_62_ = lp_tree_Formalism_MainNotions_UnusedSlot38_monoWt(v_a_57_, v_rk_58_, v_wt_59_, v_m_60_, v_a_61_);
lean_dec(v_rk_58_);
lean_dec(v_a_57_);
return v_res_62_;
}
}
LEAN_EXPORT lean_object* lp_tree_Finsupp_sum___at___00Formalism_MainNotions_UnusedSlot38_monoWt_spec__0(lean_object* v_00_u03b1_63_, lean_object* v_f_64_, lean_object* v_g_65_, lean_object* v___y_66_){
_start:
{
lean_object* v___x_67_; 
v___x_67_ = lp_tree_Finsupp_sum___at___00Formalism_MainNotions_UnusedSlot38_monoWt_spec__0___redArg(v_f_64_, v_g_65_, v___y_66_);
return v___x_67_;
}
}
LEAN_EXPORT lean_object* lp_tree_Finset_sum___at___00Finsupp_sum___at___00Formalism_MainNotions_UnusedSlot38_monoWt_spec__0_spec__0(lean_object* v_00_u03b9_68_, lean_object* v_s_69_, lean_object* v_f_70_, lean_object* v___y_71_){
_start:
{
lean_object* v___x_72_; 
v___x_72_ = lp_tree_Finset_sum___at___00Finsupp_sum___at___00Formalism_MainNotions_UnusedSlot38_monoWt_spec__0_spec__0___redArg(v_s_69_, v_f_70_, v___y_71_);
return v___x_72_;
}
}
LEAN_EXPORT lean_object* lp_tree_Formalism_MainNotions_UnusedSlot38_Pj(lean_object* v_O_73_, lean_object* v_inst_74_, lean_object* v_a_75_, lean_object* v_rk_76_, lean_object* v_wt_77_, lean_object* v_j_78_){
_start:
{
lean_object* v___x_79_; 
v___x_79_ = lean_box(0);
return v___x_79_;
}
}
LEAN_EXPORT lean_object* lp_tree_Formalism_MainNotions_UnusedSlot38_Pj___boxed(lean_object* v_O_80_, lean_object* v_inst_81_, lean_object* v_a_82_, lean_object* v_rk_83_, lean_object* v_wt_84_, lean_object* v_j_85_){
_start:
{
lean_object* v_res_86_; 
v_res_86_ = lp_tree_Formalism_MainNotions_UnusedSlot38_Pj(v_O_80_, v_inst_81_, v_a_82_, v_rk_83_, v_wt_84_, v_j_85_);
lean_dec_ref(v_j_85_);
lean_dec_ref(v_wt_84_);
lean_dec(v_rk_83_);
lean_dec(v_a_82_);
lean_dec_ref(v_inst_81_);
return v_res_86_;
}
}
LEAN_EXPORT lean_object* lp_tree_Formalism_MainNotions_UnusedSlot38_Psub(lean_object* v_O_87_, lean_object* v_inst_88_, lean_object* v_a_89_, lean_object* v_rk_90_, lean_object* v_wt_91_){
_start:
{
lean_object* v___x_92_; 
v___x_92_ = lean_box(0);
return v___x_92_;
}
}
LEAN_EXPORT lean_object* lp_tree_Formalism_MainNotions_UnusedSlot38_Psub___boxed(lean_object* v_O_93_, lean_object* v_inst_94_, lean_object* v_a_95_, lean_object* v_rk_96_, lean_object* v_wt_97_){
_start:
{
lean_object* v_res_98_; 
v_res_98_ = lp_tree_Formalism_MainNotions_UnusedSlot38_Psub(v_O_93_, v_inst_94_, v_a_95_, v_rk_96_, v_wt_97_);
lean_dec_ref(v_wt_97_);
lean_dec(v_rk_96_);
lean_dec(v_a_95_);
lean_dec_ref(v_inst_94_);
return v_res_98_;
}
}
LEAN_EXPORT lean_object* lp_tree_Formalism_MainNotions_UnusedSlot38_P0sub(lean_object* v_O_99_, lean_object* v_inst_100_, lean_object* v_a_101_, lean_object* v_rk_102_, lean_object* v_wt_103_){
_start:
{
lean_object* v___x_104_; 
v___x_104_ = lean_box(0);
return v___x_104_;
}
}
LEAN_EXPORT lean_object* lp_tree_Formalism_MainNotions_UnusedSlot38_P0sub___boxed(lean_object* v_O_105_, lean_object* v_inst_106_, lean_object* v_a_107_, lean_object* v_rk_108_, lean_object* v_wt_109_){
_start:
{
lean_object* v_res_110_; 
v_res_110_ = lp_tree_Formalism_MainNotions_UnusedSlot38_P0sub(v_O_105_, v_inst_106_, v_a_107_, v_rk_108_, v_wt_109_);
lean_dec_ref(v_wt_109_);
lean_dec(v_rk_108_);
lean_dec(v_a_107_);
lean_dec_ref(v_inst_106_);
return v_res_110_;
}
}
LEAN_EXPORT uint8_t lp_tree_Formalism_MainNotions_UnusedSlot38_comp___redArg___lam__0(lean_object* v_a_111_, lean_object* v___y_112_, lean_object* v___y_113_){
_start:
{
uint8_t v___x_114_; 
v___x_114_ = lean_int_dec_eq(v___y_112_, v___y_113_);
return v___x_114_;
}
}
LEAN_EXPORT lean_object* lp_tree_Formalism_MainNotions_UnusedSlot38_comp___redArg___lam__0___boxed(lean_object* v_a_115_, lean_object* v___y_116_, lean_object* v___y_117_){
_start:
{
uint8_t v_res_118_; lean_object* v_r_119_; 
v_res_118_ = lp_tree_Formalism_MainNotions_UnusedSlot38_comp___redArg___lam__0(v_a_115_, v___y_116_, v___y_117_);
lean_dec(v___y_117_);
lean_dec(v___y_116_);
lean_dec(v_a_115_);
v_r_119_ = lean_box(v_res_118_);
return v_r_119_;
}
}
LEAN_EXPORT lean_object* lp_tree_Formalism_MainNotions_UnusedSlot38_comp___redArg(lean_object* v_inst_121_, lean_object* v_a_122_, lean_object* v_rk_123_, lean_object* v_wt_124_, lean_object* v_j_125_, lean_object* v_f_126_, lean_object* v_m_127_){
_start:
{
lean_object* v___f_128_; lean_object* v___x_129_; lean_object* v___x_130_; uint8_t v___x_131_; 
v___f_128_ = ((lean_object*)(lp_tree_Formalism_MainNotions_UnusedSlot38_comp___redArg___closed__0));
lean_inc(v_rk_123_);
v___x_129_ = l_List_finRange(v_rk_123_);
lean_inc_ref(v_m_127_);
v___x_130_ = lean_alloc_closure((void*)(lp_tree_Formalism_MainNotions_UnusedSlot38_monoWt___boxed), 5, 4);
lean_closure_set(v___x_130_, 0, v_a_122_);
lean_closure_set(v___x_130_, 1, v_rk_123_);
lean_closure_set(v___x_130_, 2, v_wt_124_);
lean_closure_set(v___x_130_, 3, v_m_127_);
v___x_131_ = lp_mathlib_Fintype_decidablePiFintype___redArg(v___f_128_, v___x_129_, v___x_130_, v_j_125_);
if (v___x_131_ == 0)
{
lean_object* v_toSemiring_132_; lean_object* v___x_133_; lean_object* v_toZero_134_; 
lean_dec_ref(v_m_127_);
lean_dec(v_f_126_);
v_toSemiring_132_ = lean_ctor_get(v_inst_121_, 0);
lean_inc_ref(v_toSemiring_132_);
lean_dec_ref(v_inst_121_);
v___x_133_ = lp_mathlib_instMulZeroClassOfSemiring___redArg(v_toSemiring_132_);
v_toZero_134_ = lean_ctor_get(v___x_133_, 1);
lean_inc(v_toZero_134_);
lean_dec_ref(v___x_133_);
return v_toZero_134_;
}
else
{
lean_object* v___x_135_; 
lean_dec_ref(v_inst_121_);
v___x_135_ = lean_apply_1(v_f_126_, v_m_127_);
return v___x_135_;
}
}
}
LEAN_EXPORT lean_object* lp_tree_Formalism_MainNotions_UnusedSlot38_comp(lean_object* v_O_136_, lean_object* v_inst_137_, lean_object* v_a_138_, lean_object* v_rk_139_, lean_object* v_wt_140_, lean_object* v_j_141_, lean_object* v_f_142_, lean_object* v_m_143_){
_start:
{
lean_object* v___x_144_; 
v___x_144_ = lp_tree_Formalism_MainNotions_UnusedSlot38_comp___redArg(v_inst_137_, v_a_138_, v_rk_139_, v_wt_140_, v_j_141_, v_f_142_, v_m_143_);
return v___x_144_;
}
}
LEAN_EXPORT lean_object* lp_tree_Formalism_MainNotions_UnusedSlot38_dC___redArg___lam__0(lean_object* v_toMul_145_, lean_object* v_x1_146_, lean_object* v_x2_147_){
_start:
{
lean_object* v___x_148_; 
v___x_148_ = lean_apply_2(v_toMul_145_, v_x1_146_, v_x2_147_);
return v___x_148_;
}
}
LEAN_EXPORT lean_object* lp_tree_Formalism_MainNotions_UnusedSlot38_dC___redArg___lam__1(lean_object* v_x_149_, lean_object* v_i_150_){
_start:
{
lean_object* v___x_151_; lean_object* v___x_152_; 
v___x_151_ = l_Fin_succ___redArg(v_i_150_);
v___x_152_ = lean_apply_1(v_x_149_, v___x_151_);
return v___x_152_;
}
}
LEAN_EXPORT lean_object* lp_tree_Formalism_MainNotions_UnusedSlot38_dC___redArg___lam__1___boxed(lean_object* v_x_153_, lean_object* v_i_154_){
_start:
{
lean_object* v_res_155_; 
v_res_155_ = lp_tree_Formalism_MainNotions_UnusedSlot38_dC___redArg___lam__1(v_x_153_, v_i_154_);
lean_dec(v_i_154_);
return v_res_155_;
}
}
LEAN_EXPORT lean_object* lp_tree_Formalism_MainNotions_UnusedSlot38_dC___redArg___lam__2(lean_object* v_toNeg_156_, lean_object* v_toOne_157_, lean_object* v___x_158_, lean_object* v_toNPow_159_, lean_object* v_m_160_, lean_object* v___f_161_, lean_object* v_x_162_, lean_object* v_c_163_, lean_object* v_toMul_164_, lean_object* v_j_165_, lean_object* v___y_166_, lean_object* v___y_167_){
_start:
{
lean_object* v___x_168_; lean_object* v___x_169_; lean_object* v___x_170_; lean_object* v___x_171_; lean_object* v___x_172_; lean_object* v___x_173_; 
v___x_168_ = lean_apply_1(v_toNeg_156_, v_toOne_157_);
v___x_169_ = lean_nat_add(v_j_165_, v___x_158_);
v___x_170_ = lean_apply_2(v_toNPow_159_, v___x_169_, v___x_168_);
v___x_171_ = lean_alloc_closure((void*)(lp_mathlib_Fin_contractNth___boxed), 6, 5);
lean_closure_set(v___x_171_, 0, v_m_160_);
lean_closure_set(v___x_171_, 1, lean_box(0));
lean_closure_set(v___x_171_, 2, v_j_165_);
lean_closure_set(v___x_171_, 3, v___f_161_);
lean_closure_set(v___x_171_, 4, v_x_162_);
v___x_172_ = lean_apply_3(v_c_163_, v___x_171_, v___y_166_, v___y_167_);
v___x_173_ = lean_apply_2(v_toMul_164_, v___x_170_, v___x_172_);
return v___x_173_;
}
}
LEAN_EXPORT lean_object* lp_tree_Formalism_MainNotions_UnusedSlot38_dC___redArg___lam__2___boxed(lean_object* v_toNeg_174_, lean_object* v_toOne_175_, lean_object* v___x_176_, lean_object* v_toNPow_177_, lean_object* v_m_178_, lean_object* v___f_179_, lean_object* v_x_180_, lean_object* v_c_181_, lean_object* v_toMul_182_, lean_object* v_j_183_, lean_object* v___y_184_, lean_object* v___y_185_){
_start:
{
lean_object* v_res_186_; 
v_res_186_ = lp_tree_Formalism_MainNotions_UnusedSlot38_dC___redArg___lam__2(v_toNeg_174_, v_toOne_175_, v___x_176_, v_toNPow_177_, v_m_178_, v___f_179_, v_x_180_, v_c_181_, v_toMul_182_, v_j_183_, v___y_184_, v___y_185_);
lean_dec(v___x_176_);
return v_res_186_;
}
}
LEAN_EXPORT lean_object* lp_tree_Formalism_MainNotions_UnusedSlot38_dC___redArg___lam__3(lean_object* v_toNeg_187_, lean_object* v_toOne_188_, lean_object* v_toNPow_189_, lean_object* v_m_190_, lean_object* v___f_191_, lean_object* v_toMul_192_, lean_object* v_act_193_, lean_object* v___x_194_, lean_object* v_toAdd_195_, lean_object* v_c_196_, lean_object* v_x_197_, lean_object* v___y_198_, lean_object* v___y_199_){
_start:
{
lean_object* v___f_200_; lean_object* v___x_201_; lean_object* v___f_202_; lean_object* v___x_203_; lean_object* v___x_204_; lean_object* v___x_205_; lean_object* v___x_206_; lean_object* v___x_207_; lean_object* v___x_208_; lean_object* v___x_209_; lean_object* v___x_928__overap_210_; lean_object* v___x_211_; lean_object* v___x_212_; 
lean_inc_n(v_x_197_, 2);
v___f_200_ = lean_alloc_closure((void*)(lp_tree_Formalism_MainNotions_UnusedSlot38_dC___redArg___lam__1___boxed), 2, 1);
lean_closure_set(v___f_200_, 0, v_x_197_);
v___x_201_ = lean_unsigned_to_nat(1u);
lean_inc(v_c_196_);
lean_inc(v_m_190_);
v___f_202_ = lean_alloc_closure((void*)(lp_tree_Formalism_MainNotions_UnusedSlot38_dC___redArg___lam__2___boxed), 12, 9);
lean_closure_set(v___f_202_, 0, v_toNeg_187_);
lean_closure_set(v___f_202_, 1, v_toOne_188_);
lean_closure_set(v___f_202_, 2, v___x_201_);
lean_closure_set(v___f_202_, 3, v_toNPow_189_);
lean_closure_set(v___f_202_, 4, v_m_190_);
lean_closure_set(v___f_202_, 5, v___f_191_);
lean_closure_set(v___f_202_, 6, v_x_197_);
lean_closure_set(v___f_202_, 7, v_c_196_);
lean_closure_set(v___f_202_, 8, v_toMul_192_);
v___x_203_ = lean_nat_add(v_m_190_, v___x_201_);
lean_dec(v_m_190_);
v___x_204_ = lean_unsigned_to_nat(0u);
v___x_205_ = lean_nat_mod(v___x_204_, v___x_203_);
v___x_206_ = lean_apply_1(v_x_197_, v___x_205_);
v___x_207_ = lean_apply_1(v_c_196_, v___f_200_);
v___x_208_ = l_List_finRange(v___x_203_);
lean_inc(v___y_199_);
lean_inc(v___y_198_);
v___x_209_ = lean_apply_4(v_act_193_, v___x_206_, v___x_207_, v___y_198_, v___y_199_);
v___x_928__overap_210_ = lp_mathlib_Finset_sum___redArg(v___x_194_, v___x_208_, v___f_202_);
v___x_211_ = lean_apply_2(v___x_928__overap_210_, v___y_198_, v___y_199_);
v___x_212_ = lean_apply_2(v_toAdd_195_, v___x_209_, v___x_211_);
return v___x_212_;
}
}
LEAN_EXPORT lean_object* lp_tree_Formalism_MainNotions_UnusedSlot38_dC___redArg___lam__3___boxed(lean_object* v_toNeg_213_, lean_object* v_toOne_214_, lean_object* v_toNPow_215_, lean_object* v_m_216_, lean_object* v___f_217_, lean_object* v_toMul_218_, lean_object* v_act_219_, lean_object* v___x_220_, lean_object* v_toAdd_221_, lean_object* v_c_222_, lean_object* v_x_223_, lean_object* v___y_224_, lean_object* v___y_225_){
_start:
{
lean_object* v_res_226_; 
v_res_226_ = lp_tree_Formalism_MainNotions_UnusedSlot38_dC___redArg___lam__3(v_toNeg_213_, v_toOne_214_, v_toNPow_215_, v_m_216_, v___f_217_, v_toMul_218_, v_act_219_, v___x_220_, v_toAdd_221_, v_c_222_, v_x_223_, v___y_224_, v___y_225_);
lean_dec_ref(v___x_220_);
return v_res_226_;
}
}
LEAN_EXPORT lean_object* lp_tree_Formalism_MainNotions_UnusedSlot38_dC___redArg(lean_object* v_inst_227_, lean_object* v_inst_228_, lean_object* v_act_229_, lean_object* v_m_230_){
_start:
{
lean_object* v___x_231_; lean_object* v___x_232_; lean_object* v_toSemiring_233_; lean_object* v_toAddCommMonoid_234_; lean_object* v_toMonoid_235_; lean_object* v___x_236_; lean_object* v___x_237_; lean_object* v_toMul_238_; lean_object* v_toAdd_239_; lean_object* v_toNPow_240_; lean_object* v___x_241_; lean_object* v_toRing_242_; lean_object* v___x_243_; lean_object* v___x_244_; lean_object* v_toNeg_245_; lean_object* v___x_246_; lean_object* v_toAddMonoidWithOne_247_; lean_object* v_toOne_248_; lean_object* v_toMonoid_249_; lean_object* v___x_250_; lean_object* v_toMul_251_; lean_object* v___f_252_; lean_object* v___f_253_; 
v___x_231_ = lp_mathlib_Field_toSemifield___redArg(v_inst_227_);
v___x_232_ = lp_mathlib_Semifield_toDivisionSemiring___redArg(v___x_231_);
v_toSemiring_233_ = lean_ctor_get(v___x_232_, 0);
lean_inc_ref(v_toSemiring_233_);
lean_dec_ref(v___x_232_);
v_toAddCommMonoid_234_ = lean_ctor_get(v_toSemiring_233_, 0);
v_toMonoid_235_ = lean_ctor_get(v_toSemiring_233_, 1);
lean_inc_ref(v_toMonoid_235_);
lean_inc_ref(v_toAddCommMonoid_234_);
v___x_236_ = lp_mathlib_Matrix_addMonoid___redArg(v_toAddCommMonoid_234_);
v___x_237_ = lp_mathlib_instDistribOfSemiring___redArg(v_toSemiring_233_);
v_toMul_238_ = lean_ctor_get(v___x_237_, 0);
lean_inc(v_toMul_238_);
v_toAdd_239_ = lean_ctor_get(v___x_237_, 1);
lean_inc(v_toAdd_239_);
lean_dec_ref(v___x_237_);
v_toNPow_240_ = lean_ctor_get(v_toMonoid_235_, 2);
lean_inc(v_toNPow_240_);
lean_dec_ref(v_toMonoid_235_);
v___x_241_ = lp_mathlib_Field_toDivisionRing___redArg(v_inst_227_);
v_toRing_242_ = lean_ctor_get(v___x_241_, 0);
lean_inc_ref(v_toRing_242_);
lean_dec_ref(v___x_241_);
v___x_243_ = lp_mathlib_Ring_toAddCommGroup___redArg(v_toRing_242_);
v___x_244_ = lp_mathlib_SubNegZeroMonoid_toNegZeroClass___redArg(v___x_243_);
lean_dec_ref(v___x_243_);
v_toNeg_245_ = lean_ctor_get(v___x_244_, 1);
lean_inc(v_toNeg_245_);
lean_dec_ref(v___x_244_);
v___x_246_ = lp_mathlib_Ring_toAddGroupWithOne___redArg(v_toRing_242_);
v_toAddMonoidWithOne_247_ = lean_ctor_get(v___x_246_, 1);
lean_inc_ref(v_toAddMonoidWithOne_247_);
lean_dec_ref(v___x_246_);
v_toOne_248_ = lean_ctor_get(v_toAddMonoidWithOne_247_, 2);
lean_inc(v_toOne_248_);
lean_dec_ref(v_toAddMonoidWithOne_247_);
v_toMonoid_249_ = lean_ctor_get(v_inst_228_, 0);
v___x_250_ = lp_mathlib_Monoid_toMulOneClass___redArg(v_toMonoid_249_);
v_toMul_251_ = lean_ctor_get(v___x_250_, 1);
lean_inc(v_toMul_251_);
lean_dec_ref(v___x_250_);
v___f_252_ = lean_alloc_closure((void*)(lp_tree_Formalism_MainNotions_UnusedSlot38_dC___redArg___lam__0), 3, 1);
lean_closure_set(v___f_252_, 0, v_toMul_251_);
v___f_253_ = lean_alloc_closure((void*)(lp_tree_Formalism_MainNotions_UnusedSlot38_dC___redArg___lam__3___boxed), 13, 9);
lean_closure_set(v___f_253_, 0, v_toNeg_245_);
lean_closure_set(v___f_253_, 1, v_toOne_248_);
lean_closure_set(v___f_253_, 2, v_toNPow_240_);
lean_closure_set(v___f_253_, 3, v_m_230_);
lean_closure_set(v___f_253_, 4, v___f_252_);
lean_closure_set(v___f_253_, 5, v_toMul_238_);
lean_closure_set(v___f_253_, 6, v_act_229_);
lean_closure_set(v___f_253_, 7, v___x_236_);
lean_closure_set(v___f_253_, 8, v_toAdd_239_);
return v___f_253_;
}
}
LEAN_EXPORT lean_object* lp_tree_Formalism_MainNotions_UnusedSlot38_dC___redArg___boxed(lean_object* v_inst_254_, lean_object* v_inst_255_, lean_object* v_act_256_, lean_object* v_m_257_){
_start:
{
lean_object* v_res_258_; 
v_res_258_ = lp_tree_Formalism_MainNotions_UnusedSlot38_dC___redArg(v_inst_254_, v_inst_255_, v_act_256_, v_m_257_);
lean_dec_ref(v_inst_255_);
return v_res_258_;
}
}
LEAN_EXPORT lean_object* lp_tree_Formalism_MainNotions_UnusedSlot38_dC(lean_object* v_k_259_, lean_object* v_inst_260_, lean_object* v_n_261_, lean_object* v_H_262_, lean_object* v_inst_263_, lean_object* v_act_264_, lean_object* v_m_265_){
_start:
{
lean_object* v___x_266_; 
v___x_266_ = lp_tree_Formalism_MainNotions_UnusedSlot38_dC___redArg(v_inst_260_, v_inst_263_, v_act_264_, v_m_265_);
return v___x_266_;
}
}
LEAN_EXPORT lean_object* lp_tree_Formalism_MainNotions_UnusedSlot38_dC___boxed(lean_object* v_k_267_, lean_object* v_inst_268_, lean_object* v_n_269_, lean_object* v_H_270_, lean_object* v_inst_271_, lean_object* v_act_272_, lean_object* v_m_273_){
_start:
{
lean_object* v_res_274_; 
v_res_274_ = lp_tree_Formalism_MainNotions_UnusedSlot38_dC(v_k_267_, v_inst_268_, v_n_269_, v_H_270_, v_inst_271_, v_act_272_, v_m_273_);
lean_dec_ref(v_inst_271_);
lean_dec(v_n_269_);
return v_res_274_;
}
}
LEAN_EXPORT lean_object* lp_tree_Formalism_MainNotions_UnusedSlot38_CochSub(lean_object* v_k_275_, lean_object* v_inst_276_, lean_object* v_n_277_, lean_object* v_H_278_, lean_object* v_inst_279_, lean_object* v_m_280_, lean_object* v_N_281_){
_start:
{
lean_object* v___x_282_; 
v___x_282_ = lean_box(0);
return v___x_282_;
}
}
LEAN_EXPORT lean_object* lp_tree_Formalism_MainNotions_UnusedSlot38_CochSub___boxed(lean_object* v_k_283_, lean_object* v_inst_284_, lean_object* v_n_285_, lean_object* v_H_286_, lean_object* v_inst_287_, lean_object* v_m_288_, lean_object* v_N_289_){
_start:
{
lean_object* v_res_290_; 
v_res_290_ = lp_tree_Formalism_MainNotions_UnusedSlot38_CochSub(v_k_283_, v_inst_284_, v_n_285_, v_H_286_, v_inst_287_, v_m_288_, v_N_289_);
lean_dec(v_m_288_);
lean_dec(v_n_285_);
lean_dec_ref(v_inst_284_);
return v_res_290_;
}
}
LEAN_EXPORT lean_object* lp_tree_Formalism_MainNotions_UnusedSlot38_wtSub(lean_object* v_P_291_, lean_object* v_V_292_, lean_object* v_w_293_, lean_object* v_j_294_){
_start:
{
lean_object* v___x_295_; 
v___x_295_ = lean_box(0);
return v___x_295_;
}
}
LEAN_EXPORT lean_object* lp_tree_Formalism_MainNotions_UnusedSlot38_wtSub___boxed(lean_object* v_P_296_, lean_object* v_V_297_, lean_object* v_w_298_, lean_object* v_j_299_){
_start:
{
lean_object* v_res_300_; 
v_res_300_ = lp_tree_Formalism_MainNotions_UnusedSlot38_wtSub(v_P_296_, v_V_297_, v_w_298_, v_j_299_);
lean_dec(v_j_299_);
lean_dec(v_w_298_);
lean_dec_ref(v_P_296_);
return v_res_300_;
}
}
LEAN_EXPORT lean_object* lp_tree_Formalism_MainNotions_UnusedSlot38_bSub(lean_object* v_P_301_, lean_object* v_F_302_){
_start:
{
lean_object* v___x_303_; 
v___x_303_ = lean_box(0);
return v___x_303_;
}
}
LEAN_EXPORT lean_object* lp_tree_Formalism_MainNotions_UnusedSlot38_bSub___boxed(lean_object* v_P_304_, lean_object* v_F_305_){
_start:
{
lean_object* v_res_306_; 
v_res_306_ = lp_tree_Formalism_MainNotions_UnusedSlot38_bSub(v_P_304_, v_F_305_);
lean_dec(v_F_305_);
lean_dec_ref(v_P_304_);
return v_res_306_;
}
}
LEAN_EXPORT lean_object* lp_tree_Formalism_MainNotions_UnusedSlot38_nSub(lean_object* v_P_307_, lean_object* v_F_308_){
_start:
{
lean_object* v___x_309_; 
v___x_309_ = lean_box(0);
return v___x_309_;
}
}
LEAN_EXPORT lean_object* lp_tree_Formalism_MainNotions_UnusedSlot38_nSub___boxed(lean_object* v_P_310_, lean_object* v_F_311_){
_start:
{
lean_object* v_res_312_; 
v_res_312_ = lp_tree_Formalism_MainNotions_UnusedSlot38_nSub(v_P_310_, v_F_311_);
lean_dec(v_F_311_);
lean_dec_ref(v_P_310_);
return v_res_312_;
}
}
LEAN_EXPORT lean_object* lp_tree_Formalism_MainNotions_UnusedSlot38_dimb(uint8_t v_x_313_){
_start:
{
if (v_x_313_ == 1)
{
lean_object* v___x_314_; 
v___x_314_ = lean_unsigned_to_nat(3u);
return v___x_314_;
}
else
{
lean_object* v___x_315_; 
v___x_315_ = lean_unsigned_to_nat(6u);
return v___x_315_;
}
}
}
LEAN_EXPORT lean_object* lp_tree_Formalism_MainNotions_UnusedSlot38_dimb___boxed(lean_object* v_x_316_){
_start:
{
uint8_t v_x_29__boxed_317_; lean_object* v_res_318_; 
v_x_29__boxed_317_ = lean_unbox(v_x_316_);
v_res_318_ = lp_tree_Formalism_MainNotions_UnusedSlot38_dimb(v_x_29__boxed_317_);
return v_res_318_;
}
}
LEAN_EXPORT lean_object* lp_tree_Subgroup_subtype___at___00Formalism_MainNotions_UnusedSlot38_kerAbL_spec__0___lam__0(lean_object* v_self_319_){
_start:
{
lean_inc(v_self_319_);
return v_self_319_;
}
}
LEAN_EXPORT lean_object* lp_tree_Subgroup_subtype___at___00Formalism_MainNotions_UnusedSlot38_kerAbL_spec__0___lam__0___boxed(lean_object* v_self_320_){
_start:
{
lean_object* v_res_321_; 
v_res_321_ = lp_tree_Subgroup_subtype___at___00Formalism_MainNotions_UnusedSlot38_kerAbL_spec__0___lam__0(v_self_320_);
lean_dec(v_self_320_);
return v_res_321_;
}
}
LEAN_EXPORT lean_object* lp_tree_Subgroup_subtype___at___00Formalism_MainNotions_UnusedSlot38_kerAbL_spec__0(lean_object* v_P_323_, lean_object* v_H_324_){
_start:
{
lean_object* v___f_325_; 
v___f_325_ = ((lean_object*)(lp_tree_Subgroup_subtype___at___00Formalism_MainNotions_UnusedSlot38_kerAbL_spec__0___closed__0));
return v___f_325_;
}
}
LEAN_EXPORT lean_object* lp_tree_Subgroup_subtype___at___00Formalism_MainNotions_UnusedSlot38_kerAbL_spec__0___boxed(lean_object* v_P_326_, lean_object* v_H_327_){
_start:
{
lean_object* v_res_328_; 
v_res_328_ = lp_tree_Subgroup_subtype___at___00Formalism_MainNotions_UnusedSlot38_kerAbL_spec__0(v_P_326_, v_H_327_);
lean_dec_ref(v_P_326_);
return v_res_328_;
}
}
LEAN_EXPORT lean_object* lp_tree_Subgroup_map___at___00Formalism_MainNotions_UnusedSlot38_kerAbL_spec__4(lean_object* v_P_329_, lean_object* v___x_330_, lean_object* v_f_331_, lean_object* v_H_332_){
_start:
{
lean_object* v___x_333_; 
v___x_333_ = lean_box(0);
return v___x_333_;
}
}
LEAN_EXPORT lean_object* lp_tree_Subgroup_map___at___00Formalism_MainNotions_UnusedSlot38_kerAbL_spec__4___boxed(lean_object* v_P_334_, lean_object* v___x_335_, lean_object* v_f_336_, lean_object* v_H_337_){
_start:
{
lean_object* v_res_338_; 
v_res_338_ = lp_tree_Subgroup_map___at___00Formalism_MainNotions_UnusedSlot38_kerAbL_spec__4(v_P_334_, v___x_335_, v_f_336_, v_H_337_);
lean_dec(v_f_336_);
lean_dec_ref(v_P_334_);
return v_res_338_;
}
}
LEAN_EXPORT lean_object* lp_tree_Submonoid_copy___at___00iInf___at___00Formalism_MainNotions_UnusedSlot38_kerAbL_spec__3_spec__7(lean_object* v_P_339_, lean_object* v___x_340_, lean_object* v_S_341_, lean_object* v_s_342_, lean_object* v_hs_343_){
_start:
{
lean_object* v___x_344_; 
v___x_344_ = lean_box(0);
return v___x_344_;
}
}
LEAN_EXPORT lean_object* lp_tree_Submonoid_copy___at___00iInf___at___00Formalism_MainNotions_UnusedSlot38_kerAbL_spec__3_spec__7___boxed(lean_object* v_P_345_, lean_object* v___x_346_, lean_object* v_S_347_, lean_object* v_s_348_, lean_object* v_hs_349_){
_start:
{
lean_object* v_res_350_; 
v_res_350_ = lp_tree_Submonoid_copy___at___00iInf___at___00Formalism_MainNotions_UnusedSlot38_kerAbL_spec__3_spec__7(v_P_345_, v___x_346_, v_S_347_, v_s_348_, v_hs_349_);
lean_dec_ref(v_P_345_);
return v_res_350_;
}
}
LEAN_EXPORT lean_object* lp_tree_iInf___at___00iInf___at___00Formalism_MainNotions_UnusedSlot38_kerAbL_spec__3_spec__5(lean_object* v_P_351_, lean_object* v___x_352_, lean_object* v_00_u03b9_353_, lean_object* v_s_354_){
_start:
{
lean_object* v___x_355_; 
v___x_355_ = lean_box(0);
return v___x_355_;
}
}
LEAN_EXPORT lean_object* lp_tree_iInf___at___00iInf___at___00Formalism_MainNotions_UnusedSlot38_kerAbL_spec__3_spec__5___boxed(lean_object* v_P_356_, lean_object* v___x_357_, lean_object* v_00_u03b9_358_, lean_object* v_s_359_){
_start:
{
lean_object* v_res_360_; 
v_res_360_ = lp_tree_iInf___at___00iInf___at___00Formalism_MainNotions_UnusedSlot38_kerAbL_spec__3_spec__5(v_P_356_, v___x_357_, v_00_u03b9_358_, v_s_359_);
lean_dec_ref(v_s_359_);
lean_dec_ref(v_P_356_);
return v_res_360_;
}
}
LEAN_EXPORT lean_object* lp_tree_iInf___at___00Formalism_MainNotions_UnusedSlot38_kerAbL_spec__3___redArg___lam__0(lean_object* v_S_361_, lean_object* v_h_362_){
_start:
{
return v_S_361_;
}
}
LEAN_EXPORT lean_object* lp_tree_iInf___at___00Formalism_MainNotions_UnusedSlot38_kerAbL_spec__3___redArg___lam__1(lean_object* v_P_363_, lean_object* v___x_364_, lean_object* v_S_365_){
_start:
{
lean_object* v___x_366_; 
v___x_366_ = lean_box(0);
return v___x_366_;
}
}
LEAN_EXPORT lean_object* lp_tree_iInf___at___00Formalism_MainNotions_UnusedSlot38_kerAbL_spec__3___redArg___lam__1___boxed(lean_object* v_P_367_, lean_object* v___x_368_, lean_object* v_S_369_){
_start:
{
lean_object* v_res_370_; 
v_res_370_ = lp_tree_iInf___at___00Formalism_MainNotions_UnusedSlot38_kerAbL_spec__3___redArg___lam__1(v_P_367_, v___x_368_, v_S_369_);
lean_dec_ref(v_P_367_);
return v_res_370_;
}
}
LEAN_EXPORT lean_object* lp_tree_iInf___at___00iInf___at___00Formalism_MainNotions_UnusedSlot38_kerAbL_spec__3_spec__6(lean_object* v_P_371_, lean_object* v___x_372_, lean_object* v_00_u03b9_373_, lean_object* v_s_374_){
_start:
{
lean_object* v___x_375_; 
v___x_375_ = lean_box(0);
return v___x_375_;
}
}
LEAN_EXPORT lean_object* lp_tree_iInf___at___00iInf___at___00Formalism_MainNotions_UnusedSlot38_kerAbL_spec__3_spec__6___boxed(lean_object* v_P_376_, lean_object* v___x_377_, lean_object* v_00_u03b9_378_, lean_object* v_s_379_){
_start:
{
lean_object* v_res_380_; 
v_res_380_ = lp_tree_iInf___at___00iInf___at___00Formalism_MainNotions_UnusedSlot38_kerAbL_spec__3_spec__6(v_P_376_, v___x_377_, v_00_u03b9_378_, v_s_379_);
lean_dec_ref(v_s_379_);
lean_dec_ref(v_P_376_);
return v_res_380_;
}
}
LEAN_EXPORT lean_object* lp_tree_iInf___at___00Formalism_MainNotions_UnusedSlot38_kerAbL_spec__3___redArg(lean_object* v_P_381_, lean_object* v___x_382_){
_start:
{
lean_object* v___x_383_; 
v___x_383_ = lean_box(0);
return v___x_383_;
}
}
LEAN_EXPORT lean_object* lp_tree_iInf___at___00Formalism_MainNotions_UnusedSlot38_kerAbL_spec__3___redArg___boxed(lean_object* v_P_384_, lean_object* v___x_385_){
_start:
{
lean_object* v_res_386_; 
v_res_386_ = lp_tree_iInf___at___00Formalism_MainNotions_UnusedSlot38_kerAbL_spec__3___redArg(v_P_384_, v___x_385_);
lean_dec_ref(v_P_384_);
return v_res_386_;
}
}
LEAN_EXPORT lean_object* lp_tree_Formalism_MainNotions_UnusedSlot38_kerAbL(lean_object* v_P_387_, lean_object* v_v_388_){
_start:
{
lean_object* v___x_389_; 
v___x_389_ = lean_box(0);
return v___x_389_;
}
}
LEAN_EXPORT lean_object* lp_tree_Formalism_MainNotions_UnusedSlot38_kerAbL___boxed(lean_object* v_P_390_, lean_object* v_v_391_){
_start:
{
lean_object* v_res_392_; 
v_res_392_ = lp_tree_Formalism_MainNotions_UnusedSlot38_kerAbL(v_P_390_, v_v_391_);
lean_dec(v_v_391_);
lean_dec_ref(v_P_390_);
return v_res_392_;
}
}
LEAN_EXPORT lean_object* lp_tree_MulHomClass_toMulHom___at___00MonoidHomClass_toMonoidHom___at___00Formalism_MainNotions_UnusedSlot38_kerAbL_spec__1_spec__1___redArg___lam__0(lean_object* v_f_393_, lean_object* v___y_394_){
_start:
{
lean_object* v___x_395_; 
v___x_395_ = lean_apply_1(v_f_393_, v___y_394_);
return v___x_395_;
}
}
LEAN_EXPORT lean_object* lp_tree_MulHomClass_toMulHom___at___00MonoidHomClass_toMonoidHom___at___00Formalism_MainNotions_UnusedSlot38_kerAbL_spec__1_spec__1___redArg(lean_object* v_f_396_){
_start:
{
lean_object* v___f_397_; 
v___f_397_ = lean_alloc_closure((void*)(lp_tree_MulHomClass_toMulHom___at___00MonoidHomClass_toMonoidHom___at___00Formalism_MainNotions_UnusedSlot38_kerAbL_spec__1_spec__1___redArg___lam__0), 2, 1);
lean_closure_set(v___f_397_, 0, v_f_396_);
return v___f_397_;
}
}
LEAN_EXPORT lean_object* lp_tree_MulHomClass_toMulHom___at___00MonoidHomClass_toMonoidHom___at___00Formalism_MainNotions_UnusedSlot38_kerAbL_spec__1_spec__1(lean_object* v_P_398_, lean_object* v___x_399_, lean_object* v___x_400_, lean_object* v_inst_401_, lean_object* v_f_402_){
_start:
{
lean_object* v___f_403_; 
v___f_403_ = lean_alloc_closure((void*)(lp_tree_MulHomClass_toMulHom___at___00MonoidHomClass_toMonoidHom___at___00Formalism_MainNotions_UnusedSlot38_kerAbL_spec__1_spec__1___redArg___lam__0), 2, 1);
lean_closure_set(v___f_403_, 0, v_f_402_);
return v___f_403_;
}
}
LEAN_EXPORT lean_object* lp_tree_MulHomClass_toMulHom___at___00MonoidHomClass_toMonoidHom___at___00Formalism_MainNotions_UnusedSlot38_kerAbL_spec__1_spec__1___boxed(lean_object* v_P_404_, lean_object* v___x_405_, lean_object* v___x_406_, lean_object* v_inst_407_, lean_object* v_f_408_){
_start:
{
lean_object* v_res_409_; 
v_res_409_ = lp_tree_MulHomClass_toMulHom___at___00MonoidHomClass_toMonoidHom___at___00Formalism_MainNotions_UnusedSlot38_kerAbL_spec__1_spec__1(v_P_404_, v___x_405_, v___x_406_, v_inst_407_, v_f_408_);
lean_dec(v___x_406_);
lean_dec_ref(v_P_404_);
return v_res_409_;
}
}
LEAN_EXPORT lean_object* lp_tree_MonoidHomClass_toMonoidHom___at___00Formalism_MainNotions_UnusedSlot38_kerAbL_spec__1___redArg(lean_object* v_P_410_, lean_object* v___x_411_, lean_object* v___x_412_, lean_object* v_f_413_){
_start:
{
lean_object* v___f_414_; 
v___f_414_ = lean_alloc_closure((void*)(lp_tree_MulHomClass_toMulHom___at___00MonoidHomClass_toMonoidHom___at___00Formalism_MainNotions_UnusedSlot38_kerAbL_spec__1_spec__1___redArg___lam__0), 2, 1);
lean_closure_set(v___f_414_, 0, v_f_413_);
return v___f_414_;
}
}
LEAN_EXPORT lean_object* lp_tree_MonoidHomClass_toMonoidHom___at___00Formalism_MainNotions_UnusedSlot38_kerAbL_spec__1___redArg___boxed(lean_object* v_P_415_, lean_object* v___x_416_, lean_object* v___x_417_, lean_object* v_f_418_){
_start:
{
lean_object* v_res_419_; 
v_res_419_ = lp_tree_MonoidHomClass_toMonoidHom___at___00Formalism_MainNotions_UnusedSlot38_kerAbL_spec__1___redArg(v_P_415_, v___x_416_, v___x_417_, v_f_418_);
lean_dec(v___x_417_);
lean_dec_ref(v_P_415_);
return v_res_419_;
}
}
LEAN_EXPORT lean_object* lp_tree_MonoidHomClass_toMonoidHom___at___00Formalism_MainNotions_UnusedSlot38_kerAbL_spec__1(lean_object* v_P_420_, lean_object* v___x_421_, lean_object* v___x_422_, lean_object* v_inst_423_, lean_object* v_f_424_){
_start:
{
lean_object* v___f_425_; 
v___f_425_ = lean_alloc_closure((void*)(lp_tree_MulHomClass_toMulHom___at___00MonoidHomClass_toMonoidHom___at___00Formalism_MainNotions_UnusedSlot38_kerAbL_spec__1_spec__1___redArg___lam__0), 2, 1);
lean_closure_set(v___f_425_, 0, v_f_424_);
return v___f_425_;
}
}
LEAN_EXPORT lean_object* lp_tree_MonoidHomClass_toMonoidHom___at___00Formalism_MainNotions_UnusedSlot38_kerAbL_spec__1___boxed(lean_object* v_P_426_, lean_object* v___x_427_, lean_object* v___x_428_, lean_object* v_inst_429_, lean_object* v_f_430_){
_start:
{
lean_object* v_res_431_; 
v_res_431_ = lp_tree_MonoidHomClass_toMonoidHom___at___00Formalism_MainNotions_UnusedSlot38_kerAbL_spec__1(v_P_426_, v___x_427_, v___x_428_, v_inst_429_, v_f_430_);
lean_dec(v___x_428_);
lean_dec_ref(v_P_426_);
return v_res_431_;
}
}
LEAN_EXPORT lean_object* lp_tree_Submonoid_comap___at___00MonoidHom_mker___at___00MonoidHom_ker___at___00Formalism_MainNotions_UnusedSlot38_kerAbL_spec__2_spec__3_spec__5(lean_object* v_P_432_, lean_object* v___x_433_, lean_object* v___x_434_, lean_object* v_mc_435_, lean_object* v_f_436_, lean_object* v_S_437_){
_start:
{
lean_object* v___x_438_; 
v___x_438_ = lean_box(0);
return v___x_438_;
}
}
LEAN_EXPORT lean_object* lp_tree_Submonoid_comap___at___00MonoidHom_mker___at___00MonoidHom_ker___at___00Formalism_MainNotions_UnusedSlot38_kerAbL_spec__2_spec__3_spec__5___boxed(lean_object* v_P_439_, lean_object* v___x_440_, lean_object* v___x_441_, lean_object* v_mc_442_, lean_object* v_f_443_, lean_object* v_S_444_){
_start:
{
lean_object* v_res_445_; 
v_res_445_ = lp_tree_Submonoid_comap___at___00MonoidHom_mker___at___00MonoidHom_ker___at___00Formalism_MainNotions_UnusedSlot38_kerAbL_spec__2_spec__3_spec__5(v_P_439_, v___x_440_, v___x_441_, v_mc_442_, v_f_443_, v_S_444_);
lean_dec(v_f_443_);
lean_dec(v___x_441_);
lean_dec_ref(v_P_439_);
return v_res_445_;
}
}
LEAN_EXPORT lean_object* lp_tree_MonoidHom_mker___at___00MonoidHom_ker___at___00Formalism_MainNotions_UnusedSlot38_kerAbL_spec__2_spec__3___redArg(lean_object* v_P_446_, lean_object* v___x_447_, lean_object* v___x_448_, lean_object* v_f_449_){
_start:
{
lean_object* v___x_450_; 
v___x_450_ = lean_box(0);
return v___x_450_;
}
}
LEAN_EXPORT lean_object* lp_tree_MonoidHom_mker___at___00MonoidHom_ker___at___00Formalism_MainNotions_UnusedSlot38_kerAbL_spec__2_spec__3___redArg___boxed(lean_object* v_P_451_, lean_object* v___x_452_, lean_object* v___x_453_, lean_object* v_f_454_){
_start:
{
lean_object* v_res_455_; 
v_res_455_ = lp_tree_MonoidHom_mker___at___00MonoidHom_ker___at___00Formalism_MainNotions_UnusedSlot38_kerAbL_spec__2_spec__3___redArg(v_P_451_, v___x_452_, v___x_453_, v_f_454_);
lean_dec(v_f_454_);
lean_dec(v___x_453_);
lean_dec_ref(v_P_451_);
return v_res_455_;
}
}
LEAN_EXPORT lean_object* lp_tree_MonoidHom_ker___at___00Formalism_MainNotions_UnusedSlot38_kerAbL_spec__2(lean_object* v_P_456_, lean_object* v___x_457_, lean_object* v___x_458_, lean_object* v_f_459_){
_start:
{
lean_object* v___x_460_; 
v___x_460_ = lean_box(0);
return v___x_460_;
}
}
LEAN_EXPORT lean_object* lp_tree_MonoidHom_ker___at___00Formalism_MainNotions_UnusedSlot38_kerAbL_spec__2___boxed(lean_object* v_P_461_, lean_object* v___x_462_, lean_object* v___x_463_, lean_object* v_f_464_){
_start:
{
lean_object* v_res_465_; 
v_res_465_ = lp_tree_MonoidHom_ker___at___00Formalism_MainNotions_UnusedSlot38_kerAbL_spec__2(v_P_461_, v___x_462_, v___x_463_, v_f_464_);
lean_dec(v_f_464_);
lean_dec(v___x_463_);
lean_dec_ref(v_P_461_);
return v_res_465_;
}
}
LEAN_EXPORT lean_object* lp_tree_iInf___at___00Formalism_MainNotions_UnusedSlot38_kerAbL_spec__3(lean_object* v_P_466_, lean_object* v___x_467_, lean_object* v_00_u03b9_468_, lean_object* v_s_469_){
_start:
{
lean_object* v___x_470_; 
v___x_470_ = lean_box(0);
return v___x_470_;
}
}
LEAN_EXPORT lean_object* lp_tree_iInf___at___00Formalism_MainNotions_UnusedSlot38_kerAbL_spec__3___boxed(lean_object* v_P_471_, lean_object* v___x_472_, lean_object* v_00_u03b9_473_, lean_object* v_s_474_){
_start:
{
lean_object* v_res_475_; 
v_res_475_ = lp_tree_iInf___at___00Formalism_MainNotions_UnusedSlot38_kerAbL_spec__3(v_P_471_, v___x_472_, v_00_u03b9_473_, v_s_474_);
lean_dec_ref(v_s_474_);
lean_dec_ref(v_P_471_);
return v_res_475_;
}
}
LEAN_EXPORT lean_object* lp_tree_MonoidHom_mker___at___00MonoidHom_ker___at___00Formalism_MainNotions_UnusedSlot38_kerAbL_spec__2_spec__3(lean_object* v_P_476_, lean_object* v___x_477_, lean_object* v___x_478_, lean_object* v_mc_479_, lean_object* v_f_480_){
_start:
{
lean_object* v___x_481_; 
v___x_481_ = lean_box(0);
return v___x_481_;
}
}
LEAN_EXPORT lean_object* lp_tree_MonoidHom_mker___at___00MonoidHom_ker___at___00Formalism_MainNotions_UnusedSlot38_kerAbL_spec__2_spec__3___boxed(lean_object* v_P_482_, lean_object* v___x_483_, lean_object* v___x_484_, lean_object* v_mc_485_, lean_object* v_f_486_){
_start:
{
lean_object* v_res_487_; 
v_res_487_ = lp_tree_MonoidHom_mker___at___00MonoidHom_ker___at___00Formalism_MainNotions_UnusedSlot38_kerAbL_spec__2_spec__3(v_P_482_, v___x_483_, v___x_484_, v_mc_485_, v_f_486_);
lean_dec(v_f_486_);
lean_dec(v___x_484_);
lean_dec_ref(v_P_482_);
return v_res_487_;
}
}
LEAN_EXPORT lean_object* lp_tree_Formalism_MainNotions_UnusedSlot38_CochG(lean_object* v_P_488_, lean_object* v_H_489_, lean_object* v_inst_490_, lean_object* v_inst_491_, lean_object* v_00_u03b9_492_, lean_object* v_S_493_, lean_object* v_N_494_, lean_object* v_m_495_){
_start:
{
lean_object* v___x_496_; 
v___x_496_ = lean_box(0);
return v___x_496_;
}
}
LEAN_EXPORT lean_object* lp_tree_Formalism_MainNotions_UnusedSlot38_CochG___boxed(lean_object* v_P_497_, lean_object* v_H_498_, lean_object* v_inst_499_, lean_object* v_inst_500_, lean_object* v_00_u03b9_501_, lean_object* v_S_502_, lean_object* v_N_503_, lean_object* v_m_504_){
_start:
{
lean_object* v_res_505_; 
v_res_505_ = lp_tree_Formalism_MainNotions_UnusedSlot38_CochG(v_P_497_, v_H_498_, v_inst_499_, v_inst_500_, v_00_u03b9_501_, v_S_502_, v_N_503_, v_m_504_);
lean_dec(v_m_504_);
lean_dec(v_00_u03b9_501_);
lean_dec_ref(v_inst_499_);
lean_dec_ref(v_P_497_);
return v_res_505_;
}
}
lean_object* initialize_Init(uint8_t builtin);
lean_object* initialize_Init(uint8_t builtin);
lean_object* initialize_mathlib_Mathlib(uint8_t builtin);
lean_object* initialize_tree_Formalism_LocalRingCardinality_RhoDetPrimeEqMuTildeMulChiPow(uint8_t builtin);
lean_object* initialize_tree_Formalism_SharpRestriction_ParConsts(uint8_t builtin);
lean_object* initialize_tree_Formalism_SharpRestriction_ValuationFrobeniusEpsilon_InstLocalRingSymplecticCoefficients(uint8_t builtin);
static bool _G_initialized = false;
LEAN_EXPORT lean_object* initialize_tree_Formalism_SharpRestriction_ValuationFrobeniusEpsilon_GradedCompletionLemmas(uint8_t builtin) {
lean_object * res;
if (_G_initialized) return lean_io_result_mk_ok(lean_box(0));
_G_initialized = true;
res = initialize_Init(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_Init(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_mathlib_Mathlib(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_Formalism_LocalRingCardinality_RhoDetPrimeEqMuTildeMulChiPow(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_Formalism_SharpRestriction_ParConsts(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_Formalism_SharpRestriction_ValuationFrobeniusEpsilon_InstLocalRingSymplecticCoefficients(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
return lean_io_result_mk_ok(lean_box(0));
}
#ifdef __cplusplus
}
#endif
