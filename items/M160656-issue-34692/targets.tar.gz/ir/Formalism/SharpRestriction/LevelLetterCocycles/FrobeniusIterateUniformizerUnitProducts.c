// Lean compiler output
// Module: Formalism.SharpRestriction.LevelLetterCocycles.FrobeniusIterateUniformizerUnitProducts
// Imports: public import Init public meta import Init public import Mathlib public import Formalism.SharpRestriction.LevelLetterCocycles.FiltrationSaturationKiller
#include <lean/lean.h>
#if defined(__clang__)
#pragma clang diagnostic ignored "-Wunused-parameter"
#pragma clang diagnostic ignored "-Wunused-label"
#elif defined(__GNUC__) && !defined(__CLANG__)
#pragma GCC diagnostic ignored "-Wunused-parameter"
#pragma GCC diagnostic ignored "-Wunused-label"
#pragma GCC diagnostic ignored "-Wunused-but-set-variable"
#endif
#ifdef __cplusplus
extern "C" {
#endif
LEAN_EXPORT lean_object* lp_tree_Formalism_MainNotions_UnusedSlot80_unitQProds(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_Formalism_MainNotions_UnusedSlot80_unitQProds___boxed(lean_object**);
LEAN_EXPORT lean_object* lp_tree_Formalism_MainNotions_UnusedSlot80_unitQProds(lean_object* v_G_1_, lean_object* v_inst_2_, lean_object* v_inst_3_, lean_object* v_Qp_4_, lean_object* v_K_u2080_5_, lean_object* v_K_6_, lean_object* v_inst_7_, lean_object* v_inst_8_, lean_object* v_inst_9_, lean_object* v_inst_10_, lean_object* v_inst_11_, lean_object* v_inst_12_, lean_object* v_inst_13_, lean_object* v_B_14_, lean_object* v_BdR_15_, lean_object* v_inst_16_, lean_object* v_inst_17_, lean_object* v_inst_18_, lean_object* v_inst_19_, lean_object* v_inst_20_, lean_object* v_inst_21_, lean_object* v_inst_22_, lean_object* v_inst_23_, lean_object* v_inst_24_, lean_object* v_inst_25_, lean_object* v_inst_26_, lean_object* v_PD_27_, lean_object* v_LL_28_, lean_object* v_O_29_, lean_object* v_inst_30_, lean_object* v_inst_31_, lean_object* v_inst_32_, lean_object* v_inst_33_, lean_object* v_inst_34_, lean_object* v_v_35_, lean_object* v_n_36_, lean_object* v_W_37_){
_start:
{
lean_object* v___x_38_; 
v___x_38_ = lean_box(0);
return v___x_38_;
}
}
LEAN_EXPORT lean_object* lp_tree_Formalism_MainNotions_UnusedSlot80_unitQProds___boxed(lean_object** _args){
lean_object* v_G_39_ = _args[0];
lean_object* v_inst_40_ = _args[1];
lean_object* v_inst_41_ = _args[2];
lean_object* v_Qp_42_ = _args[3];
lean_object* v_K_u2080_43_ = _args[4];
lean_object* v_K_44_ = _args[5];
lean_object* v_inst_45_ = _args[6];
lean_object* v_inst_46_ = _args[7];
lean_object* v_inst_47_ = _args[8];
lean_object* v_inst_48_ = _args[9];
lean_object* v_inst_49_ = _args[10];
lean_object* v_inst_50_ = _args[11];
lean_object* v_inst_51_ = _args[12];
lean_object* v_B_52_ = _args[13];
lean_object* v_BdR_53_ = _args[14];
lean_object* v_inst_54_ = _args[15];
lean_object* v_inst_55_ = _args[16];
lean_object* v_inst_56_ = _args[17];
lean_object* v_inst_57_ = _args[18];
lean_object* v_inst_58_ = _args[19];
lean_object* v_inst_59_ = _args[20];
lean_object* v_inst_60_ = _args[21];
lean_object* v_inst_61_ = _args[22];
lean_object* v_inst_62_ = _args[23];
lean_object* v_inst_63_ = _args[24];
lean_object* v_inst_64_ = _args[25];
lean_object* v_PD_65_ = _args[26];
lean_object* v_LL_66_ = _args[27];
lean_object* v_O_67_ = _args[28];
lean_object* v_inst_68_ = _args[29];
lean_object* v_inst_69_ = _args[30];
lean_object* v_inst_70_ = _args[31];
lean_object* v_inst_71_ = _args[32];
lean_object* v_inst_72_ = _args[33];
lean_object* v_v_73_ = _args[34];
lean_object* v_n_74_ = _args[35];
lean_object* v_W_75_ = _args[36];
_start:
{
lean_object* v_res_76_; 
v_res_76_ = lp_tree_Formalism_MainNotions_UnusedSlot80_unitQProds(v_G_39_, v_inst_40_, v_inst_41_, v_Qp_42_, v_K_u2080_43_, v_K_44_, v_inst_45_, v_inst_46_, v_inst_47_, v_inst_48_, v_inst_49_, v_inst_50_, v_inst_51_, v_B_52_, v_BdR_53_, v_inst_54_, v_inst_55_, v_inst_56_, v_inst_57_, v_inst_58_, v_inst_59_, v_inst_60_, v_inst_61_, v_inst_62_, v_inst_63_, v_inst_64_, v_PD_65_, v_LL_66_, v_O_67_, v_inst_68_, v_inst_69_, v_inst_70_, v_inst_71_, v_inst_72_, v_v_73_, v_n_74_, v_W_75_);
lean_dec_ref(v_W_75_);
lean_dec(v_n_74_);
lean_dec_ref(v_v_73_);
lean_dec_ref(v_inst_72_);
lean_dec_ref(v_inst_71_);
lean_dec_ref(v_inst_69_);
lean_dec_ref(v_inst_68_);
lean_dec_ref(v_PD_65_);
lean_dec_ref(v_inst_61_);
lean_dec_ref(v_inst_60_);
lean_dec_ref(v_inst_59_);
lean_dec_ref(v_inst_57_);
lean_dec_ref(v_inst_56_);
lean_dec_ref(v_inst_55_);
lean_dec_ref(v_inst_54_);
lean_dec_ref(v_inst_50_);
lean_dec_ref(v_inst_49_);
lean_dec_ref(v_inst_48_);
lean_dec_ref(v_inst_47_);
lean_dec_ref(v_inst_46_);
lean_dec_ref(v_inst_45_);
lean_dec_ref(v_inst_40_);
return v_res_76_;
}
}
lean_object* initialize_Init(uint8_t builtin);
lean_object* initialize_Init(uint8_t builtin);
lean_object* initialize_mathlib_Mathlib(uint8_t builtin);
lean_object* initialize_tree_Formalism_SharpRestriction_LevelLetterCocycles_FiltrationSaturationKiller(uint8_t builtin);
static bool _G_initialized = false;
LEAN_EXPORT lean_object* initialize_tree_Formalism_SharpRestriction_LevelLetterCocycles_FrobeniusIterateUniformizerUnitProducts(uint8_t builtin) {
lean_object * res;
if (_G_initialized) return lean_io_result_mk_ok(lean_box(0));
_G_initialized = true;
res = initialize_Init(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_Init(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_mathlib_Mathlib(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_Formalism_SharpRestriction_LevelLetterCocycles_FiltrationSaturationKiller(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
return lean_io_result_mk_ok(lean_box(0));
}
#ifdef __cplusplus
}
#endif
