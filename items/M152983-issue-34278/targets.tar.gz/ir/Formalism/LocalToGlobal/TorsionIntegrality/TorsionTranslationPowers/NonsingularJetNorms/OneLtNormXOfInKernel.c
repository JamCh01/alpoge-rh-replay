// Lean compiler output
// Module: Formalism.LocalToGlobal.TorsionIntegrality.TorsionTranslationPowers.NonsingularJetNorms.OneLtNormXOfInKernel
// Imports: public import Init public meta import Init public import Formalism.LocalToGlobal.TorsionIntegrality.TorsionTranslationPowers.StatementS public import Formalism.LocalToGlobal.TorsionIntegrality.TorsionTranslationPowers.FacShapeZero public import Formalism.EllipticTorsion.FormalGroupPointsNoTorsion public import Formalism.LocalToGlobal.TorsionIntegrality.TorsionTranslationPowers.NonsingularJetNorms.Taylor0ConstMul
#include <lean/lean.h>
#if defined(__clang__)
#pragma clang diagnostic ignored "-Wunused-parameter"
#pragma clang diagnostic ignored "-Wunused-label"
#elif defined(__GNUC__) && !defined(__CLANG__)
#pragma GCC diagnostic ignored "-Wunused-parameter"
#pragma GCC diagnostic ignored "-Wunused-label"
#pragma GCC diagnostic ignored "-Wunused-but-set-variable"
#endif
#ifdef __cplusplus
extern "C" {
#endif
LEAN_EXPORT lean_object* lp_tree___private_Formalism_LocalToGlobal_TorsionIntegrality_TorsionTranslationPowers_NonsingularJetNorms_OneLtNormXOfInKernel_0__Formalism_L2_Th1_E_px_match__1_splitter___redArg(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree___private_Formalism_LocalToGlobal_TorsionIntegrality_TorsionTranslationPowers_NonsingularJetNorms_OneLtNormXOfInKernel_0__Formalism_L2_Th1_E_px_match__1_splitter(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree___private_Formalism_LocalToGlobal_TorsionIntegrality_TorsionTranslationPowers_NonsingularJetNorms_OneLtNormXOfInKernel_0__Formalism_L2_Th1_E_px_match__1_splitter___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree___private_Formalism_LocalToGlobal_TorsionIntegrality_TorsionTranslationPowers_NonsingularJetNorms_OneLtNormXOfInKernel_0__Formalism_L2_Th1_E_px_match__1_splitter___redArg(lean_object* v_x_1_, lean_object* v_h__1_2_, lean_object* v_h__2_3_){
_start:
{
if (lean_obj_tag(v_x_1_) == 0)
{
lean_object* v___x_4_; lean_object* v___x_5_; 
lean_dec(v_h__2_3_);
v___x_4_ = lean_box(0);
v___x_5_ = lean_apply_1(v_h__1_2_, v___x_4_);
return v___x_5_;
}
else
{
lean_object* v_x_6_; lean_object* v_y_7_; lean_object* v___x_8_; 
lean_dec(v_h__1_2_);
v_x_6_ = lean_ctor_get(v_x_1_, 0);
lean_inc(v_x_6_);
v_y_7_ = lean_ctor_get(v_x_1_, 1);
lean_inc(v_y_7_);
lean_dec_ref_known(v_x_1_, 2);
v___x_8_ = lean_apply_3(v_h__2_3_, v_x_6_, v_y_7_, lean_box(0));
return v___x_8_;
}
}
}
LEAN_EXPORT lean_object* lp_tree___private_Formalism_LocalToGlobal_TorsionIntegrality_TorsionTranslationPowers_NonsingularJetNorms_OneLtNormXOfInKernel_0__Formalism_L2_Th1_E_px_match__1_splitter(lean_object* v_K_9_, lean_object* v_inst_10_, lean_object* v_W_11_, lean_object* v_motive_12_, lean_object* v_x_13_, lean_object* v_h__1_14_, lean_object* v_h__2_15_){
_start:
{
if (lean_obj_tag(v_x_13_) == 0)
{
lean_object* v___x_16_; lean_object* v___x_17_; 
lean_dec(v_h__2_15_);
v___x_16_ = lean_box(0);
v___x_17_ = lean_apply_1(v_h__1_14_, v___x_16_);
return v___x_17_;
}
else
{
lean_object* v_x_18_; lean_object* v_y_19_; lean_object* v___x_20_; 
lean_dec(v_h__1_14_);
v_x_18_ = lean_ctor_get(v_x_13_, 0);
lean_inc(v_x_18_);
v_y_19_ = lean_ctor_get(v_x_13_, 1);
lean_inc(v_y_19_);
lean_dec_ref_known(v_x_13_, 2);
v___x_20_ = lean_apply_3(v_h__2_15_, v_x_18_, v_y_19_, lean_box(0));
return v___x_20_;
}
}
}
LEAN_EXPORT lean_object* lp_tree___private_Formalism_LocalToGlobal_TorsionIntegrality_TorsionTranslationPowers_NonsingularJetNorms_OneLtNormXOfInKernel_0__Formalism_L2_Th1_E_px_match__1_splitter___boxed(lean_object* v_K_21_, lean_object* v_inst_22_, lean_object* v_W_23_, lean_object* v_motive_24_, lean_object* v_x_25_, lean_object* v_h__1_26_, lean_object* v_h__2_27_){
_start:
{
lean_object* v_res_28_; 
v_res_28_ = lp_tree___private_Formalism_LocalToGlobal_TorsionIntegrality_TorsionTranslationPowers_NonsingularJetNorms_OneLtNormXOfInKernel_0__Formalism_L2_Th1_E_px_match__1_splitter(v_K_21_, v_inst_22_, v_W_23_, v_motive_24_, v_x_25_, v_h__1_26_, v_h__2_27_);
lean_dec_ref(v_W_23_);
lean_dec_ref(v_inst_22_);
return v_res_28_;
}
}
lean_object* initialize_Init(uint8_t builtin);
lean_object* initialize_Init(uint8_t builtin);
lean_object* initialize_tree_Formalism_LocalToGlobal_TorsionIntegrality_TorsionTranslationPowers_StatementS(uint8_t builtin);
lean_object* initialize_tree_Formalism_LocalToGlobal_TorsionIntegrality_TorsionTranslationPowers_FacShapeZero(uint8_t builtin);
lean_object* initialize_tree_Formalism_EllipticTorsion_FormalGroupPointsNoTorsion(uint8_t builtin);
lean_object* initialize_tree_Formalism_LocalToGlobal_TorsionIntegrality_TorsionTranslationPowers_NonsingularJetNorms_Taylor0ConstMul(uint8_t builtin);
static bool _G_initialized = false;
LEAN_EXPORT lean_object* initialize_tree_Formalism_LocalToGlobal_TorsionIntegrality_TorsionTranslationPowers_NonsingularJetNorms_OneLtNormXOfInKernel(uint8_t builtin) {
lean_object * res;
if (_G_initialized) return lean_io_result_mk_ok(lean_box(0));
_G_initialized = true;
res = initialize_Init(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_Init(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_Formalism_LocalToGlobal_TorsionIntegrality_TorsionTranslationPowers_StatementS(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_Formalism_LocalToGlobal_TorsionIntegrality_TorsionTranslationPowers_FacShapeZero(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_Formalism_EllipticTorsion_FormalGroupPointsNoTorsion(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_Formalism_LocalToGlobal_TorsionIntegrality_TorsionTranslationPowers_NonsingularJetNorms_Taylor0ConstMul(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
return lean_io_result_mk_ok(lean_box(0));
}
#ifdef __cplusplus
}
#endif
