// Lean compiler output
// Module: Development.AbelianVarietyTheory.Proofs.DivisorProofs.FunIffRowSlopeBound
// Imports: public import Init public meta import Init public import Mathlib public import Formalism.LocalToGlobal.IndefiniteForms.IndefUse public import Formalism.LocalToGlobal.IndefiniteForms.IndefExample public import Formalism.LocalToGlobal.Divisibility.FramesLemmas public import Formalism.QuotientMetricDivisors.FinalW public import Formalism.LocalRingCardinality.Lemmas public import Development.AbelianVarietyTheory.BlockTheory.DivisorBase.QuotientNormSquareData
#include <lean/lean.h>
#if defined(__clang__)
#pragma clang diagnostic ignored "-Wunused-parameter"
#pragma clang diagnostic ignored "-Wunused-label"
#elif defined(__GNUC__) && !defined(__CLANG__)
#pragma GCC diagnostic ignored "-Wunused-parameter"
#pragma GCC diagnostic ignored "-Wunused-label"
#pragma GCC diagnostic ignored "-Wunused-but-set-variable"
#endif
#ifdef __cplusplus
extern "C" {
#endif
lean_object* l_List_finRange(lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_RowSlopeCompare_baseOf___redArg(lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_RowSlopeCompare_baseOf___redArg___boxed(lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_RowSlopeCompare_baseOf(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_RowSlopeCompare_baseOf___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_RowSlopeCompare_baseOf___redArg(lean_object* v_inst_1_, lean_object* v_m_2_, lean_object* v_D_3_, lean_object* v_v0_4_){
_start:
{
lean_object* v_t_u2080_5_; lean_object* v___x_6_; lean_object* v___x_7_; lean_object* v___x_8_; 
v_t_u2080_5_ = lean_ctor_get(v_D_3_, 0);
v___x_6_ = lean_box(0);
v___x_7_ = l_List_finRange(v_m_2_);
lean_inc(v_t_u2080_5_);
v___x_8_ = lean_alloc_ctor(0, 5, 0);
lean_ctor_set(v___x_8_, 0, v___x_6_);
lean_ctor_set(v___x_8_, 1, v_v0_4_);
lean_ctor_set(v___x_8_, 2, v_t_u2080_5_);
lean_ctor_set(v___x_8_, 3, v_inst_1_);
lean_ctor_set(v___x_8_, 4, v___x_7_);
return v___x_8_;
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_RowSlopeCompare_baseOf___redArg___boxed(lean_object* v_inst_9_, lean_object* v_m_10_, lean_object* v_D_11_, lean_object* v_v0_12_){
_start:
{
lean_object* v_res_13_; 
v_res_13_ = lp_tree_GlobalTheory_RowSlopeCompare_baseOf___redArg(v_inst_9_, v_m_10_, v_D_11_, v_v0_12_);
lean_dec_ref(v_D_11_);
return v_res_13_;
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_RowSlopeCompare_baseOf(lean_object* v_K_14_, lean_object* v_inst_15_, lean_object* v_inst_16_, lean_object* v_inst_17_, lean_object* v_T_18_, lean_object* v_00_u03ba_19_, lean_object* v_inst_20_, lean_object* v_inst_21_, lean_object* v_00_u03c4_22_, lean_object* v_C_23_, lean_object* v_inst_24_, lean_object* v_n_25_, lean_object* v_m_26_, lean_object* v_D_27_, lean_object* v_v0_28_){
_start:
{
lean_object* v_t_u2080_29_; lean_object* v___x_30_; lean_object* v___x_31_; lean_object* v___x_32_; 
v_t_u2080_29_ = lean_ctor_get(v_D_27_, 0);
v___x_30_ = lean_box(0);
v___x_31_ = l_List_finRange(v_m_26_);
lean_inc(v_t_u2080_29_);
v___x_32_ = lean_alloc_ctor(0, 5, 0);
lean_ctor_set(v___x_32_, 0, v___x_30_);
lean_ctor_set(v___x_32_, 1, v_v0_28_);
lean_ctor_set(v___x_32_, 2, v_t_u2080_29_);
lean_ctor_set(v___x_32_, 3, v_inst_24_);
lean_ctor_set(v___x_32_, 4, v___x_31_);
return v___x_32_;
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_RowSlopeCompare_baseOf___boxed(lean_object* v_K_33_, lean_object* v_inst_34_, lean_object* v_inst_35_, lean_object* v_inst_36_, lean_object* v_T_37_, lean_object* v_00_u03ba_38_, lean_object* v_inst_39_, lean_object* v_inst_40_, lean_object* v_00_u03c4_41_, lean_object* v_C_42_, lean_object* v_inst_43_, lean_object* v_n_44_, lean_object* v_m_45_, lean_object* v_D_46_, lean_object* v_v0_47_){
_start:
{
lean_object* v_res_48_; 
v_res_48_ = lp_tree_GlobalTheory_RowSlopeCompare_baseOf(v_K_33_, v_inst_34_, v_inst_35_, v_inst_36_, v_T_37_, v_00_u03ba_38_, v_inst_39_, v_inst_40_, v_00_u03c4_41_, v_C_42_, v_inst_43_, v_n_44_, v_m_45_, v_D_46_, v_v0_47_);
lean_dec_ref(v_D_46_);
lean_dec(v_n_44_);
lean_dec_ref(v_inst_40_);
lean_dec(v_inst_39_);
lean_dec(v_inst_36_);
lean_dec_ref(v_inst_34_);
return v_res_48_;
}
}
lean_object* initialize_Init(uint8_t builtin);
lean_object* initialize_Init(uint8_t builtin);
lean_object* initialize_mathlib_Mathlib(uint8_t builtin);
lean_object* initialize_tree_Formalism_LocalToGlobal_IndefiniteForms_IndefUse(uint8_t builtin);
lean_object* initialize_tree_Formalism_LocalToGlobal_IndefiniteForms_IndefExample(uint8_t builtin);
lean_object* initialize_tree_Formalism_LocalToGlobal_Divisibility_FramesLemmas(uint8_t builtin);
lean_object* initialize_tree_Formalism_QuotientMetricDivisors_FinalW(uint8_t builtin);
lean_object* initialize_tree_Formalism_LocalRingCardinality_Lemmas(uint8_t builtin);
lean_object* initialize_tree_Development_AbelianVarietyTheory_BlockTheory_DivisorBase_QuotientNormSquareData(uint8_t builtin);
static bool _G_initialized = false;
LEAN_EXPORT lean_object* initialize_tree_Development_AbelianVarietyTheory_Proofs_DivisorProofs_FunIffRowSlopeBound(uint8_t builtin) {
lean_object * res;
if (_G_initialized) return lean_io_result_mk_ok(lean_box(0));
_G_initialized = true;
res = initialize_Init(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_Init(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_mathlib_Mathlib(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_Formalism_LocalToGlobal_IndefiniteForms_IndefUse(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_Formalism_LocalToGlobal_IndefiniteForms_IndefExample(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_Formalism_LocalToGlobal_Divisibility_FramesLemmas(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_Formalism_QuotientMetricDivisors_FinalW(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_Formalism_LocalRingCardinality_Lemmas(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_Development_AbelianVarietyTheory_BlockTheory_DivisorBase_QuotientNormSquareData(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
return lean_io_result_mk_ok(lean_box(0));
}
#ifdef __cplusplus
}
#endif
