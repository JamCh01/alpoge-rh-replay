// Lean compiler output
// Module: Formalism.LocalToGlobal.SiegelLatticeTheory.CokernelGLCounts.RankPointCounts.DualFamilyCounting.CovolNOfSteps
// Imports: public import Init public meta import Init public import Mathlib public import Formalism.LocalToGlobal.SiegelLatticeTheory.CokernelGLCounts.RankPointCounts.DualFamilyCounting.CovolumeExponent
#include <lean/lean.h>
#if defined(__clang__)
#pragma clang diagnostic ignored "-Wunused-parameter"
#pragma clang diagnostic ignored "-Wunused-label"
#elif defined(__GNUC__) && !defined(__CLANG__)
#pragma GCC diagnostic ignored "-Wunused-parameter"
#pragma GCC diagnostic ignored "-Wunused-label"
#pragma GCC diagnostic ignored "-Wunused-but-set-variable"
#endif
#ifdef __cplusplus
extern "C" {
#endif
LEAN_EXPORT lean_object* lp_tree_Formalism_L2_SG_Pf_LsNc5_reim(lean_object*, uint8_t);
LEAN_EXPORT lean_object* lp_tree_Formalism_L2_SG_Pf_LsNc5_reim___boxed(lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_Formalism_L2_SG_Pf_LsNc5_reim(lean_object* v_c_1_, uint8_t v_t_2_){
_start:
{
if (v_t_2_ == 0)
{
lean_object* v_re_3_; 
v_re_3_ = lean_ctor_get(v_c_1_, 0);
lean_inc(v_re_3_);
return v_re_3_;
}
else
{
lean_object* v_im_4_; 
v_im_4_ = lean_ctor_get(v_c_1_, 1);
lean_inc(v_im_4_);
return v_im_4_;
}
}
}
LEAN_EXPORT lean_object* lp_tree_Formalism_L2_SG_Pf_LsNc5_reim___boxed(lean_object* v_c_5_, lean_object* v_t_6_){
_start:
{
uint8_t v_t_boxed_7_; lean_object* v_res_8_; 
v_t_boxed_7_ = lean_unbox(v_t_6_);
v_res_8_ = lp_tree_Formalism_L2_SG_Pf_LsNc5_reim(v_c_5_, v_t_boxed_7_);
lean_dec_ref(v_c_5_);
return v_res_8_;
}
}
lean_object* initialize_Init(uint8_t builtin);
lean_object* initialize_Init(uint8_t builtin);
lean_object* initialize_mathlib_Mathlib(uint8_t builtin);
lean_object* initialize_tree_Formalism_LocalToGlobal_SiegelLatticeTheory_CokernelGLCounts_RankPointCounts_DualFamilyCounting_CovolumeExponent(uint8_t builtin);
static bool _G_initialized = false;
LEAN_EXPORT lean_object* initialize_tree_Formalism_LocalToGlobal_SiegelLatticeTheory_CokernelGLCounts_RankPointCounts_DualFamilyCounting_CovolNOfSteps(uint8_t builtin) {
lean_object * res;
if (_G_initialized) return lean_io_result_mk_ok(lean_box(0));
_G_initialized = true;
res = initialize_Init(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_Init(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_mathlib_Mathlib(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_Formalism_LocalToGlobal_SiegelLatticeTheory_CokernelGLCounts_RankPointCounts_DualFamilyCounting_CovolumeExponent(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
return lean_io_result_mk_ok(lean_box(0));
}
#ifdef __cplusplus
}
#endif
