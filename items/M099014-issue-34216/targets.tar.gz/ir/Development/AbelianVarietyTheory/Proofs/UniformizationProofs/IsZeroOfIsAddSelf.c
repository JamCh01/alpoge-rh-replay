// Lean compiler output
// Module: Development.AbelianVarietyTheory.Proofs.UniformizationProofs.IsZeroOfIsAddSelf
// Imports: public import Init public meta import Init public import Mathlib public import ReciprocityTheory.ReductiveGroups.ArithmeticGeometry.ExtensionDescent.GtPtBridgeSt public import ReciprocityTheory.ReductiveGroups.ArithmeticGeometry.BirationalGeometry.ToroidalCompactification.ExistsZeroGt public import ReciprocityTheory.ReductiveGroups.ArithmeticGeometry.BirationalGeometry.ToroidalCompactification.BCTools public import Development.AbelianVarietyTheory.BlockTheory.UniformisationCharts.TorusPointForms
#include <lean/lean.h>
#if defined(__clang__)
#pragma clang diagnostic ignored "-Wunused-parameter"
#pragma clang diagnostic ignored "-Wunused-label"
#elif defined(__GNUC__) && !defined(__CLANG__)
#pragma GCC diagnostic ignored "-Wunused-parameter"
#pragma GCC diagnostic ignored "-Wunused-label"
#pragma GCC diagnostic ignored "-Wunused-but-set-variable"
#endif
#ifdef __cplusplus
extern "C" {
#endif
lean_object* lp_mathlib_Equiv_symm___redArg(lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_GtPointsCompare_castGen___redArg(lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_GtPointsCompare_castGen___redArg___boxed(lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_GtPointsCompare_castGen(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_GtPointsCompare_castGen___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_GtPointsCompare_pairEquivOf___redArg___lam__0(lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_GtPointsCompare_pairEquivOf___redArg___lam__1(lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_GtPointsCompare_pairEquivOf___redArg(lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_GtPointsCompare_pairEquivOf(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_GtPointsCompare_pairEquivOf___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_GtPointsCompare_datumEquiv___lam__0(lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_GtPointsCompare_datumEquiv___lam__1(lean_object*);
static const lean_closure_object lp_tree_GlobalTheory_GtPointsCompare_datumEquiv___closed__0_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_closure_object) + sizeof(void*)*0, .m_other = 0, .m_tag = 245}, .m_fun = (void*)lp_tree_GlobalTheory_GtPointsCompare_datumEquiv___lam__0, .m_arity = 1, .m_num_fixed = 0, .m_objs = {} };
static const lean_object* lp_tree_GlobalTheory_GtPointsCompare_datumEquiv___closed__0 = (const lean_object*)&lp_tree_GlobalTheory_GtPointsCompare_datumEquiv___closed__0_value;
static const lean_closure_object lp_tree_GlobalTheory_GtPointsCompare_datumEquiv___closed__1_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_closure_object) + sizeof(void*)*0, .m_other = 0, .m_tag = 245}, .m_fun = (void*)lp_tree_GlobalTheory_GtPointsCompare_datumEquiv___lam__1, .m_arity = 1, .m_num_fixed = 0, .m_objs = {} };
static const lean_object* lp_tree_GlobalTheory_GtPointsCompare_datumEquiv___closed__1 = (const lean_object*)&lp_tree_GlobalTheory_GtPointsCompare_datumEquiv___closed__1_value;
static const lean_ctor_object lp_tree_GlobalTheory_GtPointsCompare_datumEquiv___closed__2_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 0, .m_other = 2, .m_tag = 0}, .m_objs = {((lean_object*)&lp_tree_GlobalTheory_GtPointsCompare_datumEquiv___closed__1_value),((lean_object*)&lp_tree_GlobalTheory_GtPointsCompare_datumEquiv___closed__0_value)}};
static const lean_object* lp_tree_GlobalTheory_GtPointsCompare_datumEquiv___closed__2 = (const lean_object*)&lp_tree_GlobalTheory_GtPointsCompare_datumEquiv___closed__2_value;
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_GtPointsCompare_datumEquiv(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_GtPointsCompare_datumEquiv___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_GtPointsCompare_castGen___redArg(lean_object* v_t_1_){
_start:
{
lean_inc_ref(v_t_1_);
return v_t_1_;
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_GtPointsCompare_castGen___redArg___boxed(lean_object* v_t_2_){
_start:
{
lean_object* v_res_3_; 
v_res_3_ = lp_tree_GlobalTheory_GtPointsCompare_castGen___redArg(v_t_2_);
lean_dec_ref(v_t_2_);
return v_res_3_;
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_GtPointsCompare_castGen(lean_object* v_X_4_, lean_object* v_Y_5_, lean_object* v_L_6_, lean_object* v_K_7_, lean_object* v_inst_8_, lean_object* v_00_u03c6_9_, lean_object* v_00_u03c6_x27_10_, lean_object* v_00_u03b5_11_, lean_object* v_h_12_, lean_object* v_t_13_){
_start:
{
lean_inc_ref(v_t_13_);
return v_t_13_;
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_GtPointsCompare_castGen___boxed(lean_object* v_X_14_, lean_object* v_Y_15_, lean_object* v_L_16_, lean_object* v_K_17_, lean_object* v_inst_18_, lean_object* v_00_u03c6_19_, lean_object* v_00_u03c6_x27_20_, lean_object* v_00_u03b5_21_, lean_object* v_h_22_, lean_object* v_t_23_){
_start:
{
lean_object* v_res_24_; 
v_res_24_ = lp_tree_GlobalTheory_GtPointsCompare_castGen(v_X_14_, v_Y_15_, v_L_16_, v_K_17_, v_inst_18_, v_00_u03c6_19_, v_00_u03c6_x27_20_, v_00_u03b5_21_, v_h_22_, v_t_23_);
lean_dec_ref(v_t_23_);
lean_dec_ref(v_00_u03b5_21_);
lean_dec_ref(v_00_u03c6_x27_20_);
lean_dec_ref(v_00_u03c6_19_);
lean_dec(v_inst_18_);
lean_dec_ref(v_L_16_);
lean_dec_ref(v_Y_15_);
lean_dec_ref(v_X_14_);
return v_res_24_;
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_GtPointsCompare_pairEquivOf___redArg___lam__0(lean_object* v_e_25_, lean_object* v_p_26_){
_start:
{
lean_object* v_fst_27_; lean_object* v_snd_28_; lean_object* v_toFun_29_; lean_object* v___x_31_; uint8_t v_isShared_32_; uint8_t v_isSharedCheck_37_; 
v_fst_27_ = lean_ctor_get(v_p_26_, 0);
lean_inc(v_fst_27_);
v_snd_28_ = lean_ctor_get(v_p_26_, 1);
lean_inc(v_snd_28_);
lean_dec_ref(v_p_26_);
v_toFun_29_ = lean_ctor_get(v_e_25_, 0);
v_isSharedCheck_37_ = !lean_is_exclusive(v_e_25_);
if (v_isSharedCheck_37_ == 0)
{
lean_object* v_unused_38_; 
v_unused_38_ = lean_ctor_get(v_e_25_, 1);
lean_dec(v_unused_38_);
v___x_31_ = v_e_25_;
v_isShared_32_ = v_isSharedCheck_37_;
goto v_resetjp_30_;
}
else
{
lean_inc(v_toFun_29_);
lean_dec(v_e_25_);
v___x_31_ = lean_box(0);
v_isShared_32_ = v_isSharedCheck_37_;
goto v_resetjp_30_;
}
v_resetjp_30_:
{
lean_object* v___x_33_; lean_object* v___x_35_; 
v___x_33_ = lean_apply_1(v_toFun_29_, v_snd_28_);
if (v_isShared_32_ == 0)
{
lean_ctor_set(v___x_31_, 1, v___x_33_);
lean_ctor_set(v___x_31_, 0, v_fst_27_);
v___x_35_ = v___x_31_;
goto v_reusejp_34_;
}
else
{
lean_object* v_reuseFailAlloc_36_; 
v_reuseFailAlloc_36_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_36_, 0, v_fst_27_);
lean_ctor_set(v_reuseFailAlloc_36_, 1, v___x_33_);
v___x_35_ = v_reuseFailAlloc_36_;
goto v_reusejp_34_;
}
v_reusejp_34_:
{
return v___x_35_;
}
}
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_GtPointsCompare_pairEquivOf___redArg___lam__1(lean_object* v_e_39_, lean_object* v_q_40_){
_start:
{
lean_object* v_y_41_; lean_object* v_g_42_; lean_object* v___x_43_; lean_object* v_toFun_44_; lean_object* v___x_46_; uint8_t v_isShared_47_; uint8_t v_isSharedCheck_52_; 
v_y_41_ = lean_ctor_get(v_q_40_, 0);
lean_inc(v_y_41_);
v_g_42_ = lean_ctor_get(v_q_40_, 1);
lean_inc_ref(v_g_42_);
lean_dec_ref(v_q_40_);
v___x_43_ = lp_mathlib_Equiv_symm___redArg(v_e_39_);
v_toFun_44_ = lean_ctor_get(v___x_43_, 0);
v_isSharedCheck_52_ = !lean_is_exclusive(v___x_43_);
if (v_isSharedCheck_52_ == 0)
{
lean_object* v_unused_53_; 
v_unused_53_ = lean_ctor_get(v___x_43_, 1);
lean_dec(v_unused_53_);
v___x_46_ = v___x_43_;
v_isShared_47_ = v_isSharedCheck_52_;
goto v_resetjp_45_;
}
else
{
lean_inc(v_toFun_44_);
lean_dec(v___x_43_);
v___x_46_ = lean_box(0);
v_isShared_47_ = v_isSharedCheck_52_;
goto v_resetjp_45_;
}
v_resetjp_45_:
{
lean_object* v___x_48_; lean_object* v___x_50_; 
v___x_48_ = lean_apply_1(v_toFun_44_, v_g_42_);
if (v_isShared_47_ == 0)
{
lean_ctor_set(v___x_46_, 1, v___x_48_);
lean_ctor_set(v___x_46_, 0, v_y_41_);
v___x_50_ = v___x_46_;
goto v_reusejp_49_;
}
else
{
lean_object* v_reuseFailAlloc_51_; 
v_reuseFailAlloc_51_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_51_, 0, v_y_41_);
lean_ctor_set(v_reuseFailAlloc_51_, 1, v___x_48_);
v___x_50_ = v_reuseFailAlloc_51_;
goto v_reusejp_49_;
}
v_reusejp_49_:
{
return v___x_50_;
}
}
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_GtPointsCompare_pairEquivOf___redArg(lean_object* v_e_54_){
_start:
{
lean_object* v___f_55_; lean_object* v___f_56_; lean_object* v___x_57_; 
lean_inc_ref(v_e_54_);
v___f_55_ = lean_alloc_closure((void*)(lp_tree_GlobalTheory_GtPointsCompare_pairEquivOf___redArg___lam__0), 2, 1);
lean_closure_set(v___f_55_, 0, v_e_54_);
v___f_56_ = lean_alloc_closure((void*)(lp_tree_GlobalTheory_GtPointsCompare_pairEquivOf___redArg___lam__1), 2, 1);
lean_closure_set(v___f_56_, 0, v_e_54_);
v___x_57_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_57_, 0, v___f_55_);
lean_ctor_set(v___x_57_, 1, v___f_56_);
return v___x_57_;
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_GtPointsCompare_pairEquivOf(lean_object* v_R_58_, lean_object* v_inst_59_, lean_object* v_inst_60_, lean_object* v_D_61_, lean_object* v_F_62_, lean_object* v_inst_63_, lean_object* v_inst_64_, lean_object* v_k_65_, lean_object* v_e_66_, lean_object* v_H_67_){
_start:
{
lean_object* v___x_68_; 
v___x_68_ = lp_tree_GlobalTheory_GtPointsCompare_pairEquivOf___redArg(v_e_66_);
return v___x_68_;
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_GtPointsCompare_pairEquivOf___boxed(lean_object* v_R_69_, lean_object* v_inst_70_, lean_object* v_inst_71_, lean_object* v_D_72_, lean_object* v_F_73_, lean_object* v_inst_74_, lean_object* v_inst_75_, lean_object* v_k_76_, lean_object* v_e_77_, lean_object* v_H_78_){
_start:
{
lean_object* v_res_79_; 
v_res_79_ = lp_tree_GlobalTheory_GtPointsCompare_pairEquivOf(v_R_69_, v_inst_70_, v_inst_71_, v_D_72_, v_F_73_, v_inst_74_, v_inst_75_, v_k_76_, v_e_77_, v_H_78_);
lean_dec(v_k_76_);
lean_dec_ref(v_inst_75_);
lean_dec_ref(v_inst_74_);
lean_dec_ref(v_D_72_);
lean_dec_ref(v_inst_70_);
return v_res_79_;
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_GtPointsCompare_datumEquiv___lam__0(lean_object* v_h_80_){
_start:
{
lean_object* v_e_81_; lean_object* v_chi_82_; lean_object* v___x_84_; uint8_t v_isShared_85_; uint8_t v_isSharedCheck_90_; 
v_e_81_ = lean_ctor_get(v_h_80_, 0);
v_chi_82_ = lean_ctor_get(v_h_80_, 1);
v_isSharedCheck_90_ = !lean_is_exclusive(v_h_80_);
if (v_isSharedCheck_90_ == 0)
{
v___x_84_ = v_h_80_;
v_isShared_85_ = v_isSharedCheck_90_;
goto v_resetjp_83_;
}
else
{
lean_inc(v_chi_82_);
lean_inc(v_e_81_);
lean_dec(v_h_80_);
v___x_84_ = lean_box(0);
v_isShared_85_ = v_isSharedCheck_90_;
goto v_resetjp_83_;
}
v_resetjp_83_:
{
lean_object* v___x_86_; lean_object* v___x_88_; 
v___x_86_ = lp_mathlib_Equiv_symm___redArg(v_chi_82_);
if (v_isShared_85_ == 0)
{
lean_ctor_set(v___x_84_, 1, v___x_86_);
v___x_88_ = v___x_84_;
goto v_reusejp_87_;
}
else
{
lean_object* v_reuseFailAlloc_89_; 
v_reuseFailAlloc_89_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_89_, 0, v_e_81_);
lean_ctor_set(v_reuseFailAlloc_89_, 1, v___x_86_);
v___x_88_ = v_reuseFailAlloc_89_;
goto v_reusejp_87_;
}
v_reusejp_87_:
{
return v___x_88_;
}
}
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_GtPointsCompare_datumEquiv___lam__1(lean_object* v_p_91_){
_start:
{
lean_object* v_fst_92_; lean_object* v_snd_93_; lean_object* v___x_95_; uint8_t v_isShared_96_; uint8_t v_isSharedCheck_101_; 
v_fst_92_ = lean_ctor_get(v_p_91_, 0);
v_snd_93_ = lean_ctor_get(v_p_91_, 1);
v_isSharedCheck_101_ = !lean_is_exclusive(v_p_91_);
if (v_isSharedCheck_101_ == 0)
{
v___x_95_ = v_p_91_;
v_isShared_96_ = v_isSharedCheck_101_;
goto v_resetjp_94_;
}
else
{
lean_inc(v_snd_93_);
lean_inc(v_fst_92_);
lean_dec(v_p_91_);
v___x_95_ = lean_box(0);
v_isShared_96_ = v_isSharedCheck_101_;
goto v_resetjp_94_;
}
v_resetjp_94_:
{
lean_object* v___x_97_; lean_object* v___x_99_; 
v___x_97_ = lp_mathlib_Equiv_symm___redArg(v_snd_93_);
if (v_isShared_96_ == 0)
{
lean_ctor_set(v___x_95_, 1, v___x_97_);
v___x_99_ = v___x_95_;
goto v_reusejp_98_;
}
else
{
lean_object* v_reuseFailAlloc_100_; 
v_reuseFailAlloc_100_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_100_, 0, v_fst_92_);
lean_ctor_set(v_reuseFailAlloc_100_, 1, v___x_97_);
v___x_99_ = v_reuseFailAlloc_100_;
goto v_reusejp_98_;
}
v_reusejp_98_:
{
return v___x_99_;
}
}
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_GtPointsCompare_datumEquiv(lean_object* v_R_107_, lean_object* v_inst_108_, lean_object* v_inst_109_, lean_object* v_D_110_, lean_object* v_F_111_, lean_object* v_inst_112_, lean_object* v_inst_113_, lean_object* v_E_114_){
_start:
{
lean_object* v___x_115_; 
v___x_115_ = ((lean_object*)(lp_tree_GlobalTheory_GtPointsCompare_datumEquiv___closed__2));
return v___x_115_;
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_GtPointsCompare_datumEquiv___boxed(lean_object* v_R_116_, lean_object* v_inst_117_, lean_object* v_inst_118_, lean_object* v_D_119_, lean_object* v_F_120_, lean_object* v_inst_121_, lean_object* v_inst_122_, lean_object* v_E_123_){
_start:
{
lean_object* v_res_124_; 
v_res_124_ = lp_tree_GlobalTheory_GtPointsCompare_datumEquiv(v_R_116_, v_inst_117_, v_inst_118_, v_D_119_, v_F_120_, v_inst_121_, v_inst_122_, v_E_123_);
lean_dec_ref(v_E_123_);
lean_dec_ref(v_inst_122_);
lean_dec_ref(v_inst_121_);
lean_dec_ref(v_D_119_);
lean_dec_ref(v_inst_117_);
return v_res_124_;
}
}
lean_object* initialize_Init(uint8_t builtin);
lean_object* initialize_Init(uint8_t builtin);
lean_object* initialize_mathlib_Mathlib(uint8_t builtin);
lean_object* initialize_tree_ReciprocityTheory_ReductiveGroups_ArithmeticGeometry_ExtensionDescent_GtPtBridgeSt(uint8_t builtin);
lean_object* initialize_tree_ReciprocityTheory_ReductiveGroups_ArithmeticGeometry_BirationalGeometry_ToroidalCompactification_ExistsZeroGt(uint8_t builtin);
lean_object* initialize_tree_ReciprocityTheory_ReductiveGroups_ArithmeticGeometry_BirationalGeometry_ToroidalCompactification_BCTools(uint8_t builtin);
lean_object* initialize_tree_Development_AbelianVarietyTheory_BlockTheory_UniformisationCharts_TorusPointForms(uint8_t builtin);
static bool _G_initialized = false;
LEAN_EXPORT lean_object* initialize_tree_Development_AbelianVarietyTheory_Proofs_UniformizationProofs_IsZeroOfIsAddSelf(uint8_t builtin) {
lean_object * res;
if (_G_initialized) return lean_io_result_mk_ok(lean_box(0));
_G_initialized = true;
res = initialize_Init(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_Init(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_mathlib_Mathlib(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_ReciprocityTheory_ReductiveGroups_ArithmeticGeometry_ExtensionDescent_GtPtBridgeSt(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_ReciprocityTheory_ReductiveGroups_ArithmeticGeometry_BirationalGeometry_ToroidalCompactification_ExistsZeroGt(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_ReciprocityTheory_ReductiveGroups_ArithmeticGeometry_BirationalGeometry_ToroidalCompactification_BCTools(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_Development_AbelianVarietyTheory_BlockTheory_UniformisationCharts_TorusPointForms(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
return lean_io_result_mk_ok(lean_box(0));
}
#ifdef __cplusplus
}
#endif
