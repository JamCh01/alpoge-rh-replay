// Lean compiler output
// Module: Development.AbelianVarietyTheory.Proofs.FlagMeasures.CanonicalLatticeFlagIsotropicSelfDual
// Imports: public import Init public meta import Init public import Mathlib public import Development.AbelianVarietyTheory.Definitions.SemilocalFrames.LayerProd public import Formalism.HarderNarasimhan.ShiftInvariance public import Development.AbelianVarietyTheory.Proofs.FlagMeasures.AutPointLatticeIntersectionSelfDualPropertiesStatement public import Development.AbelianVarietyTheory.Proofs.FlagMeasures.CanonicalLatticeFiltrationSizePropertiesStatement public import Development.AbelianVarietyTheory.Proofs.FlagMeasures.OrthogonalCanonicalFiltrationStepsAutPointStatement
#include <lean/lean.h>
#if defined(__clang__)
#pragma clang diagnostic ignored "-Wunused-parameter"
#pragma clang diagnostic ignored "-Wunused-label"
#elif defined(__GNUC__) && !defined(__CLANG__)
#pragma GCC diagnostic ignored "-Wunused-parameter"
#pragma GCC diagnostic ignored "-Wunused-label"
#pragma GCC diagnostic ignored "-Wunused-but-set-variable"
#endif
#ifdef __cplusplus
extern "C" {
#endif
lean_object* l_List_finRange(lean_object*);
lean_object* lp_tree_Formalism_UG_hform___redArg(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_FlagIso_hR___redArg___lam__0(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_FlagIso_hR___redArg(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_FlagIso_hR(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_FlagIso_hR___redArg___lam__0(lean_object* v_toCommRing_1_, lean_object* v___x_2_, lean_object* v_inst_3_, lean_object* v_J_4_, lean_object* v_x_5_, lean_object* v_y_6_){
_start:
{
lean_object* v___x_7_; 
v___x_7_ = lp_tree_Formalism_UG_hform___redArg(v_toCommRing_1_, v___x_2_, v_inst_3_, v_J_4_, v_x_5_, v_y_6_);
return v___x_7_;
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_FlagIso_hR___redArg(lean_object* v_inst_8_, lean_object* v_inst_9_, lean_object* v_n_10_, lean_object* v_J_11_, lean_object* v_x_12_){
_start:
{
lean_object* v_toCommRing_13_; lean_object* v___x_14_; lean_object* v___f_15_; 
v_toCommRing_13_ = lean_ctor_get(v_inst_8_, 0);
lean_inc_ref(v_toCommRing_13_);
lean_dec_ref(v_inst_8_);
v___x_14_ = l_List_finRange(v_n_10_);
v___f_15_ = lean_alloc_closure((void*)(lp_tree_GlobalTheory_FlagIso_hR___redArg___lam__0), 6, 5);
lean_closure_set(v___f_15_, 0, v_toCommRing_13_);
lean_closure_set(v___f_15_, 1, v___x_14_);
lean_closure_set(v___f_15_, 2, v_inst_9_);
lean_closure_set(v___f_15_, 3, v_J_11_);
lean_closure_set(v___f_15_, 4, v_x_12_);
return v___f_15_;
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_FlagIso_hR(lean_object* v_E_16_, lean_object* v_inst_17_, lean_object* v_inst_18_, lean_object* v_n_19_, lean_object* v_J_20_, lean_object* v_x_21_){
_start:
{
lean_object* v___x_22_; 
v___x_22_ = lp_tree_GlobalTheory_FlagIso_hR___redArg(v_inst_17_, v_inst_18_, v_n_19_, v_J_20_, v_x_21_);
return v___x_22_;
}
}
lean_object* initialize_Init(uint8_t builtin);
lean_object* initialize_Init(uint8_t builtin);
lean_object* initialize_mathlib_Mathlib(uint8_t builtin);
lean_object* initialize_tree_Development_AbelianVarietyTheory_Definitions_SemilocalFrames_LayerProd(uint8_t builtin);
lean_object* initialize_tree_Formalism_HarderNarasimhan_ShiftInvariance(uint8_t builtin);
lean_object* initialize_tree_Development_AbelianVarietyTheory_Proofs_FlagMeasures_AutPointLatticeIntersectionSelfDualPropertiesStatement(uint8_t builtin);
lean_object* initialize_tree_Development_AbelianVarietyTheory_Proofs_FlagMeasures_CanonicalLatticeFiltrationSizePropertiesStatement(uint8_t builtin);
lean_object* initialize_tree_Development_AbelianVarietyTheory_Proofs_FlagMeasures_OrthogonalCanonicalFiltrationStepsAutPointStatement(uint8_t builtin);
static bool _G_initialized = false;
LEAN_EXPORT lean_object* initialize_tree_Development_AbelianVarietyTheory_Proofs_FlagMeasures_CanonicalLatticeFlagIsotropicSelfDual(uint8_t builtin) {
lean_object * res;
if (_G_initialized) return lean_io_result_mk_ok(lean_box(0));
_G_initialized = true;
res = initialize_Init(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_Init(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_mathlib_Mathlib(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_Development_AbelianVarietyTheory_Definitions_SemilocalFrames_LayerProd(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_Formalism_HarderNarasimhan_ShiftInvariance(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_Development_AbelianVarietyTheory_Proofs_FlagMeasures_AutPointLatticeIntersectionSelfDualPropertiesStatement(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_Development_AbelianVarietyTheory_Proofs_FlagMeasures_CanonicalLatticeFiltrationSizePropertiesStatement(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_Development_AbelianVarietyTheory_Proofs_FlagMeasures_OrthogonalCanonicalFiltrationStepsAutPointStatement(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
return lean_io_result_mk_ok(lean_box(0));
}
#ifdef __cplusplus
}
#endif
