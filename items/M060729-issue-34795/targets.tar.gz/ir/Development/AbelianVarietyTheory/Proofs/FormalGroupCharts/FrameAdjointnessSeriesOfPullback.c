// Lean compiler output
// Module: Development.AbelianVarietyTheory.Proofs.FormalGroupCharts.FrameAdjointnessSeriesOfPullback
// Imports: public import Init public meta import Init public import Mathlib public import Formalism.SharpRestriction.Divisibility.GeneratorPowers.GermCut public import Formalism.SharpRestriction.Divisibility.GeneratorPowers.GermBGen public import Formalism.SharpRestriction.Divisibility.GeneratorPowers.ChartPrimTrPfA public import Formalism.SharpRestriction.Divisibility.GeneratorPowers.IntChartPf public import Formalism.SharpRestriction.Divisibility.GeneratorPowers.ExistsTruncatedIntegralChart public import Formalism.LocalToGlobal.ProjectiveLattices.PlaceBelow public import ReciprocityTheory.ReductiveGroups.ArithmeticGeometry.ExtensionDescent.SecBaseChangeAnySt public import ReciprocityTheory.ReductiveGroups.ArithmeticGeometry.BirationalGeometry.ToroidalCompactification.RosVal public import Development.AbelianVarietyTheory.Proofs.FormalGroupCharts.FrameSymmetryIffPullback
#include <lean/lean.h>
#if defined(__clang__)
#pragma clang diagnostic ignored "-Wunused-parameter"
#pragma clang diagnostic ignored "-Wunused-label"
#elif defined(__GNUC__) && !defined(__CLANG__)
#pragma GCC diagnostic ignored "-Wunused-parameter"
#pragma GCC diagnostic ignored "-Wunused-label"
#pragma GCC diagnostic ignored "-Wunused-but-set-variable"
#endif
#ifdef __cplusplus
extern "C" {
#endif
lean_object* lp_tree_Formalism_L2_Pj_c_u03b5(lean_object*, lean_object*);
lean_object* lean_int_neg(lean_object*);
lean_object* lp_tree_Formalism_L2_Pj_c_u03b5___boxed(lean_object*, lean_object*);
lean_object* l_Sum_elim___redArg(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_FrameAdjUp_ad_u03b5___lam__0(lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_FrameAdjUp_ad_u03b5___lam__0___boxed(lean_object*, lean_object*);
static const lean_closure_object lp_tree_GlobalTheory_FrameAdjUp_ad_u03b5___closed__0_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_closure_object) + sizeof(void*)*1, .m_other = 0, .m_tag = 245}, .m_fun = (void*)lp_tree_GlobalTheory_FrameAdjUp_ad_u03b5___lam__0___boxed, .m_arity = 2, .m_num_fixed = 1, .m_objs = {((lean_object*)(((size_t)(2) << 1) | 1))} };
static const lean_object* lp_tree_GlobalTheory_FrameAdjUp_ad_u03b5___closed__0 = (const lean_object*)&lp_tree_GlobalTheory_FrameAdjUp_ad_u03b5___closed__0_value;
static const lean_closure_object lp_tree_GlobalTheory_FrameAdjUp_ad_u03b5___closed__1_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_closure_object) + sizeof(void*)*1, .m_other = 0, .m_tag = 245}, .m_fun = (void*)lp_tree_Formalism_L2_Pj_c_u03b5___boxed, .m_arity = 2, .m_num_fixed = 1, .m_objs = {((lean_object*)(((size_t)(2) << 1) | 1))} };
static const lean_object* lp_tree_GlobalTheory_FrameAdjUp_ad_u03b5___closed__1 = (const lean_object*)&lp_tree_GlobalTheory_FrameAdjUp_ad_u03b5___closed__1_value;
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_FrameAdjUp_ad_u03b5(lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_FrameAdjUp_ad_u03b5___lam__0(lean_object* v___x_1_, lean_object* v_I_2_){
_start:
{
lean_object* v___x_3_; lean_object* v___x_4_; 
v___x_3_ = lp_tree_Formalism_L2_Pj_c_u03b5(v___x_1_, v_I_2_);
v___x_4_ = lean_int_neg(v___x_3_);
lean_dec(v___x_3_);
return v___x_4_;
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_FrameAdjUp_ad_u03b5___lam__0___boxed(lean_object* v___x_5_, lean_object* v_I_6_){
_start:
{
lean_object* v_res_7_; 
v_res_7_ = lp_tree_GlobalTheory_FrameAdjUp_ad_u03b5___lam__0(v___x_5_, v_I_6_);
lean_dec(v_I_6_);
lean_dec(v___x_5_);
return v_res_7_;
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_FrameAdjUp_ad_u03b5(lean_object* v_a_12_){
_start:
{
lean_object* v___f_13_; lean_object* v___x_14_; lean_object* v___x_15_; 
v___f_13_ = ((lean_object*)(lp_tree_GlobalTheory_FrameAdjUp_ad_u03b5___closed__0));
v___x_14_ = ((lean_object*)(lp_tree_GlobalTheory_FrameAdjUp_ad_u03b5___closed__1));
v___x_15_ = l_Sum_elim___redArg(v___x_14_, v___f_13_, v_a_12_);
return v___x_15_;
}
}
lean_object* initialize_Init(uint8_t builtin);
lean_object* initialize_Init(uint8_t builtin);
lean_object* initialize_mathlib_Mathlib(uint8_t builtin);
lean_object* initialize_tree_Formalism_SharpRestriction_Divisibility_GeneratorPowers_GermCut(uint8_t builtin);
lean_object* initialize_tree_Formalism_SharpRestriction_Divisibility_GeneratorPowers_GermBGen(uint8_t builtin);
lean_object* initialize_tree_Formalism_SharpRestriction_Divisibility_GeneratorPowers_ChartPrimTrPfA(uint8_t builtin);
lean_object* initialize_tree_Formalism_SharpRestriction_Divisibility_GeneratorPowers_IntChartPf(uint8_t builtin);
lean_object* initialize_tree_Formalism_SharpRestriction_Divisibility_GeneratorPowers_ExistsTruncatedIntegralChart(uint8_t builtin);
lean_object* initialize_tree_Formalism_LocalToGlobal_ProjectiveLattices_PlaceBelow(uint8_t builtin);
lean_object* initialize_tree_ReciprocityTheory_ReductiveGroups_ArithmeticGeometry_ExtensionDescent_SecBaseChangeAnySt(uint8_t builtin);
lean_object* initialize_tree_ReciprocityTheory_ReductiveGroups_ArithmeticGeometry_BirationalGeometry_ToroidalCompactification_RosVal(uint8_t builtin);
lean_object* initialize_tree_Development_AbelianVarietyTheory_Proofs_FormalGroupCharts_FrameSymmetryIffPullback(uint8_t builtin);
static bool _G_initialized = false;
LEAN_EXPORT lean_object* initialize_tree_Development_AbelianVarietyTheory_Proofs_FormalGroupCharts_FrameAdjointnessSeriesOfPullback(uint8_t builtin) {
lean_object * res;
if (_G_initialized) return lean_io_result_mk_ok(lean_box(0));
_G_initialized = true;
res = initialize_Init(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_Init(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_mathlib_Mathlib(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_Formalism_SharpRestriction_Divisibility_GeneratorPowers_GermCut(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_Formalism_SharpRestriction_Divisibility_GeneratorPowers_GermBGen(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_Formalism_SharpRestriction_Divisibility_GeneratorPowers_ChartPrimTrPfA(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_Formalism_SharpRestriction_Divisibility_GeneratorPowers_IntChartPf(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_Formalism_SharpRestriction_Divisibility_GeneratorPowers_ExistsTruncatedIntegralChart(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_Formalism_LocalToGlobal_ProjectiveLattices_PlaceBelow(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_ReciprocityTheory_ReductiveGroups_ArithmeticGeometry_ExtensionDescent_SecBaseChangeAnySt(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_ReciprocityTheory_ReductiveGroups_ArithmeticGeometry_BirationalGeometry_ToroidalCompactification_RosVal(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_Development_AbelianVarietyTheory_Proofs_FormalGroupCharts_FrameSymmetryIffPullback(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
return lean_io_result_mk_ok(lean_box(0));
}
#ifdef __cplusplus
}
#endif
