// Lean compiler output
// Module: Development.AbelianVarietyTheory.Proofs.FlagMeasures.RankTwoDefiniteUnimodularHermitianClassBound
// Imports: public import Init public meta import Init public import Mathlib public import Development.AbelianVarietyTheory.Statements.CuspFrameWeights.SameKindIsometric public import Development.AbelianVarietyTheory.Proofs.FlagMeasures.ClassNumberLeMinkowskiCount public import Development.AbelianVarietyTheory.Proofs.FlagMeasures.RootDiscrGeThreeHalvesOfIsTotallyComplexStatement public import Development.AbelianVarietyTheory.Proofs.FlagMeasures.DefiniteUnimodularPlaneSplitAlongVectorStatement public import Development.AbelianVarietyTheory.Proofs.FlagMeasures.CardUnimodularGluingsTwoLinesLeStatement public import Development.AbelianVarietyTheory.Proofs.FlagMeasures.NcardRealGeneratedIdealsLeStatement public import Development.AbelianVarietyTheory.Proofs.FlagMeasures.ExistsShortVectorUnimodularHermitianLatticeRankTStatement public import Development.AbelianVarietyTheory.Proofs.FlagMeasures.CardRankOneHermitianLatticeClassesLeStatement
#include <lean/lean.h>
#if defined(__clang__)
#pragma clang diagnostic ignored "-Wunused-parameter"
#pragma clang diagnostic ignored "-Wunused-label"
#elif defined(__GNUC__) && !defined(__CLANG__)
#pragma GCC diagnostic ignored "-Wunused-parameter"
#pragma GCC diagnostic ignored "-Wunused-label"
#pragma GCC diagnostic ignored "-Wunused-but-set-variable"
#endif
#ifdef __cplusplus
extern "C" {
#endif
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_RankTwoCount_pull(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_RankTwoCount_pull___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_RankTwoCount_pull(lean_object* v_E_1_, lean_object* v_inst_2_, lean_object* v_r_3_, lean_object* v_00_u03b3_4_, lean_object* v_00_u039b_5_){
_start:
{
lean_object* v___x_6_; 
v___x_6_ = lean_box(0);
return v___x_6_;
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_RankTwoCount_pull___boxed(lean_object* v_E_7_, lean_object* v_inst_8_, lean_object* v_r_9_, lean_object* v_00_u03b3_10_, lean_object* v_00_u039b_11_){
_start:
{
lean_object* v_res_12_; 
v_res_12_ = lp_tree_GlobalTheory_RankTwoCount_pull(v_E_7_, v_inst_8_, v_r_9_, v_00_u03b3_10_, v_00_u039b_11_);
lean_dec_ref(v_00_u03b3_10_);
lean_dec(v_r_9_);
lean_dec_ref(v_inst_8_);
return v_res_12_;
}
}
lean_object* initialize_Init(uint8_t builtin);
lean_object* initialize_Init(uint8_t builtin);
lean_object* initialize_mathlib_Mathlib(uint8_t builtin);
lean_object* initialize_tree_Development_AbelianVarietyTheory_Statements_CuspFrameWeights_SameKindIsometric(uint8_t builtin);
lean_object* initialize_tree_Development_AbelianVarietyTheory_Proofs_FlagMeasures_ClassNumberLeMinkowskiCount(uint8_t builtin);
lean_object* initialize_tree_Development_AbelianVarietyTheory_Proofs_FlagMeasures_RootDiscrGeThreeHalvesOfIsTotallyComplexStatement(uint8_t builtin);
lean_object* initialize_tree_Development_AbelianVarietyTheory_Proofs_FlagMeasures_DefiniteUnimodularPlaneSplitAlongVectorStatement(uint8_t builtin);
lean_object* initialize_tree_Development_AbelianVarietyTheory_Proofs_FlagMeasures_CardUnimodularGluingsTwoLinesLeStatement(uint8_t builtin);
lean_object* initialize_tree_Development_AbelianVarietyTheory_Proofs_FlagMeasures_NcardRealGeneratedIdealsLeStatement(uint8_t builtin);
lean_object* initialize_tree_Development_AbelianVarietyTheory_Proofs_FlagMeasures_ExistsShortVectorUnimodularHermitianLatticeRankTStatement(uint8_t builtin);
lean_object* initialize_tree_Development_AbelianVarietyTheory_Proofs_FlagMeasures_CardRankOneHermitianLatticeClassesLeStatement(uint8_t builtin);
static bool _G_initialized = false;
LEAN_EXPORT lean_object* initialize_tree_Development_AbelianVarietyTheory_Proofs_FlagMeasures_RankTwoDefiniteUnimodularHermitianClassBound(uint8_t builtin) {
lean_object * res;
if (_G_initialized) return lean_io_result_mk_ok(lean_box(0));
_G_initialized = true;
res = initialize_Init(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_Init(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_mathlib_Mathlib(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_Development_AbelianVarietyTheory_Statements_CuspFrameWeights_SameKindIsometric(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_Development_AbelianVarietyTheory_Proofs_FlagMeasures_ClassNumberLeMinkowskiCount(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_Development_AbelianVarietyTheory_Proofs_FlagMeasures_RootDiscrGeThreeHalvesOfIsTotallyComplexStatement(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_Development_AbelianVarietyTheory_Proofs_FlagMeasures_DefiniteUnimodularPlaneSplitAlongVectorStatement(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_Development_AbelianVarietyTheory_Proofs_FlagMeasures_CardUnimodularGluingsTwoLinesLeStatement(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_Development_AbelianVarietyTheory_Proofs_FlagMeasures_NcardRealGeneratedIdealsLeStatement(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_Development_AbelianVarietyTheory_Proofs_FlagMeasures_ExistsShortVectorUnimodularHermitianLatticeRankTStatement(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_Development_AbelianVarietyTheory_Proofs_FlagMeasures_CardRankOneHermitianLatticeClassesLeStatement(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
return lean_io_result_mk_ok(lean_box(0));
}
#ifdef __cplusplus
}
#endif
