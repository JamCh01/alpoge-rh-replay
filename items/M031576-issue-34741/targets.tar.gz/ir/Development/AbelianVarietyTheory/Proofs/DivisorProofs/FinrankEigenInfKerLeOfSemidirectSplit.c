// Lean compiler output
// Module: Development.AbelianVarietyTheory.Proofs.DivisorProofs.FinrankEigenInfKerLeOfSemidirectSplit
// Imports: public import Init public meta import Init public import Mathlib public import Development.AbelianVarietyTheory.Definitions.Divisors.BadElt public import Development.AbelianVarietyTheory.Proofs.DivisorProofs.FinrankCharacterEigenspaceInfKerLeStatement
#include <lean/lean.h>
#if defined(__clang__)
#pragma clang diagnostic ignored "-Wunused-parameter"
#pragma clang diagnostic ignored "-Wunused-label"
#elif defined(__GNUC__) && !defined(__CLANG__)
#pragma GCC diagnostic ignored "-Wunused-parameter"
#pragma GCC diagnostic ignored "-Wunused-label"
#pragma GCC diagnostic ignored "-Wunused-but-set-variable"
#endif
#ifdef __cplusplus
extern "C" {
#endif
lean_object* lp_mathlib_Monoid_toMulOneClass___redArg(lean_object*);
lean_object* lp_mathlib_DivInvOneMonoid_toInvOneClass___redArg(lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_BadCount_Lift_comapEquiv___redArg___lam__0(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_BadCount_Lift_comapEquiv___redArg___lam__1(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_BadCount_Lift_comapEquiv___redArg(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_BadCount_Lift_comapEquiv___redArg___boxed(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_BadCount_Lift_comapEquiv(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_BadCount_Lift_comapEquiv___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_BadCount_Lift_comapEquiv___redArg___lam__0(lean_object* v_00_u03b9_1_, lean_object* v_toMul_2_, lean_object* v_x_3_){
_start:
{
lean_object* v_fst_4_; lean_object* v_snd_5_; lean_object* v___x_6_; lean_object* v___x_7_; 
v_fst_4_ = lean_ctor_get(v_x_3_, 0);
lean_inc(v_fst_4_);
v_snd_5_ = lean_ctor_get(v_x_3_, 1);
lean_inc(v_snd_5_);
lean_dec_ref(v_x_3_);
v___x_6_ = lean_apply_1(v_00_u03b9_1_, v_fst_4_);
v___x_7_ = lean_apply_2(v_toMul_2_, v___x_6_, v_snd_5_);
return v___x_7_;
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_BadCount_Lift_comapEquiv___redArg___lam__1(lean_object* v_00_u03c0_8_, lean_object* v_00_u03b9_9_, lean_object* v_toInv_10_, lean_object* v_toMul_11_, lean_object* v_00_u03b3_12_){
_start:
{
lean_object* v___x_13_; lean_object* v___x_14_; lean_object* v___x_15_; lean_object* v___x_16_; lean_object* v___x_17_; 
lean_inc(v_00_u03b3_12_);
v___x_13_ = lean_apply_1(v_00_u03c0_8_, v_00_u03b3_12_);
lean_inc(v___x_13_);
v___x_14_ = lean_apply_1(v_00_u03b9_9_, v___x_13_);
v___x_15_ = lean_apply_1(v_toInv_10_, v___x_14_);
v___x_16_ = lean_apply_2(v_toMul_11_, v___x_15_, v_00_u03b3_12_);
v___x_17_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_17_, 0, v___x_13_);
lean_ctor_set(v___x_17_, 1, v___x_16_);
return v___x_17_;
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_BadCount_Lift_comapEquiv___redArg(lean_object* v_inst_18_, lean_object* v_00_u03c0_19_, lean_object* v_00_u03b9_20_){
_start:
{
lean_object* v_toMonoid_21_; lean_object* v___x_22_; lean_object* v_toMul_23_; lean_object* v___x_24_; lean_object* v_toInv_25_; lean_object* v___x_27_; uint8_t v_isShared_28_; uint8_t v_isSharedCheck_34_; 
v_toMonoid_21_ = lean_ctor_get(v_inst_18_, 0);
v___x_22_ = lp_mathlib_Monoid_toMulOneClass___redArg(v_toMonoid_21_);
v_toMul_23_ = lean_ctor_get(v___x_22_, 1);
lean_inc(v_toMul_23_);
lean_dec_ref(v___x_22_);
v___x_24_ = lp_mathlib_DivInvOneMonoid_toInvOneClass___redArg(v_inst_18_);
v_toInv_25_ = lean_ctor_get(v___x_24_, 1);
v_isSharedCheck_34_ = !lean_is_exclusive(v___x_24_);
if (v_isSharedCheck_34_ == 0)
{
lean_object* v_unused_35_; 
v_unused_35_ = lean_ctor_get(v___x_24_, 0);
lean_dec(v_unused_35_);
v___x_27_ = v___x_24_;
v_isShared_28_ = v_isSharedCheck_34_;
goto v_resetjp_26_;
}
else
{
lean_inc(v_toInv_25_);
lean_dec(v___x_24_);
v___x_27_ = lean_box(0);
v_isShared_28_ = v_isSharedCheck_34_;
goto v_resetjp_26_;
}
v_resetjp_26_:
{
lean_object* v___f_29_; lean_object* v___f_30_; lean_object* v___x_32_; 
lean_inc(v_toMul_23_);
lean_inc(v_00_u03b9_20_);
v___f_29_ = lean_alloc_closure((void*)(lp_tree_GlobalTheory_BadCount_Lift_comapEquiv___redArg___lam__0), 3, 2);
lean_closure_set(v___f_29_, 0, v_00_u03b9_20_);
lean_closure_set(v___f_29_, 1, v_toMul_23_);
v___f_30_ = lean_alloc_closure((void*)(lp_tree_GlobalTheory_BadCount_Lift_comapEquiv___redArg___lam__1), 5, 4);
lean_closure_set(v___f_30_, 0, v_00_u03c0_19_);
lean_closure_set(v___f_30_, 1, v_00_u03b9_20_);
lean_closure_set(v___f_30_, 2, v_toInv_25_);
lean_closure_set(v___f_30_, 3, v_toMul_23_);
if (v_isShared_28_ == 0)
{
lean_ctor_set(v___x_27_, 1, v___f_30_);
lean_ctor_set(v___x_27_, 0, v___f_29_);
v___x_32_ = v___x_27_;
goto v_reusejp_31_;
}
else
{
lean_object* v_reuseFailAlloc_33_; 
v_reuseFailAlloc_33_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_33_, 0, v___f_29_);
lean_ctor_set(v_reuseFailAlloc_33_, 1, v___f_30_);
v___x_32_ = v_reuseFailAlloc_33_;
goto v_reusejp_31_;
}
v_reusejp_31_:
{
return v___x_32_;
}
}
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_BadCount_Lift_comapEquiv___redArg___boxed(lean_object* v_inst_36_, lean_object* v_00_u03c0_37_, lean_object* v_00_u03b9_38_){
_start:
{
lean_object* v_res_39_; 
v_res_39_ = lp_tree_GlobalTheory_BadCount_Lift_comapEquiv___redArg(v_inst_36_, v_00_u03c0_37_, v_00_u03b9_38_);
lean_dec_ref(v_inst_36_);
return v_res_39_;
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_BadCount_Lift_comapEquiv(lean_object* v_G_40_, lean_object* v_00_u0393_41_, lean_object* v_inst_42_, lean_object* v_inst_43_, lean_object* v_00_u03c0_44_, lean_object* v_00_u03b9_45_, lean_object* v_h_46_, lean_object* v_P_47_){
_start:
{
lean_object* v___x_48_; 
v___x_48_ = lp_tree_GlobalTheory_BadCount_Lift_comapEquiv___redArg(v_inst_43_, v_00_u03c0_44_, v_00_u03b9_45_);
return v___x_48_;
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_BadCount_Lift_comapEquiv___boxed(lean_object* v_G_49_, lean_object* v_00_u0393_50_, lean_object* v_inst_51_, lean_object* v_inst_52_, lean_object* v_00_u03c0_53_, lean_object* v_00_u03b9_54_, lean_object* v_h_55_, lean_object* v_P_56_){
_start:
{
lean_object* v_res_57_; 
v_res_57_ = lp_tree_GlobalTheory_BadCount_Lift_comapEquiv(v_G_49_, v_00_u0393_50_, v_inst_51_, v_inst_52_, v_00_u03c0_53_, v_00_u03b9_54_, v_h_55_, v_P_56_);
lean_dec_ref(v_inst_52_);
lean_dec_ref(v_inst_51_);
return v_res_57_;
}
}
lean_object* initialize_Init(uint8_t builtin);
lean_object* initialize_Init(uint8_t builtin);
lean_object* initialize_mathlib_Mathlib(uint8_t builtin);
lean_object* initialize_tree_Development_AbelianVarietyTheory_Definitions_Divisors_BadElt(uint8_t builtin);
lean_object* initialize_tree_Development_AbelianVarietyTheory_Proofs_DivisorProofs_FinrankCharacterEigenspaceInfKerLeStatement(uint8_t builtin);
static bool _G_initialized = false;
LEAN_EXPORT lean_object* initialize_tree_Development_AbelianVarietyTheory_Proofs_DivisorProofs_FinrankEigenInfKerLeOfSemidirectSplit(uint8_t builtin) {
lean_object * res;
if (_G_initialized) return lean_io_result_mk_ok(lean_box(0));
_G_initialized = true;
res = initialize_Init(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_Init(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_mathlib_Mathlib(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_Development_AbelianVarietyTheory_Definitions_Divisors_BadElt(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_Development_AbelianVarietyTheory_Proofs_DivisorProofs_FinrankCharacterEigenspaceInfKerLeStatement(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
return lean_io_result_mk_ok(lean_box(0));
}
#ifdef __cplusplus
}
#endif
