// Lean compiler output
// Module: GroundTheory.AutomorphicForms.MultiplicityOne.GL2ProductCompleteness.EqSmulOfMemWindowOrbitClosure
// Imports: public import Init public meta import Init public import Mathlib public import GroundTheory.AutomorphicForms.ArchimedeanWhittaker.MultOne public import GroundTheory.AutomorphicForms.MultiplicityOne.OpenSubgroupRep
#include <lean/lean.h>
#if defined(__clang__)
#pragma clang diagnostic ignored "-Wunused-parameter"
#pragma clang diagnostic ignored "-Wunused-label"
#elif defined(__GNUC__) && !defined(__CLANG__)
#pragma GCC diagnostic ignored "-Wunused-parameter"
#pragma GCC diagnostic ignored "-Wunused-label"
#pragma GCC diagnostic ignored "-Wunused-but-set-variable"
#endif
#ifdef __cplusplus
extern "C" {
#endif
LEAN_EXPORT lean_object* lp_tree_GroundTheory_Automorphic_GL2ProductCompleteness_orbitClosure(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_GroundTheory_Automorphic_GL2ProductCompleteness_orbitClosure___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_GroundTheory_Automorphic_GL2ProductCompleteness_orbitClosure(lean_object* v_G_1_, lean_object* v_G_u2081_2_, lean_object* v_inst_3_, lean_object* v_inst_4_, lean_object* v_inst_5_, lean_object* v_V_6_, lean_object* v_inst_7_, lean_object* v_inst_8_, lean_object* v_inst_9_, lean_object* v_00_u03c4_10_, lean_object* v_00_u03b9_u2081_11_, lean_object* v_v_12_){
_start:
{
lean_object* v___x_13_; 
v___x_13_ = lean_box(0);
return v___x_13_;
}
}
LEAN_EXPORT lean_object* lp_tree_GroundTheory_Automorphic_GL2ProductCompleteness_orbitClosure___boxed(lean_object* v_G_14_, lean_object* v_G_u2081_15_, lean_object* v_inst_16_, lean_object* v_inst_17_, lean_object* v_inst_18_, lean_object* v_V_19_, lean_object* v_inst_20_, lean_object* v_inst_21_, lean_object* v_inst_22_, lean_object* v_00_u03c4_23_, lean_object* v_00_u03b9_u2081_24_, lean_object* v_v_25_){
_start:
{
lean_object* v_res_26_; 
v_res_26_ = lp_tree_GroundTheory_Automorphic_GL2ProductCompleteness_orbitClosure(v_G_14_, v_G_u2081_15_, v_inst_16_, v_inst_17_, v_inst_18_, v_V_19_, v_inst_20_, v_inst_21_, v_inst_22_, v_00_u03c4_23_, v_00_u03b9_u2081_24_, v_v_25_);
lean_dec(v_v_25_);
lean_dec(v_00_u03b9_u2081_24_);
lean_dec(v_00_u03c4_23_);
lean_dec_ref(v_inst_21_);
lean_dec_ref(v_inst_20_);
lean_dec_ref(v_inst_18_);
lean_dec_ref(v_inst_16_);
return v_res_26_;
}
}
lean_object* initialize_Init(uint8_t builtin);
lean_object* initialize_Init(uint8_t builtin);
lean_object* initialize_mathlib_Mathlib(uint8_t builtin);
lean_object* initialize_tree_GroundTheory_AutomorphicForms_ArchimedeanWhittaker_MultOne(uint8_t builtin);
lean_object* initialize_tree_GroundTheory_AutomorphicForms_MultiplicityOne_OpenSubgroupRep(uint8_t builtin);
static bool _G_initialized = false;
LEAN_EXPORT lean_object* initialize_tree_GroundTheory_AutomorphicForms_MultiplicityOne_GL2ProductCompleteness_EqSmulOfMemWindowOrbitClosure(uint8_t builtin) {
lean_object * res;
if (_G_initialized) return lean_io_result_mk_ok(lean_box(0));
_G_initialized = true;
res = initialize_Init(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_Init(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_mathlib_Mathlib(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_GroundTheory_AutomorphicForms_ArchimedeanWhittaker_MultOne(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_GroundTheory_AutomorphicForms_MultiplicityOne_OpenSubgroupRep(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
return lean_io_result_mk_ok(lean_box(0));
}
#ifdef __cplusplus
}
#endif
