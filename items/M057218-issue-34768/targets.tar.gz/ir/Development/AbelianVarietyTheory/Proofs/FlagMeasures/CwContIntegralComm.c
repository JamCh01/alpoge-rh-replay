// Lean compiler output
// Module: Development.AbelianVarietyTheory.Proofs.FlagMeasures.CwContIntegralComm
// Imports: public import Init public meta import Init public import Mathlib public import Development.AbelianVarietyTheory.Definitions.Jets.SideFam public import Formalism.HermitianCurvature.WeylElementCommutesLevelOne public import Development.AbelianVarietyTheory.Proofs.JetHarmonics.DiscreteSeriesUnitarySmoothBasic public import Development.AbelianVarietyTheory.Proofs.JetHarmonics.DerivedActionDiscreteSeriesProperties public import Development.AbelianVarietyTheory.Proofs.JetHarmonics.FrechetContinuousContinuousOnOrbitHasDerivAt
#include <lean/lean.h>
#if defined(__clang__)
#pragma clang diagnostic ignored "-Wunused-parameter"
#pragma clang diagnostic ignored "-Wunused-label"
#elif defined(__GNUC__) && !defined(__CLANG__)
#pragma GCC diagnostic ignored "-Wunused-parameter"
#pragma GCC diagnostic ignored "-Wunused-label"
#pragma GCC diagnostic ignored "-Wunused-but-set-variable"
#endif
#ifdef __cplusplus
extern "C" {
#endif
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_CWIntegral_linOn___redArg___lam__0(lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_CWIntegral_linOn___redArg(lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_CWIntegral_linOn(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_CWIntegral_linOn___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_CWIntegral_linOn___redArg___lam__0(lean_object* v_B_1_, lean_object* v_v_2_){
_start:
{
lean_object* v___x_3_; 
v___x_3_ = lean_apply_1(v_B_1_, v_v_2_);
return v___x_3_;
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_CWIntegral_linOn___redArg(lean_object* v_B_4_){
_start:
{
lean_object* v___f_5_; 
v___f_5_ = lean_alloc_closure((void*)(lp_tree_GlobalTheory_CWIntegral_linOn___redArg___lam__0), 2, 1);
lean_closure_set(v___f_5_, 0, v_B_4_);
return v___f_5_;
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_CWIntegral_linOn(lean_object* v_k_6_, lean_object* v_r_7_, lean_object* v_R_8_, lean_object* v_V_9_, lean_object* v_inst_10_, lean_object* v_inst_11_, lean_object* v_B_12_, lean_object* v_ha_13_, lean_object* v_hs_14_){
_start:
{
lean_object* v___f_15_; 
v___f_15_ = lean_alloc_closure((void*)(lp_tree_GlobalTheory_CWIntegral_linOn___redArg___lam__0), 2, 1);
lean_closure_set(v___f_15_, 0, v_B_12_);
return v___f_15_;
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_CWIntegral_linOn___boxed(lean_object* v_k_16_, lean_object* v_r_17_, lean_object* v_R_18_, lean_object* v_V_19_, lean_object* v_inst_20_, lean_object* v_inst_21_, lean_object* v_B_22_, lean_object* v_ha_23_, lean_object* v_hs_24_){
_start:
{
lean_object* v_res_25_; 
v_res_25_ = lp_tree_GlobalTheory_CWIntegral_linOn(v_k_16_, v_r_17_, v_R_18_, v_V_19_, v_inst_20_, v_inst_21_, v_B_22_, v_ha_23_, v_hs_24_);
lean_dec(v_inst_21_);
lean_dec_ref(v_inst_20_);
lean_dec_ref(v_R_18_);
lean_dec(v_r_17_);
lean_dec(v_k_16_);
return v_res_25_;
}
}
lean_object* initialize_Init(uint8_t builtin);
lean_object* initialize_Init(uint8_t builtin);
lean_object* initialize_mathlib_Mathlib(uint8_t builtin);
lean_object* initialize_tree_Development_AbelianVarietyTheory_Definitions_Jets_SideFam(uint8_t builtin);
lean_object* initialize_tree_Formalism_HermitianCurvature_WeylElementCommutesLevelOne(uint8_t builtin);
lean_object* initialize_tree_Development_AbelianVarietyTheory_Proofs_JetHarmonics_DiscreteSeriesUnitarySmoothBasic(uint8_t builtin);
lean_object* initialize_tree_Development_AbelianVarietyTheory_Proofs_JetHarmonics_DerivedActionDiscreteSeriesProperties(uint8_t builtin);
lean_object* initialize_tree_Development_AbelianVarietyTheory_Proofs_JetHarmonics_FrechetContinuousContinuousOnOrbitHasDerivAt(uint8_t builtin);
static bool _G_initialized = false;
LEAN_EXPORT lean_object* initialize_tree_Development_AbelianVarietyTheory_Proofs_FlagMeasures_CwContIntegralComm(uint8_t builtin) {
lean_object * res;
if (_G_initialized) return lean_io_result_mk_ok(lean_box(0));
_G_initialized = true;
res = initialize_Init(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_Init(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_mathlib_Mathlib(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_Development_AbelianVarietyTheory_Definitions_Jets_SideFam(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_Formalism_HermitianCurvature_WeylElementCommutesLevelOne(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_Development_AbelianVarietyTheory_Proofs_JetHarmonics_DiscreteSeriesUnitarySmoothBasic(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_Development_AbelianVarietyTheory_Proofs_JetHarmonics_DerivedActionDiscreteSeriesProperties(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_Development_AbelianVarietyTheory_Proofs_JetHarmonics_FrechetContinuousContinuousOnOrbitHasDerivAt(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
return lean_io_result_mk_ok(lean_box(0));
}
#ifdef __cplusplus
}
#endif
