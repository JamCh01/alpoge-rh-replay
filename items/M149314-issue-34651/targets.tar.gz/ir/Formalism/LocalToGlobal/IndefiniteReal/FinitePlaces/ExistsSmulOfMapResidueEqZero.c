// Lean compiler output
// Module: Formalism.LocalToGlobal.IndefiniteReal.FinitePlaces.ExistsSmulOfMapResidueEqZero
// Imports: public import Init public meta import Init public import Mathlib public import Formalism.SubspaceCounting.ChoiceOfTopsRefined public import Formalism.SatakeDualWeyl.Statement public import Formalism.SatakeDualWeyl.StatementE public import Formalism.SharpRestriction.GenusPolyhedralBounds.RelativeIndexClassSets.LevGapLoc
#include <lean/lean.h>
#if defined(__clang__)
#pragma clang diagnostic ignored "-Wunused-parameter"
#pragma clang diagnostic ignored "-Wunused-label"
#elif defined(__GNUC__) && !defined(__CLANG__)
#pragma GCC diagnostic ignored "-Wunused-parameter"
#pragma GCC diagnostic ignored "-Wunused-label"
#pragma GCC diagnostic ignored "-Wunused-but-set-variable"
#endif
#ifdef __cplusplus
extern "C" {
#endif
lean_object* lp_mathlib_Matrix_transpose(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
lean_object* lp_mathlib_Matrix_diagonal___redArg(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
uint8_t lean_nat_dec_lt(lean_object*, lean_object*);
lean_object* lp_mathlib_Field_toDivisionRing___redArg(lean_object*);
lean_object* lp_mathlib_Ring_toAddGroupWithOne___redArg(lean_object*);
lean_object* lp_mathlib_Semifield_toCommGroupWithZero___redArg(lean_object*);
lean_object* lp_mathlib_CommGroupWithZero_toDivisionCommMonoid___redArg(lean_object*);
lean_object* lp_mathlib_DivInvOneMonoid_toInvOneClass___redArg(lean_object*);
lean_object* lp_mathlib_Field_toSemifield___redArg(lean_object*);
lean_object* lp_mathlib_Semifield_toDivisionSemiring___redArg(lean_object*);
lean_object* lp_mathlib_instDistribOfSemiring___redArg(lean_object*);
lean_object* lp_mathlib_instMulZeroClassOfSemiring___redArg(lean_object*);
lean_object* l_instDecidableEqFin___boxed(lean_object*, lean_object*, lean_object*);
lean_object* lp_mathlib_Matrix_diagonal(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_Formalism_IndefR_Fin_HCount_liftM___redArg(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_Formalism_IndefR_Fin_HCount_liftM(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_Formalism_IndefR_Fin_HCount_liftM___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_Formalism_IndefR_Fin_HCount_dgl___redArg___lam__0(lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_Formalism_IndefR_Fin_HCount_dgl___redArg___lam__0___boxed(lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_Formalism_IndefR_Fin_HCount_dgl___redArg___lam__1(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_Formalism_IndefR_Fin_HCount_dgl___redArg___lam__1___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_Formalism_IndefR_Fin_HCount_dgl___redArg(lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_Formalism_IndefR_Fin_HCount_dgl(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_Formalism_IndefR_Fin_HCount_scU___redArg___lam__0(lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_Formalism_IndefR_Fin_HCount_scU___redArg___lam__0___boxed(lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_Formalism_IndefR_Fin_HCount_scU___redArg___lam__1(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_Formalism_IndefR_Fin_HCount_scU___redArg___lam__2(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_Formalism_IndefR_Fin_HCount_scU___redArg(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_Formalism_IndefR_Fin_HCount_scU(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_Formalism_IndefR_Fin_HCount_scU___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_Formalism_IndefR_Fin_HCount_invT___redArg(lean_object*);
LEAN_EXPORT lean_object* lp_tree_Formalism_IndefR_Fin_HCount_invT(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_Formalism_IndefR_Fin_HCount_invT___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_Formalism_IndefR_Fin_HCount_liftM___redArg(lean_object* v_M_1_, lean_object* v_i_2_, lean_object* v_j_3_){
_start:
{
lean_object* v___x_4_; 
v___x_4_ = lean_apply_2(v_M_1_, v_i_2_, v_j_3_);
return v___x_4_;
}
}
LEAN_EXPORT lean_object* lp_tree_Formalism_IndefR_Fin_HCount_liftM(lean_object* v_L_5_, lean_object* v_inst_6_, lean_object* v_O_7_, lean_object* v_m_8_, lean_object* v_n_9_, lean_object* v_M_10_, lean_object* v_h_11_, lean_object* v_i_12_, lean_object* v_j_13_){
_start:
{
lean_object* v___x_14_; 
v___x_14_ = lean_apply_2(v_M_10_, v_i_12_, v_j_13_);
return v___x_14_;
}
}
LEAN_EXPORT lean_object* lp_tree_Formalism_IndefR_Fin_HCount_liftM___boxed(lean_object* v_L_15_, lean_object* v_inst_16_, lean_object* v_O_17_, lean_object* v_m_18_, lean_object* v_n_19_, lean_object* v_M_20_, lean_object* v_h_21_, lean_object* v_i_22_, lean_object* v_j_23_){
_start:
{
lean_object* v_res_24_; 
v_res_24_ = lp_tree_Formalism_IndefR_Fin_HCount_liftM(v_L_15_, v_inst_16_, v_O_17_, v_m_18_, v_n_19_, v_M_20_, v_h_21_, v_i_22_, v_j_23_);
lean_dec_ref(v_inst_16_);
return v_res_24_;
}
}
LEAN_EXPORT lean_object* lp_tree_Formalism_IndefR_Fin_HCount_dgl___redArg___lam__0(lean_object* v_e_25_, lean_object* v_inst_26_, lean_object* v_00_u03d6_27_, lean_object* v_i_28_){
_start:
{
uint8_t v___x_29_; 
v___x_29_ = lean_nat_dec_lt(v_i_28_, v_e_25_);
if (v___x_29_ == 0)
{
lean_object* v___x_30_; lean_object* v_toRing_31_; lean_object* v___x_32_; lean_object* v_toAddMonoidWithOne_33_; lean_object* v_toOne_34_; 
v___x_30_ = lp_mathlib_Field_toDivisionRing___redArg(v_inst_26_);
v_toRing_31_ = lean_ctor_get(v___x_30_, 0);
lean_inc_ref(v_toRing_31_);
lean_dec_ref(v___x_30_);
v___x_32_ = lp_mathlib_Ring_toAddGroupWithOne___redArg(v_toRing_31_);
v_toAddMonoidWithOne_33_ = lean_ctor_get(v___x_32_, 1);
lean_inc_ref(v_toAddMonoidWithOne_33_);
lean_dec_ref(v___x_32_);
v_toOne_34_ = lean_ctor_get(v_toAddMonoidWithOne_33_, 2);
lean_inc(v_toOne_34_);
lean_dec_ref(v_toAddMonoidWithOne_33_);
return v_toOne_34_;
}
else
{
lean_dec_ref(v_inst_26_);
lean_inc(v_00_u03d6_27_);
return v_00_u03d6_27_;
}
}
}
LEAN_EXPORT lean_object* lp_tree_Formalism_IndefR_Fin_HCount_dgl___redArg___lam__0___boxed(lean_object* v_e_35_, lean_object* v_inst_36_, lean_object* v_00_u03d6_37_, lean_object* v_i_38_){
_start:
{
lean_object* v_res_39_; 
v_res_39_ = lp_tree_Formalism_IndefR_Fin_HCount_dgl___redArg___lam__0(v_e_35_, v_inst_36_, v_00_u03d6_37_, v_i_38_);
lean_dec(v_i_38_);
lean_dec(v_00_u03d6_37_);
lean_dec(v_e_35_);
return v_res_39_;
}
}
LEAN_EXPORT lean_object* lp_tree_Formalism_IndefR_Fin_HCount_dgl___redArg___lam__1(lean_object* v_e_40_, lean_object* v_inst_41_, lean_object* v___x_42_, lean_object* v_00_u03d6_43_, lean_object* v_i_44_){
_start:
{
uint8_t v___x_45_; 
v___x_45_ = lean_nat_dec_lt(v_i_44_, v_e_40_);
if (v___x_45_ == 0)
{
lean_object* v___x_46_; lean_object* v_toRing_47_; lean_object* v___x_48_; lean_object* v_toAddMonoidWithOne_49_; lean_object* v_toOne_50_; 
lean_dec(v_00_u03d6_43_);
v___x_46_ = lp_mathlib_Field_toDivisionRing___redArg(v_inst_41_);
v_toRing_47_ = lean_ctor_get(v___x_46_, 0);
lean_inc_ref(v_toRing_47_);
lean_dec_ref(v___x_46_);
v___x_48_ = lp_mathlib_Ring_toAddGroupWithOne___redArg(v_toRing_47_);
v_toAddMonoidWithOne_49_ = lean_ctor_get(v___x_48_, 1);
lean_inc_ref(v_toAddMonoidWithOne_49_);
lean_dec_ref(v___x_48_);
v_toOne_50_ = lean_ctor_get(v_toAddMonoidWithOne_49_, 2);
lean_inc(v_toOne_50_);
lean_dec_ref(v_toAddMonoidWithOne_49_);
return v_toOne_50_;
}
else
{
lean_object* v___x_51_; lean_object* v___x_52_; lean_object* v___x_53_; lean_object* v_toInv_54_; lean_object* v___x_55_; 
lean_dec_ref(v_inst_41_);
v___x_51_ = lp_mathlib_Semifield_toCommGroupWithZero___redArg(v___x_42_);
v___x_52_ = lp_mathlib_CommGroupWithZero_toDivisionCommMonoid___redArg(v___x_51_);
v___x_53_ = lp_mathlib_DivInvOneMonoid_toInvOneClass___redArg(v___x_52_);
lean_dec_ref(v___x_52_);
v_toInv_54_ = lean_ctor_get(v___x_53_, 1);
lean_inc(v_toInv_54_);
lean_dec_ref(v___x_53_);
v___x_55_ = lean_apply_1(v_toInv_54_, v_00_u03d6_43_);
return v___x_55_;
}
}
}
LEAN_EXPORT lean_object* lp_tree_Formalism_IndefR_Fin_HCount_dgl___redArg___lam__1___boxed(lean_object* v_e_56_, lean_object* v_inst_57_, lean_object* v___x_58_, lean_object* v_00_u03d6_59_, lean_object* v_i_60_){
_start:
{
lean_object* v_res_61_; 
v_res_61_ = lp_tree_Formalism_IndefR_Fin_HCount_dgl___redArg___lam__1(v_e_56_, v_inst_57_, v___x_58_, v_00_u03d6_59_, v_i_60_);
lean_dec(v_i_60_);
lean_dec_ref(v___x_58_);
lean_dec(v_e_56_);
return v_res_61_;
}
}
LEAN_EXPORT lean_object* lp_tree_Formalism_IndefR_Fin_HCount_dgl___redArg(lean_object* v_inst_62_, lean_object* v_00_u03d6_63_, lean_object* v_n_64_, lean_object* v_e_65_){
_start:
{
lean_object* v___x_66_; lean_object* v___x_67_; lean_object* v_toSemiring_68_; lean_object* v___x_69_; lean_object* v_toZero_70_; lean_object* v___x_72_; uint8_t v_isShared_73_; uint8_t v_isSharedCheck_82_; 
v___x_66_ = lp_mathlib_Field_toSemifield___redArg(v_inst_62_);
lean_inc_ref(v___x_66_);
v___x_67_ = lp_mathlib_Semifield_toDivisionSemiring___redArg(v___x_66_);
v_toSemiring_68_ = lean_ctor_get(v___x_67_, 0);
lean_inc_ref(v_toSemiring_68_);
lean_dec_ref(v___x_67_);
v___x_69_ = lp_mathlib_instMulZeroClassOfSemiring___redArg(v_toSemiring_68_);
v_toZero_70_ = lean_ctor_get(v___x_69_, 1);
v_isSharedCheck_82_ = !lean_is_exclusive(v___x_69_);
if (v_isSharedCheck_82_ == 0)
{
lean_object* v_unused_83_; 
v_unused_83_ = lean_ctor_get(v___x_69_, 0);
lean_dec(v_unused_83_);
v___x_72_ = v___x_69_;
v_isShared_73_ = v_isSharedCheck_82_;
goto v_resetjp_71_;
}
else
{
lean_inc(v_toZero_70_);
lean_dec(v___x_69_);
v___x_72_ = lean_box(0);
v_isShared_73_ = v_isSharedCheck_82_;
goto v_resetjp_71_;
}
v_resetjp_71_:
{
lean_object* v___f_74_; lean_object* v___f_75_; lean_object* v___x_76_; lean_object* v___x_77_; lean_object* v___x_78_; lean_object* v___x_80_; 
lean_inc(v_00_u03d6_63_);
lean_inc_ref(v_inst_62_);
lean_inc(v_e_65_);
v___f_74_ = lean_alloc_closure((void*)(lp_tree_Formalism_IndefR_Fin_HCount_dgl___redArg___lam__0___boxed), 4, 3);
lean_closure_set(v___f_74_, 0, v_e_65_);
lean_closure_set(v___f_74_, 1, v_inst_62_);
lean_closure_set(v___f_74_, 2, v_00_u03d6_63_);
v___f_75_ = lean_alloc_closure((void*)(lp_tree_Formalism_IndefR_Fin_HCount_dgl___redArg___lam__1___boxed), 5, 4);
lean_closure_set(v___f_75_, 0, v_e_65_);
lean_closure_set(v___f_75_, 1, v_inst_62_);
lean_closure_set(v___f_75_, 2, v___x_66_);
lean_closure_set(v___f_75_, 3, v_00_u03d6_63_);
v___x_76_ = lean_alloc_closure((void*)(l_instDecidableEqFin___boxed), 3, 1);
lean_closure_set(v___x_76_, 0, v_n_64_);
lean_inc(v_toZero_70_);
lean_inc_ref(v___x_76_);
v___x_77_ = lean_alloc_closure((void*)(lp_mathlib_Matrix_diagonal), 7, 5);
lean_closure_set(v___x_77_, 0, lean_box(0));
lean_closure_set(v___x_77_, 1, lean_box(0));
lean_closure_set(v___x_77_, 2, v___x_76_);
lean_closure_set(v___x_77_, 3, v_toZero_70_);
lean_closure_set(v___x_77_, 4, v___f_74_);
v___x_78_ = lean_alloc_closure((void*)(lp_mathlib_Matrix_diagonal), 7, 5);
lean_closure_set(v___x_78_, 0, lean_box(0));
lean_closure_set(v___x_78_, 1, lean_box(0));
lean_closure_set(v___x_78_, 2, v___x_76_);
lean_closure_set(v___x_78_, 3, v_toZero_70_);
lean_closure_set(v___x_78_, 4, v___f_75_);
if (v_isShared_73_ == 0)
{
lean_ctor_set(v___x_72_, 1, v___x_78_);
lean_ctor_set(v___x_72_, 0, v___x_77_);
v___x_80_ = v___x_72_;
goto v_reusejp_79_;
}
else
{
lean_object* v_reuseFailAlloc_81_; 
v_reuseFailAlloc_81_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_81_, 0, v___x_77_);
lean_ctor_set(v_reuseFailAlloc_81_, 1, v___x_78_);
v___x_80_ = v_reuseFailAlloc_81_;
goto v_reusejp_79_;
}
v_reusejp_79_:
{
return v___x_80_;
}
}
}
}
LEAN_EXPORT lean_object* lp_tree_Formalism_IndefR_Fin_HCount_dgl(lean_object* v_L_84_, lean_object* v_inst_85_, lean_object* v_00_u03d6_86_, lean_object* v_h_u03d6_87_, lean_object* v_n_88_, lean_object* v_e_89_){
_start:
{
lean_object* v___x_90_; 
v___x_90_ = lp_tree_Formalism_IndefR_Fin_HCount_dgl___redArg(v_inst_85_, v_00_u03d6_86_, v_n_88_, v_e_89_);
return v___x_90_;
}
}
LEAN_EXPORT lean_object* lp_tree_Formalism_IndefR_Fin_HCount_scU___redArg___lam__0(lean_object* v_toOne_91_, lean_object* v_x_92_){
_start:
{
lean_inc(v_toOne_91_);
return v_toOne_91_;
}
}
LEAN_EXPORT lean_object* lp_tree_Formalism_IndefR_Fin_HCount_scU___redArg___lam__0___boxed(lean_object* v_toOne_93_, lean_object* v_x_94_){
_start:
{
lean_object* v_res_95_; 
v_res_95_ = lp_tree_Formalism_IndefR_Fin_HCount_scU___redArg___lam__0(v_toOne_93_, v_x_94_);
lean_dec(v_x_94_);
lean_dec(v_toOne_93_);
return v_res_95_;
}
}
LEAN_EXPORT lean_object* lp_tree_Formalism_IndefR_Fin_HCount_scU___redArg___lam__1(lean_object* v_inst_96_, lean_object* v_toZero_97_, lean_object* v___f_98_, lean_object* v_toMul_99_, lean_object* v_00_u03d6_100_, lean_object* v___y_101_, lean_object* v___y_102_){
_start:
{
lean_object* v___x_103_; lean_object* v___x_104_; 
v___x_103_ = lp_mathlib_Matrix_diagonal___redArg(v_inst_96_, v_toZero_97_, v___f_98_, v___y_101_, v___y_102_);
v___x_104_ = lean_apply_2(v_toMul_99_, v_00_u03d6_100_, v___x_103_);
return v___x_104_;
}
}
LEAN_EXPORT lean_object* lp_tree_Formalism_IndefR_Fin_HCount_scU___redArg___lam__2(lean_object* v_inst_105_, lean_object* v_toZero_106_, lean_object* v___f_107_, lean_object* v_toMul_108_, lean_object* v___x_109_, lean_object* v___y_110_, lean_object* v___y_111_){
_start:
{
lean_object* v___x_112_; lean_object* v___x_113_; 
v___x_112_ = lp_mathlib_Matrix_diagonal___redArg(v_inst_105_, v_toZero_106_, v___f_107_, v___y_110_, v___y_111_);
v___x_113_ = lean_apply_2(v_toMul_108_, v___x_109_, v___x_112_);
return v___x_113_;
}
}
LEAN_EXPORT lean_object* lp_tree_Formalism_IndefR_Fin_HCount_scU___redArg(lean_object* v_inst_114_, lean_object* v_00_u03d6_115_, lean_object* v_inst_116_){
_start:
{
lean_object* v___x_117_; lean_object* v___x_118_; lean_object* v_toSemiring_119_; lean_object* v___x_120_; lean_object* v_toMul_121_; lean_object* v___x_122_; lean_object* v_toZero_123_; lean_object* v___x_124_; lean_object* v_toRing_125_; lean_object* v___x_126_; lean_object* v_toAddMonoidWithOne_127_; lean_object* v_toOne_128_; lean_object* v___x_129_; lean_object* v___x_130_; lean_object* v___x_131_; lean_object* v_toInv_132_; lean_object* v___x_134_; uint8_t v_isShared_135_; uint8_t v_isSharedCheck_143_; 
v___x_117_ = lp_mathlib_Field_toSemifield___redArg(v_inst_114_);
lean_inc_ref(v___x_117_);
v___x_118_ = lp_mathlib_Semifield_toDivisionSemiring___redArg(v___x_117_);
v_toSemiring_119_ = lean_ctor_get(v___x_118_, 0);
lean_inc_ref_n(v_toSemiring_119_, 2);
lean_dec_ref(v___x_118_);
v___x_120_ = lp_mathlib_instDistribOfSemiring___redArg(v_toSemiring_119_);
v_toMul_121_ = lean_ctor_get(v___x_120_, 0);
lean_inc(v_toMul_121_);
lean_dec_ref(v___x_120_);
v___x_122_ = lp_mathlib_instMulZeroClassOfSemiring___redArg(v_toSemiring_119_);
v_toZero_123_ = lean_ctor_get(v___x_122_, 1);
lean_inc(v_toZero_123_);
lean_dec_ref(v___x_122_);
v___x_124_ = lp_mathlib_Field_toDivisionRing___redArg(v_inst_114_);
v_toRing_125_ = lean_ctor_get(v___x_124_, 0);
lean_inc_ref(v_toRing_125_);
lean_dec_ref(v___x_124_);
v___x_126_ = lp_mathlib_Ring_toAddGroupWithOne___redArg(v_toRing_125_);
v_toAddMonoidWithOne_127_ = lean_ctor_get(v___x_126_, 1);
lean_inc_ref(v_toAddMonoidWithOne_127_);
lean_dec_ref(v___x_126_);
v_toOne_128_ = lean_ctor_get(v_toAddMonoidWithOne_127_, 2);
lean_inc(v_toOne_128_);
lean_dec_ref(v_toAddMonoidWithOne_127_);
v___x_129_ = lp_mathlib_Semifield_toCommGroupWithZero___redArg(v___x_117_);
lean_dec_ref(v___x_117_);
v___x_130_ = lp_mathlib_CommGroupWithZero_toDivisionCommMonoid___redArg(v___x_129_);
v___x_131_ = lp_mathlib_DivInvOneMonoid_toInvOneClass___redArg(v___x_130_);
lean_dec_ref(v___x_130_);
v_toInv_132_ = lean_ctor_get(v___x_131_, 1);
v_isSharedCheck_143_ = !lean_is_exclusive(v___x_131_);
if (v_isSharedCheck_143_ == 0)
{
lean_object* v_unused_144_; 
v_unused_144_ = lean_ctor_get(v___x_131_, 0);
lean_dec(v_unused_144_);
v___x_134_ = v___x_131_;
v_isShared_135_ = v_isSharedCheck_143_;
goto v_resetjp_133_;
}
else
{
lean_inc(v_toInv_132_);
lean_dec(v___x_131_);
v___x_134_ = lean_box(0);
v_isShared_135_ = v_isSharedCheck_143_;
goto v_resetjp_133_;
}
v_resetjp_133_:
{
lean_object* v___f_136_; lean_object* v___f_137_; lean_object* v___x_138_; lean_object* v___f_139_; lean_object* v___x_141_; 
v___f_136_ = lean_alloc_closure((void*)(lp_tree_Formalism_IndefR_Fin_HCount_scU___redArg___lam__0___boxed), 2, 1);
lean_closure_set(v___f_136_, 0, v_toOne_128_);
lean_inc(v_00_u03d6_115_);
lean_inc(v_toMul_121_);
lean_inc_ref(v___f_136_);
lean_inc(v_toZero_123_);
lean_inc_ref(v_inst_116_);
v___f_137_ = lean_alloc_closure((void*)(lp_tree_Formalism_IndefR_Fin_HCount_scU___redArg___lam__1), 7, 5);
lean_closure_set(v___f_137_, 0, v_inst_116_);
lean_closure_set(v___f_137_, 1, v_toZero_123_);
lean_closure_set(v___f_137_, 2, v___f_136_);
lean_closure_set(v___f_137_, 3, v_toMul_121_);
lean_closure_set(v___f_137_, 4, v_00_u03d6_115_);
v___x_138_ = lean_apply_1(v_toInv_132_, v_00_u03d6_115_);
v___f_139_ = lean_alloc_closure((void*)(lp_tree_Formalism_IndefR_Fin_HCount_scU___redArg___lam__2), 7, 5);
lean_closure_set(v___f_139_, 0, v_inst_116_);
lean_closure_set(v___f_139_, 1, v_toZero_123_);
lean_closure_set(v___f_139_, 2, v___f_136_);
lean_closure_set(v___f_139_, 3, v_toMul_121_);
lean_closure_set(v___f_139_, 4, v___x_138_);
if (v_isShared_135_ == 0)
{
lean_ctor_set(v___x_134_, 1, v___f_139_);
lean_ctor_set(v___x_134_, 0, v___f_137_);
v___x_141_ = v___x_134_;
goto v_reusejp_140_;
}
else
{
lean_object* v_reuseFailAlloc_142_; 
v_reuseFailAlloc_142_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_142_, 0, v___f_137_);
lean_ctor_set(v_reuseFailAlloc_142_, 1, v___f_139_);
v___x_141_ = v_reuseFailAlloc_142_;
goto v_reusejp_140_;
}
v_reusejp_140_:
{
return v___x_141_;
}
}
}
}
LEAN_EXPORT lean_object* lp_tree_Formalism_IndefR_Fin_HCount_scU(lean_object* v_L_145_, lean_object* v_inst_146_, lean_object* v_00_u03d6_147_, lean_object* v_h_u03d6_148_, lean_object* v_n_149_, lean_object* v_inst_150_, lean_object* v_inst_151_){
_start:
{
lean_object* v___x_152_; 
v___x_152_ = lp_tree_Formalism_IndefR_Fin_HCount_scU___redArg(v_inst_146_, v_00_u03d6_147_, v_inst_151_);
return v___x_152_;
}
}
LEAN_EXPORT lean_object* lp_tree_Formalism_IndefR_Fin_HCount_scU___boxed(lean_object* v_L_153_, lean_object* v_inst_154_, lean_object* v_00_u03d6_155_, lean_object* v_h_u03d6_156_, lean_object* v_n_157_, lean_object* v_inst_158_, lean_object* v_inst_159_){
_start:
{
lean_object* v_res_160_; 
v_res_160_ = lp_tree_Formalism_IndefR_Fin_HCount_scU(v_L_153_, v_inst_154_, v_00_u03d6_155_, v_h_u03d6_156_, v_n_157_, v_inst_158_, v_inst_159_);
lean_dec(v_inst_158_);
return v_res_160_;
}
}
LEAN_EXPORT lean_object* lp_tree_Formalism_IndefR_Fin_HCount_invT___redArg(lean_object* v_x_161_){
_start:
{
lean_object* v_val_162_; lean_object* v_inv_163_; lean_object* v___x_165_; uint8_t v_isShared_166_; uint8_t v_isSharedCheck_172_; 
v_val_162_ = lean_ctor_get(v_x_161_, 0);
v_inv_163_ = lean_ctor_get(v_x_161_, 1);
v_isSharedCheck_172_ = !lean_is_exclusive(v_x_161_);
if (v_isSharedCheck_172_ == 0)
{
v___x_165_ = v_x_161_;
v_isShared_166_ = v_isSharedCheck_172_;
goto v_resetjp_164_;
}
else
{
lean_inc(v_inv_163_);
lean_inc(v_val_162_);
lean_dec(v_x_161_);
v___x_165_ = lean_box(0);
v_isShared_166_ = v_isSharedCheck_172_;
goto v_resetjp_164_;
}
v_resetjp_164_:
{
lean_object* v___x_167_; lean_object* v___x_168_; lean_object* v___x_170_; 
v___x_167_ = lean_alloc_closure((void*)(lp_mathlib_Matrix_transpose), 6, 4);
lean_closure_set(v___x_167_, 0, lean_box(0));
lean_closure_set(v___x_167_, 1, lean_box(0));
lean_closure_set(v___x_167_, 2, lean_box(0));
lean_closure_set(v___x_167_, 3, v_inv_163_);
v___x_168_ = lean_alloc_closure((void*)(lp_mathlib_Matrix_transpose), 6, 4);
lean_closure_set(v___x_168_, 0, lean_box(0));
lean_closure_set(v___x_168_, 1, lean_box(0));
lean_closure_set(v___x_168_, 2, lean_box(0));
lean_closure_set(v___x_168_, 3, v_val_162_);
if (v_isShared_166_ == 0)
{
lean_ctor_set(v___x_165_, 1, v___x_168_);
lean_ctor_set(v___x_165_, 0, v___x_167_);
v___x_170_ = v___x_165_;
goto v_reusejp_169_;
}
else
{
lean_object* v_reuseFailAlloc_171_; 
v_reuseFailAlloc_171_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_171_, 0, v___x_167_);
lean_ctor_set(v_reuseFailAlloc_171_, 1, v___x_168_);
v___x_170_ = v_reuseFailAlloc_171_;
goto v_reusejp_169_;
}
v_reusejp_169_:
{
return v___x_170_;
}
}
}
}
LEAN_EXPORT lean_object* lp_tree_Formalism_IndefR_Fin_HCount_invT(lean_object* v_L_173_, lean_object* v_inst_174_, lean_object* v_n_175_, lean_object* v_inst_176_, lean_object* v_inst_177_, lean_object* v_x_178_){
_start:
{
lean_object* v___x_179_; 
v___x_179_ = lp_tree_Formalism_IndefR_Fin_HCount_invT___redArg(v_x_178_);
return v___x_179_;
}
}
LEAN_EXPORT lean_object* lp_tree_Formalism_IndefR_Fin_HCount_invT___boxed(lean_object* v_L_180_, lean_object* v_inst_181_, lean_object* v_n_182_, lean_object* v_inst_183_, lean_object* v_inst_184_, lean_object* v_x_185_){
_start:
{
lean_object* v_res_186_; 
v_res_186_ = lp_tree_Formalism_IndefR_Fin_HCount_invT(v_L_180_, v_inst_181_, v_n_182_, v_inst_183_, v_inst_184_, v_x_185_);
lean_dec_ref(v_inst_184_);
lean_dec(v_inst_183_);
lean_dec_ref(v_inst_181_);
return v_res_186_;
}
}
lean_object* initialize_Init(uint8_t builtin);
lean_object* initialize_Init(uint8_t builtin);
lean_object* initialize_mathlib_Mathlib(uint8_t builtin);
lean_object* initialize_tree_Formalism_SubspaceCounting_ChoiceOfTopsRefined(uint8_t builtin);
lean_object* initialize_tree_Formalism_SatakeDualWeyl_Statement(uint8_t builtin);
lean_object* initialize_tree_Formalism_SatakeDualWeyl_StatementE(uint8_t builtin);
lean_object* initialize_tree_Formalism_SharpRestriction_GenusPolyhedralBounds_RelativeIndexClassSets_LevGapLoc(uint8_t builtin);
static bool _G_initialized = false;
LEAN_EXPORT lean_object* initialize_tree_Formalism_LocalToGlobal_IndefiniteReal_FinitePlaces_ExistsSmulOfMapResidueEqZero(uint8_t builtin) {
lean_object * res;
if (_G_initialized) return lean_io_result_mk_ok(lean_box(0));
_G_initialized = true;
res = initialize_Init(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_Init(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_mathlib_Mathlib(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_Formalism_SubspaceCounting_ChoiceOfTopsRefined(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_Formalism_SatakeDualWeyl_Statement(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_Formalism_SatakeDualWeyl_StatementE(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_Formalism_SharpRestriction_GenusPolyhedralBounds_RelativeIndexClassSets_LevGapLoc(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
return lean_io_result_mk_ok(lean_box(0));
}
#ifdef __cplusplus
}
#endif
