// Lean compiler output
// Module: Formalism.LocalToGlobal.TorsionIntegrality.GaussSumParity.KummerThetaLogarithms.SecondLevelOfNormHolds
// Imports: public import Init public meta import Init public import Formalism.LocalToGlobal.TorsionIntegrality.GaussSumParity.BiextensionHypothesesOfLevelOne public import Formalism.LocalToGlobal.TorsionIntegrality.GaussSumParity.KummerThetaLogarithms.CoboundaryCommutesHomomorphism public import Formalism.LocalToGlobal.TorsionIntegrality.GaussSumParity.StatementC public import Formalism.LocalToGlobal.TorsionIntegrality.SecondCoefficientNorms.FirstLevelFromUniversal public import Formalism.LocalToGlobal.TorsionIntegrality.SecondCoefficientNorms.PhNormFromDatum public import Formalism.LocalToGlobal.TorsionIntegrality.SecondCoefficientNorms.BinomialSeriesCoefficients.ConstantCoeffVecConsPairEqZero public import Formalism.LocalToGlobal.TorsionIntegrality.SecondCoefficientNorms.BinomialSeriesCoefficients.Closure
#include <lean/lean.h>
#if defined(__clang__)
#pragma clang diagnostic ignored "-Wunused-parameter"
#pragma clang diagnostic ignored "-Wunused-label"
#elif defined(__GNUC__) && !defined(__CLANG__)
#pragma GCC diagnostic ignored "-Wunused-parameter"
#pragma GCC diagnostic ignored "-Wunused-label"
#pragma GCC diagnostic ignored "-Wunused-but-set-variable"
#endif
#ifdef __cplusplus
extern "C" {
#endif
lean_object* lp_mathlib_Field_toSemifield___redArg(lean_object*);
lean_object* lp_mathlib_Semifield_toCommGroupWithZero___redArg(lean_object*);
lean_object* lp_mathlib_CommGroupWithZero_toDivisionCommMonoid___redArg(lean_object*);
lean_object* lp_mathlib_DivInvOneMonoid_toInvOneClass___redArg(lean_object*);
LEAN_EXPORT lean_object* lp_tree_Formalism_L2_Th1_D_BrC_starO___redArg___lam__0(lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_Formalism_L2_Th1_D_BrC_starO___redArg(lean_object*);
LEAN_EXPORT lean_object* lp_tree_Formalism_L2_Th1_D_BrC_starO(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_Formalism_L2_Th1_D_BrC_starO___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_Formalism_L2_Th1_D_BrC_unitO___redArg(lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_Formalism_L2_Th1_D_BrC_unitO___redArg___boxed(lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_Formalism_L2_Th1_D_BrC_unitO(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_Formalism_L2_Th1_D_BrC_unitO___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_Formalism_L2_Th1_D_BrC_starO___redArg___lam__0(lean_object* v_00_u03c3_1_, lean_object* v_a_2_){
_start:
{
lean_object* v___x_3_; 
v___x_3_ = lean_apply_1(v_00_u03c3_1_, v_a_2_);
return v___x_3_;
}
}
LEAN_EXPORT lean_object* lp_tree_Formalism_L2_Th1_D_BrC_starO___redArg(lean_object* v_00_u03c3_4_){
_start:
{
lean_object* v___f_5_; 
v___f_5_ = lean_alloc_closure((void*)(lp_tree_Formalism_L2_Th1_D_BrC_starO___redArg___lam__0), 2, 1);
lean_closure_set(v___f_5_, 0, v_00_u03c3_4_);
return v___f_5_;
}
}
LEAN_EXPORT lean_object* lp_tree_Formalism_L2_Th1_D_BrC_starO(lean_object* v_K_6_, lean_object* v_inst_7_, lean_object* v_inst_8_, lean_object* v_00_u03c3_9_, lean_object* v_h_u03c3_10_){
_start:
{
lean_object* v___f_11_; 
v___f_11_ = lean_alloc_closure((void*)(lp_tree_Formalism_L2_Th1_D_BrC_starO___redArg___lam__0), 2, 1);
lean_closure_set(v___f_11_, 0, v_00_u03c3_9_);
return v___f_11_;
}
}
LEAN_EXPORT lean_object* lp_tree_Formalism_L2_Th1_D_BrC_starO___boxed(lean_object* v_K_12_, lean_object* v_inst_13_, lean_object* v_inst_14_, lean_object* v_00_u03c3_15_, lean_object* v_h_u03c3_16_){
_start:
{
lean_object* v_res_17_; 
v_res_17_ = lp_tree_Formalism_L2_Th1_D_BrC_starO(v_K_12_, v_inst_13_, v_inst_14_, v_00_u03c3_15_, v_h_u03c3_16_);
lean_dec_ref(v_inst_13_);
return v_res_17_;
}
}
LEAN_EXPORT lean_object* lp_tree_Formalism_L2_Th1_D_BrC_unitO___redArg(lean_object* v_inst_18_, lean_object* v_a_19_){
_start:
{
lean_object* v_toField_20_; lean_object* v___x_21_; lean_object* v___x_22_; lean_object* v___x_23_; lean_object* v___x_24_; lean_object* v_toInv_25_; lean_object* v___x_27_; uint8_t v_isShared_28_; uint8_t v_isSharedCheck_33_; 
v_toField_20_ = lean_ctor_get(v_inst_18_, 1);
v___x_21_ = lp_mathlib_Field_toSemifield___redArg(v_toField_20_);
v___x_22_ = lp_mathlib_Semifield_toCommGroupWithZero___redArg(v___x_21_);
lean_dec_ref(v___x_21_);
v___x_23_ = lp_mathlib_CommGroupWithZero_toDivisionCommMonoid___redArg(v___x_22_);
v___x_24_ = lp_mathlib_DivInvOneMonoid_toInvOneClass___redArg(v___x_23_);
lean_dec_ref(v___x_23_);
v_toInv_25_ = lean_ctor_get(v___x_24_, 1);
v_isSharedCheck_33_ = !lean_is_exclusive(v___x_24_);
if (v_isSharedCheck_33_ == 0)
{
lean_object* v_unused_34_; 
v_unused_34_ = lean_ctor_get(v___x_24_, 0);
lean_dec(v_unused_34_);
v___x_27_ = v___x_24_;
v_isShared_28_ = v_isSharedCheck_33_;
goto v_resetjp_26_;
}
else
{
lean_inc(v_toInv_25_);
lean_dec(v___x_24_);
v___x_27_ = lean_box(0);
v_isShared_28_ = v_isSharedCheck_33_;
goto v_resetjp_26_;
}
v_resetjp_26_:
{
lean_object* v___x_29_; lean_object* v___x_31_; 
lean_inc(v_a_19_);
v___x_29_ = lean_apply_1(v_toInv_25_, v_a_19_);
if (v_isShared_28_ == 0)
{
lean_ctor_set(v___x_27_, 1, v___x_29_);
lean_ctor_set(v___x_27_, 0, v_a_19_);
v___x_31_ = v___x_27_;
goto v_reusejp_30_;
}
else
{
lean_object* v_reuseFailAlloc_32_; 
v_reuseFailAlloc_32_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_32_, 0, v_a_19_);
lean_ctor_set(v_reuseFailAlloc_32_, 1, v___x_29_);
v___x_31_ = v_reuseFailAlloc_32_;
goto v_reusejp_30_;
}
v_reusejp_30_:
{
return v___x_31_;
}
}
}
}
LEAN_EXPORT lean_object* lp_tree_Formalism_L2_Th1_D_BrC_unitO___redArg___boxed(lean_object* v_inst_35_, lean_object* v_a_36_){
_start:
{
lean_object* v_res_37_; 
v_res_37_ = lp_tree_Formalism_L2_Th1_D_BrC_unitO___redArg(v_inst_35_, v_a_36_);
lean_dec_ref(v_inst_35_);
return v_res_37_;
}
}
LEAN_EXPORT lean_object* lp_tree_Formalism_L2_Th1_D_BrC_unitO(lean_object* v_K_38_, lean_object* v_inst_39_, lean_object* v_inst_40_, lean_object* v_00_u03c3_41_, lean_object* v_a_42_, lean_object* v_ha_43_, lean_object* v_hs_44_){
_start:
{
lean_object* v___x_45_; 
v___x_45_ = lp_tree_Formalism_L2_Th1_D_BrC_unitO___redArg(v_inst_39_, v_a_42_);
return v___x_45_;
}
}
LEAN_EXPORT lean_object* lp_tree_Formalism_L2_Th1_D_BrC_unitO___boxed(lean_object* v_K_46_, lean_object* v_inst_47_, lean_object* v_inst_48_, lean_object* v_00_u03c3_49_, lean_object* v_a_50_, lean_object* v_ha_51_, lean_object* v_hs_52_){
_start:
{
lean_object* v_res_53_; 
v_res_53_ = lp_tree_Formalism_L2_Th1_D_BrC_unitO(v_K_46_, v_inst_47_, v_inst_48_, v_00_u03c3_49_, v_a_50_, v_ha_51_, v_hs_52_);
lean_dec(v_00_u03c3_49_);
lean_dec_ref(v_inst_47_);
return v_res_53_;
}
}
lean_object* initialize_Init(uint8_t builtin);
lean_object* initialize_Init(uint8_t builtin);
lean_object* initialize_tree_Formalism_LocalToGlobal_TorsionIntegrality_GaussSumParity_BiextensionHypothesesOfLevelOne(uint8_t builtin);
lean_object* initialize_tree_Formalism_LocalToGlobal_TorsionIntegrality_GaussSumParity_KummerThetaLogarithms_CoboundaryCommutesHomomorphism(uint8_t builtin);
lean_object* initialize_tree_Formalism_LocalToGlobal_TorsionIntegrality_GaussSumParity_StatementC(uint8_t builtin);
lean_object* initialize_tree_Formalism_LocalToGlobal_TorsionIntegrality_SecondCoefficientNorms_FirstLevelFromUniversal(uint8_t builtin);
lean_object* initialize_tree_Formalism_LocalToGlobal_TorsionIntegrality_SecondCoefficientNorms_PhNormFromDatum(uint8_t builtin);
lean_object* initialize_tree_Formalism_LocalToGlobal_TorsionIntegrality_SecondCoefficientNorms_BinomialSeriesCoefficients_ConstantCoeffVecConsPairEqZero(uint8_t builtin);
lean_object* initialize_tree_Formalism_LocalToGlobal_TorsionIntegrality_SecondCoefficientNorms_BinomialSeriesCoefficients_Closure(uint8_t builtin);
static bool _G_initialized = false;
LEAN_EXPORT lean_object* initialize_tree_Formalism_LocalToGlobal_TorsionIntegrality_GaussSumParity_KummerThetaLogarithms_SecondLevelOfNormHolds(uint8_t builtin) {
lean_object * res;
if (_G_initialized) return lean_io_result_mk_ok(lean_box(0));
_G_initialized = true;
res = initialize_Init(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_Init(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_Formalism_LocalToGlobal_TorsionIntegrality_GaussSumParity_BiextensionHypothesesOfLevelOne(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_Formalism_LocalToGlobal_TorsionIntegrality_GaussSumParity_KummerThetaLogarithms_CoboundaryCommutesHomomorphism(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_Formalism_LocalToGlobal_TorsionIntegrality_GaussSumParity_StatementC(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_Formalism_LocalToGlobal_TorsionIntegrality_SecondCoefficientNorms_FirstLevelFromUniversal(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_Formalism_LocalToGlobal_TorsionIntegrality_SecondCoefficientNorms_PhNormFromDatum(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_Formalism_LocalToGlobal_TorsionIntegrality_SecondCoefficientNorms_BinomialSeriesCoefficients_ConstantCoeffVecConsPairEqZero(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_Formalism_LocalToGlobal_TorsionIntegrality_SecondCoefficientNorms_BinomialSeriesCoefficients_Closure(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
return lean_io_result_mk_ok(lean_box(0));
}
#ifdef __cplusplus
}
#endif
