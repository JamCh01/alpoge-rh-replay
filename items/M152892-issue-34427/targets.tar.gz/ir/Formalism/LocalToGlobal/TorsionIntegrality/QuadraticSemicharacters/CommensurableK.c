// Lean compiler output
// Module: Formalism.LocalToGlobal.TorsionIntegrality.QuadraticSemicharacters.CommensurableK
// Imports: public import Init public meta import Init public import Formalism.LocalToGlobal.TorsionIntegrality.QuadraticSemicharacters.QuadraticSemicharactersFactAltForm public import Formalism.LocalToGlobal.TorsionIntegrality.QuadraticSemicharacters.InterIntegral
#include <lean/lean.h>
#if defined(__clang__)
#pragma clang diagnostic ignored "-Wunused-parameter"
#pragma clang diagnostic ignored "-Wunused-label"
#elif defined(__GNUC__) && !defined(__CLANG__)
#pragma GCC diagnostic ignored "-Wunused-parameter"
#pragma GCC diagnostic ignored "-Wunused-label"
#pragma GCC diagnostic ignored "-Wunused-but-set-variable"
#endif
#ifdef __cplusplus
extern "C" {
#endif
extern lean_object* lp_mathlib_Real_definition_00___x40_Mathlib_Data_Real_Basic_1850581184____hygCtx___hyg_8_;
lean_object* lp_mathlib_Complex_ofReal(lean_object*);
lean_object* lp_mathlib_Matrix_fromBlocks___redArg(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
lean_object* lp_mathlib_Complex_mulAux___at___00Zsqrtd_lift___at___00GaussianInt_toComplex_spec__0_spec__1(lean_object*, lean_object*, lean_object*);
static lean_once_cell_t lp_tree_Formalism_L2_Th1_H_blkSum___redArg___lam__0___closed__0_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* lp_tree_Formalism_L2_Th1_H_blkSum___redArg___lam__0___closed__0;
LEAN_EXPORT lean_object* lp_tree_Formalism_L2_Th1_H_blkSum___redArg___lam__0(lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_Formalism_L2_Th1_H_blkSum___redArg___lam__0___boxed(lean_object*, lean_object*);
static const lean_closure_object lp_tree_Formalism_L2_Th1_H_blkSum___redArg___closed__0_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_closure_object) + sizeof(void*)*0, .m_other = 0, .m_tag = 245}, .m_fun = (void*)lp_tree_Formalism_L2_Th1_H_blkSum___redArg___lam__0___boxed, .m_arity = 2, .m_num_fixed = 0, .m_objs = {} };
static const lean_object* lp_tree_Formalism_L2_Th1_H_blkSum___redArg___closed__0 = (const lean_object*)&lp_tree_Formalism_L2_Th1_H_blkSum___redArg___closed__0_value;
LEAN_EXPORT lean_object* lp_tree_Formalism_L2_Th1_H_blkSum___redArg(lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_Formalism_L2_Th1_H_blkSum(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_Formalism_L2_Th1_H_prodLat(lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_Formalism_L2_Th1_H_tensFn___redArg___lam__0(lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_Formalism_L2_Th1_H_tensFn___redArg___lam__1(lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_Formalism_L2_Th1_H_tensFn___redArg(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_Formalism_L2_Th1_H_tensFn(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
static lean_object* _init_lp_tree_Formalism_L2_Th1_H_blkSum___redArg___lam__0___closed__0(void){
_start:
{
lean_object* v___x_1_; lean_object* v___x_2_; 
v___x_1_ = lp_mathlib_Real_definition_00___x40_Mathlib_Data_Real_Basic_1850581184____hygCtx___hyg_8_;
v___x_2_ = lp_mathlib_Complex_ofReal(v___x_1_);
return v___x_2_;
}
}
LEAN_EXPORT lean_object* lp_tree_Formalism_L2_Th1_H_blkSum___redArg___lam__0(lean_object* v___y_3_, lean_object* v___y_4_){
_start:
{
lean_object* v___x_5_; 
v___x_5_ = lean_obj_once(&lp_tree_Formalism_L2_Th1_H_blkSum___redArg___lam__0___closed__0, &lp_tree_Formalism_L2_Th1_H_blkSum___redArg___lam__0___closed__0_once, _init_lp_tree_Formalism_L2_Th1_H_blkSum___redArg___lam__0___closed__0);
return v___x_5_;
}
}
LEAN_EXPORT lean_object* lp_tree_Formalism_L2_Th1_H_blkSum___redArg___lam__0___boxed(lean_object* v___y_6_, lean_object* v___y_7_){
_start:
{
lean_object* v_res_8_; 
v_res_8_ = lp_tree_Formalism_L2_Th1_H_blkSum___redArg___lam__0(v___y_6_, v___y_7_);
lean_dec(v___y_7_);
lean_dec(v___y_6_);
return v_res_8_;
}
}
LEAN_EXPORT lean_object* lp_tree_Formalism_L2_Th1_H_blkSum___redArg(lean_object* v_h_u2081_10_, lean_object* v_h_u2082_11_, lean_object* v_a_12_, lean_object* v_a_13_){
_start:
{
lean_object* v___f_14_; lean_object* v___x_15_; 
v___f_14_ = ((lean_object*)(lp_tree_Formalism_L2_Th1_H_blkSum___redArg___closed__0));
v___x_15_ = lp_mathlib_Matrix_fromBlocks___redArg(v_h_u2081_10_, v___f_14_, v___f_14_, v_h_u2082_11_, v_a_12_, v_a_13_);
return v___x_15_;
}
}
LEAN_EXPORT lean_object* lp_tree_Formalism_L2_Th1_H_blkSum(lean_object* v_n_16_, lean_object* v_k_17_, lean_object* v_h_u2081_18_, lean_object* v_h_u2082_19_, lean_object* v_a_20_, lean_object* v_a_21_){
_start:
{
lean_object* v___x_22_; 
v___x_22_ = lp_tree_Formalism_L2_Th1_H_blkSum___redArg(v_h_u2081_18_, v_h_u2082_19_, v_a_20_, v_a_21_);
return v___x_22_;
}
}
LEAN_EXPORT lean_object* lp_tree_Formalism_L2_Th1_H_prodLat(lean_object* v_n_23_, lean_object* v_k_24_, lean_object* v_00_u039b_u2081_25_, lean_object* v_00_u039b_u2082_26_){
_start:
{
lean_object* v___x_27_; 
v___x_27_ = lean_box(0);
return v___x_27_;
}
}
LEAN_EXPORT lean_object* lp_tree_Formalism_L2_Th1_H_tensFn___redArg___lam__0(lean_object* v_z_28_, lean_object* v_i_29_){
_start:
{
lean_object* v___x_30_; lean_object* v___x_31_; 
v___x_30_ = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(v___x_30_, 0, v_i_29_);
v___x_31_ = lean_apply_1(v_z_28_, v___x_30_);
return v___x_31_;
}
}
LEAN_EXPORT lean_object* lp_tree_Formalism_L2_Th1_H_tensFn___redArg___lam__1(lean_object* v_z_32_, lean_object* v_j_33_){
_start:
{
lean_object* v___x_34_; lean_object* v___x_35_; 
v___x_34_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v___x_34_, 0, v_j_33_);
v___x_35_ = lean_apply_1(v_z_32_, v___x_34_);
return v___x_35_;
}
}
LEAN_EXPORT lean_object* lp_tree_Formalism_L2_Th1_H_tensFn___redArg(lean_object* v_00_u03b8_u2081_36_, lean_object* v_00_u03b8_u2082_37_, lean_object* v_z_38_){
_start:
{
lean_object* v___f_39_; lean_object* v___x_40_; lean_object* v_re_41_; lean_object* v_im_42_; lean_object* v___f_43_; lean_object* v___x_44_; lean_object* v___x_45_; 
lean_inc_ref(v_z_38_);
v___f_39_ = lean_alloc_closure((void*)(lp_tree_Formalism_L2_Th1_H_tensFn___redArg___lam__0), 2, 1);
lean_closure_set(v___f_39_, 0, v_z_38_);
v___x_40_ = lean_apply_1(v_00_u03b8_u2081_36_, v___f_39_);
v_re_41_ = lean_ctor_get(v___x_40_, 0);
lean_inc(v_re_41_);
v_im_42_ = lean_ctor_get(v___x_40_, 1);
lean_inc(v_im_42_);
lean_dec_ref(v___x_40_);
v___f_43_ = lean_alloc_closure((void*)(lp_tree_Formalism_L2_Th1_H_tensFn___redArg___lam__1), 2, 1);
lean_closure_set(v___f_43_, 0, v_z_38_);
v___x_44_ = lean_apply_1(v_00_u03b8_u2082_37_, v___f_43_);
v___x_45_ = lp_mathlib_Complex_mulAux___at___00Zsqrtd_lift___at___00GaussianInt_toComplex_spec__0_spec__1(v_re_41_, v_im_42_, v___x_44_);
return v___x_45_;
}
}
LEAN_EXPORT lean_object* lp_tree_Formalism_L2_Th1_H_tensFn(lean_object* v_n_46_, lean_object* v_k_47_, lean_object* v_00_u03b8_u2081_48_, lean_object* v_00_u03b8_u2082_49_, lean_object* v_z_50_){
_start:
{
lean_object* v___x_51_; 
v___x_51_ = lp_tree_Formalism_L2_Th1_H_tensFn___redArg(v_00_u03b8_u2081_48_, v_00_u03b8_u2082_49_, v_z_50_);
return v___x_51_;
}
}
lean_object* initialize_Init(uint8_t builtin);
lean_object* initialize_Init(uint8_t builtin);
lean_object* initialize_tree_Formalism_LocalToGlobal_TorsionIntegrality_QuadraticSemicharacters_QuadraticSemicharactersFactAltForm(uint8_t builtin);
lean_object* initialize_tree_Formalism_LocalToGlobal_TorsionIntegrality_QuadraticSemicharacters_InterIntegral(uint8_t builtin);
static bool _G_initialized = false;
LEAN_EXPORT lean_object* initialize_tree_Formalism_LocalToGlobal_TorsionIntegrality_QuadraticSemicharacters_CommensurableK(uint8_t builtin) {
lean_object * res;
if (_G_initialized) return lean_io_result_mk_ok(lean_box(0));
_G_initialized = true;
res = initialize_Init(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_Init(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_Formalism_LocalToGlobal_TorsionIntegrality_QuadraticSemicharacters_QuadraticSemicharactersFactAltForm(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_Formalism_LocalToGlobal_TorsionIntegrality_QuadraticSemicharacters_InterIntegral(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
return lean_io_result_mk_ok(lean_box(0));
}
#ifdef __cplusplus
}
#endif
