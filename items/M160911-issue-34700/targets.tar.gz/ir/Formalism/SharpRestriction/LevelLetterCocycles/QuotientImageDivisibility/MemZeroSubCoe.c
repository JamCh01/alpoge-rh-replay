// Lean compiler output
// Module: Formalism.SharpRestriction.LevelLetterCocycles.QuotientImageDivisibility.MemZeroSubCoe
// Imports: public import Init public meta import Init public import Formalism.SharpRestriction.LevelLetterCocycles.LatticeBoundsOfThreeParts
#include <lean/lean.h>
#if defined(__clang__)
#pragma clang diagnostic ignored "-Wunused-parameter"
#pragma clang diagnostic ignored "-Wunused-label"
#elif defined(__GNUC__) && !defined(__CLANG__)
#pragma GCC diagnostic ignored "-Wunused-parameter"
#pragma GCC diagnostic ignored "-Wunused-label"
#pragma GCC diagnostic ignored "-Wunused-but-set-variable"
#endif
#ifdef __cplusplus
extern "C" {
#endif
LEAN_EXPORT lean_object* lp_tree_Formalism_MainNotions_N_Pv_LocalLengthBound_kerSub(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_Formalism_MainNotions_N_Pv_LocalLengthBound_kerSub___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_Formalism_MainNotions_N_Pv_LocalLengthBound_zeroSubA(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_Formalism_MainNotions_N_Pv_LocalLengthBound_zeroSubA___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_Formalism_MainNotions_N_Pv_LocalLengthBound_zeroSub(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_Formalism_MainNotions_N_Pv_LocalLengthBound_zeroSub___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_Formalism_MainNotions_N_Pv_LocalLengthBound_kerSub(lean_object* v_O_1_, lean_object* v_inst_2_, lean_object* v_FF_3_, lean_object* v_inst_4_, lean_object* v_inst_5_, lean_object* v_A_6_, lean_object* v_M_7_, lean_object* v_inst_8_, lean_object* v_inst_9_, lean_object* v_w_10_, lean_object* v_Y_11_){
_start:
{
lean_object* v___x_12_; 
v___x_12_ = lean_box(0);
return v___x_12_;
}
}
LEAN_EXPORT lean_object* lp_tree_Formalism_MainNotions_N_Pv_LocalLengthBound_kerSub___boxed(lean_object* v_O_13_, lean_object* v_inst_14_, lean_object* v_FF_15_, lean_object* v_inst_16_, lean_object* v_inst_17_, lean_object* v_A_18_, lean_object* v_M_19_, lean_object* v_inst_20_, lean_object* v_inst_21_, lean_object* v_w_22_, lean_object* v_Y_23_){
_start:
{
lean_object* v_res_24_; 
v_res_24_ = lp_tree_Formalism_MainNotions_N_Pv_LocalLengthBound_kerSub(v_O_13_, v_inst_14_, v_FF_15_, v_inst_16_, v_inst_17_, v_A_18_, v_M_19_, v_inst_20_, v_inst_21_, v_w_22_, v_Y_23_);
lean_dec(v_w_22_);
lean_dec(v_inst_21_);
lean_dec_ref(v_inst_20_);
lean_dec(v_inst_17_);
lean_dec_ref(v_inst_16_);
lean_dec_ref(v_inst_14_);
return v_res_24_;
}
}
LEAN_EXPORT lean_object* lp_tree_Formalism_MainNotions_N_Pv_LocalLengthBound_zeroSubA(lean_object* v_O_25_, lean_object* v_inst_26_, lean_object* v_FF_27_, lean_object* v_inst_28_, lean_object* v_inst_29_, lean_object* v_LL_30_, lean_object* v_inst_31_, lean_object* v_inst_32_, lean_object* v_U_33_, lean_object* v_inst_34_, lean_object* v_inst_35_, lean_object* v_A_36_, lean_object* v_00_u03c6_37_, lean_object* v_h_u03c6_38_){
_start:
{
lean_object* v___x_39_; 
v___x_39_ = lean_box(0);
return v___x_39_;
}
}
LEAN_EXPORT lean_object* lp_tree_Formalism_MainNotions_N_Pv_LocalLengthBound_zeroSubA___boxed(lean_object* v_O_40_, lean_object* v_inst_41_, lean_object* v_FF_42_, lean_object* v_inst_43_, lean_object* v_inst_44_, lean_object* v_LL_45_, lean_object* v_inst_46_, lean_object* v_inst_47_, lean_object* v_U_48_, lean_object* v_inst_49_, lean_object* v_inst_50_, lean_object* v_A_51_, lean_object* v_00_u03c6_52_, lean_object* v_h_u03c6_53_){
_start:
{
lean_object* v_res_54_; 
v_res_54_ = lp_tree_Formalism_MainNotions_N_Pv_LocalLengthBound_zeroSubA(v_O_40_, v_inst_41_, v_FF_42_, v_inst_43_, v_inst_44_, v_LL_45_, v_inst_46_, v_inst_47_, v_U_48_, v_inst_49_, v_inst_50_, v_A_51_, v_00_u03c6_52_, v_h_u03c6_53_);
lean_dec(v_00_u03c6_52_);
lean_dec(v_inst_50_);
lean_dec_ref(v_inst_49_);
lean_dec_ref(v_inst_47_);
lean_dec_ref(v_inst_46_);
lean_dec(v_inst_44_);
lean_dec_ref(v_inst_43_);
lean_dec_ref(v_inst_41_);
return v_res_54_;
}
}
LEAN_EXPORT lean_object* lp_tree_Formalism_MainNotions_N_Pv_LocalLengthBound_zeroSub(lean_object* v_O_55_, lean_object* v_inst_56_, lean_object* v_FF_57_, lean_object* v_inst_58_, lean_object* v_inst_59_, lean_object* v_LL_60_, lean_object* v_inst_61_, lean_object* v_inst_62_, lean_object* v_U_63_, lean_object* v_inst_64_, lean_object* v_inst_65_, lean_object* v_A_66_, lean_object* v_00_u03c6_67_, lean_object* v_h_u03c6_68_){
_start:
{
lean_object* v___x_69_; 
v___x_69_ = lean_box(0);
return v___x_69_;
}
}
LEAN_EXPORT lean_object* lp_tree_Formalism_MainNotions_N_Pv_LocalLengthBound_zeroSub___boxed(lean_object* v_O_70_, lean_object* v_inst_71_, lean_object* v_FF_72_, lean_object* v_inst_73_, lean_object* v_inst_74_, lean_object* v_LL_75_, lean_object* v_inst_76_, lean_object* v_inst_77_, lean_object* v_U_78_, lean_object* v_inst_79_, lean_object* v_inst_80_, lean_object* v_A_81_, lean_object* v_00_u03c6_82_, lean_object* v_h_u03c6_83_){
_start:
{
lean_object* v_res_84_; 
v_res_84_ = lp_tree_Formalism_MainNotions_N_Pv_LocalLengthBound_zeroSub(v_O_70_, v_inst_71_, v_FF_72_, v_inst_73_, v_inst_74_, v_LL_75_, v_inst_76_, v_inst_77_, v_U_78_, v_inst_79_, v_inst_80_, v_A_81_, v_00_u03c6_82_, v_h_u03c6_83_);
lean_dec(v_00_u03c6_82_);
lean_dec(v_inst_80_);
lean_dec_ref(v_inst_79_);
lean_dec_ref(v_inst_77_);
lean_dec_ref(v_inst_76_);
lean_dec(v_inst_74_);
lean_dec_ref(v_inst_73_);
lean_dec_ref(v_inst_71_);
return v_res_84_;
}
}
lean_object* initialize_Init(uint8_t builtin);
lean_object* initialize_Init(uint8_t builtin);
lean_object* initialize_tree_Formalism_SharpRestriction_LevelLetterCocycles_LatticeBoundsOfThreeParts(uint8_t builtin);
static bool _G_initialized = false;
LEAN_EXPORT lean_object* initialize_tree_Formalism_SharpRestriction_LevelLetterCocycles_QuotientImageDivisibility_MemZeroSubCoe(uint8_t builtin) {
lean_object * res;
if (_G_initialized) return lean_io_result_mk_ok(lean_box(0));
_G_initialized = true;
res = initialize_Init(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_Init(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_Formalism_SharpRestriction_LevelLetterCocycles_LatticeBoundsOfThreeParts(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
return lean_io_result_mk_ok(lean_box(0));
}
#ifdef __cplusplus
}
#endif
