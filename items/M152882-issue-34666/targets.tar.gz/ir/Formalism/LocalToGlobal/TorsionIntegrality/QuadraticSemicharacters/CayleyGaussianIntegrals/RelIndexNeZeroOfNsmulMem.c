// Lean compiler output
// Module: Formalism.LocalToGlobal.TorsionIntegrality.QuadraticSemicharacters.CayleyGaussianIntegrals.RelIndexNeZeroOfNsmulMem
// Imports: public import Init public meta import Init public import Formalism.LocalToGlobal.TorsionIntegrality.QuadraticSemicharacters.CommensurableK public import Formalism.LocalToGlobal.TorsionIntegrality.QuadraticSemicharacters.CayleyGaussianIntegrals.RatFourSquares public import Formalism.LocalToGlobal.TorsionIntegrality.QuadraticSemicharacters.CayleyGaussianIntegrals.ScalePairMulMulEq public import Formalism.LocalToGlobal.TorsionIntegrality.QuadraticSemicharacters.CayleyGaussianIntegrals.RelIndexEqAbsDetReal public import Formalism.LocalToGlobal.TorsionIntegrality.EisensteinTranslationProducts.MulStableIntegral
#include <lean/lean.h>
#if defined(__clang__)
#pragma clang diagnostic ignored "-Wunused-parameter"
#pragma clang diagnostic ignored "-Wunused-label"
#elif defined(__GNUC__) && !defined(__CLANG__)
#pragma GCC diagnostic ignored "-Wunused-parameter"
#pragma GCC diagnostic ignored "-Wunused-label"
#pragma GCC diagnostic ignored "-Wunused-but-set-variable"
#endif
#ifdef __cplusplus
extern "C" {
#endif
LEAN_EXPORT lean_object* lp_tree_Formalism_L2_Th1_H_nsmulHom___redArg___lam__0(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_Formalism_L2_Th1_H_nsmulHom___redArg(lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_Formalism_L2_Th1_H_nsmulHom(lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_Formalism_L2_Th1_H_nsmulHom___boxed(lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_Formalism_L2_Th1_H_stdLatEquiv___lam__0(lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_Formalism_L2_Th1_H_stdLatEquiv___lam__1(lean_object*, lean_object*);
static const lean_closure_object lp_tree_Formalism_L2_Th1_H_stdLatEquiv___closed__0_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_closure_object) + sizeof(void*)*0, .m_other = 0, .m_tag = 245}, .m_fun = (void*)lp_tree_Formalism_L2_Th1_H_stdLatEquiv___lam__0, .m_arity = 2, .m_num_fixed = 0, .m_objs = {} };
static const lean_object* lp_tree_Formalism_L2_Th1_H_stdLatEquiv___closed__0 = (const lean_object*)&lp_tree_Formalism_L2_Th1_H_stdLatEquiv___closed__0_value;
static const lean_closure_object lp_tree_Formalism_L2_Th1_H_stdLatEquiv___closed__1_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_closure_object) + sizeof(void*)*0, .m_other = 0, .m_tag = 245}, .m_fun = (void*)lp_tree_Formalism_L2_Th1_H_stdLatEquiv___lam__1, .m_arity = 2, .m_num_fixed = 0, .m_objs = {} };
static const lean_object* lp_tree_Formalism_L2_Th1_H_stdLatEquiv___closed__1 = (const lean_object*)&lp_tree_Formalism_L2_Th1_H_stdLatEquiv___closed__1_value;
static const lean_ctor_object lp_tree_Formalism_L2_Th1_H_stdLatEquiv___closed__2_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 0, .m_other = 2, .m_tag = 0}, .m_objs = {((lean_object*)&lp_tree_Formalism_L2_Th1_H_stdLatEquiv___closed__0_value),((lean_object*)&lp_tree_Formalism_L2_Th1_H_stdLatEquiv___closed__1_value)}};
static const lean_object* lp_tree_Formalism_L2_Th1_H_stdLatEquiv___closed__2 = (const lean_object*)&lp_tree_Formalism_L2_Th1_H_stdLatEquiv___closed__2_value;
LEAN_EXPORT lean_object* lp_tree_Formalism_L2_Th1_H_stdLatEquiv(lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_Formalism_L2_Th1_H_stdLatEquiv___boxed(lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_Formalism_L2_Th1_H_nsmulHom___redArg___lam__0(lean_object* v_toNSMul_1_, lean_object* v_N_2_, lean_object* v_x_3_){
_start:
{
lean_object* v___x_4_; 
v___x_4_ = lean_apply_2(v_toNSMul_1_, v_N_2_, v_x_3_);
return v___x_4_;
}
}
LEAN_EXPORT lean_object* lp_tree_Formalism_L2_Th1_H_nsmulHom___redArg(lean_object* v_inst_5_, lean_object* v_N_6_){
_start:
{
lean_object* v_toAddMonoid_7_; lean_object* v_toNSMul_8_; lean_object* v___f_9_; 
v_toAddMonoid_7_ = lean_ctor_get(v_inst_5_, 0);
lean_inc_ref(v_toAddMonoid_7_);
lean_dec_ref(v_inst_5_);
v_toNSMul_8_ = lean_ctor_get(v_toAddMonoid_7_, 2);
lean_inc(v_toNSMul_8_);
lean_dec_ref(v_toAddMonoid_7_);
v___f_9_ = lean_alloc_closure((void*)(lp_tree_Formalism_L2_Th1_H_nsmulHom___redArg___lam__0), 3, 2);
lean_closure_set(v___f_9_, 0, v_toNSMul_8_);
lean_closure_set(v___f_9_, 1, v_N_6_);
return v___f_9_;
}
}
LEAN_EXPORT lean_object* lp_tree_Formalism_L2_Th1_H_nsmulHom(lean_object* v_V_10_, lean_object* v_inst_11_, lean_object* v_inst_12_, lean_object* v_N_13_){
_start:
{
lean_object* v___x_14_; 
v___x_14_ = lp_tree_Formalism_L2_Th1_H_nsmulHom___redArg(v_inst_11_, v_N_13_);
return v___x_14_;
}
}
LEAN_EXPORT lean_object* lp_tree_Formalism_L2_Th1_H_nsmulHom___boxed(lean_object* v_V_15_, lean_object* v_inst_16_, lean_object* v_inst_17_, lean_object* v_N_18_){
_start:
{
lean_object* v_res_19_; 
v_res_19_ = lp_tree_Formalism_L2_Th1_H_nsmulHom(v_V_15_, v_inst_16_, v_inst_17_, v_N_18_);
lean_dec(v_inst_17_);
return v_res_19_;
}
}
LEAN_EXPORT lean_object* lp_tree_Formalism_L2_Th1_H_stdLatEquiv___lam__0(lean_object* v_x_20_, lean_object* v_i_21_){
_start:
{
lean_object* v___x_22_; 
v___x_22_ = lean_apply_1(v_x_20_, v_i_21_);
return v___x_22_;
}
}
LEAN_EXPORT lean_object* lp_tree_Formalism_L2_Th1_H_stdLatEquiv___lam__1(lean_object* v_y_23_, lean_object* v___y_24_){
_start:
{
lean_object* v___x_25_; 
v___x_25_ = lean_apply_1(v_y_23_, v___y_24_);
return v___x_25_;
}
}
LEAN_EXPORT lean_object* lp_tree_Formalism_L2_Th1_H_stdLatEquiv(lean_object* v_L_31_, lean_object* v_m_32_){
_start:
{
lean_object* v___x_33_; 
v___x_33_ = ((lean_object*)(lp_tree_Formalism_L2_Th1_H_stdLatEquiv___closed__2));
return v___x_33_;
}
}
LEAN_EXPORT lean_object* lp_tree_Formalism_L2_Th1_H_stdLatEquiv___boxed(lean_object* v_L_34_, lean_object* v_m_35_){
_start:
{
lean_object* v_res_36_; 
v_res_36_ = lp_tree_Formalism_L2_Th1_H_stdLatEquiv(v_L_34_, v_m_35_);
lean_dec_ref(v_L_34_);
return v_res_36_;
}
}
lean_object* initialize_Init(uint8_t builtin);
lean_object* initialize_Init(uint8_t builtin);
lean_object* initialize_tree_Formalism_LocalToGlobal_TorsionIntegrality_QuadraticSemicharacters_CommensurableK(uint8_t builtin);
lean_object* initialize_tree_Formalism_LocalToGlobal_TorsionIntegrality_QuadraticSemicharacters_CayleyGaussianIntegrals_RatFourSquares(uint8_t builtin);
lean_object* initialize_tree_Formalism_LocalToGlobal_TorsionIntegrality_QuadraticSemicharacters_CayleyGaussianIntegrals_ScalePairMulMulEq(uint8_t builtin);
lean_object* initialize_tree_Formalism_LocalToGlobal_TorsionIntegrality_QuadraticSemicharacters_CayleyGaussianIntegrals_RelIndexEqAbsDetReal(uint8_t builtin);
lean_object* initialize_tree_Formalism_LocalToGlobal_TorsionIntegrality_EisensteinTranslationProducts_MulStableIntegral(uint8_t builtin);
static bool _G_initialized = false;
LEAN_EXPORT lean_object* initialize_tree_Formalism_LocalToGlobal_TorsionIntegrality_QuadraticSemicharacters_CayleyGaussianIntegrals_RelIndexNeZeroOfNsmulMem(uint8_t builtin) {
lean_object * res;
if (_G_initialized) return lean_io_result_mk_ok(lean_box(0));
_G_initialized = true;
res = initialize_Init(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_Init(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_Formalism_LocalToGlobal_TorsionIntegrality_QuadraticSemicharacters_CommensurableK(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_Formalism_LocalToGlobal_TorsionIntegrality_QuadraticSemicharacters_CayleyGaussianIntegrals_RatFourSquares(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_Formalism_LocalToGlobal_TorsionIntegrality_QuadraticSemicharacters_CayleyGaussianIntegrals_ScalePairMulMulEq(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_Formalism_LocalToGlobal_TorsionIntegrality_QuadraticSemicharacters_CayleyGaussianIntegrals_RelIndexEqAbsDetReal(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_Formalism_LocalToGlobal_TorsionIntegrality_EisensteinTranslationProducts_MulStableIntegral(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
return lean_io_result_mk_ok(lean_box(0));
}
#ifdef __cplusplus
}
#endif
