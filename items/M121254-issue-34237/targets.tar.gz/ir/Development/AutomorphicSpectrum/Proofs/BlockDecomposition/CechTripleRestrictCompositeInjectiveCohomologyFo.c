// Lean compiler output
// Module: Development.AutomorphicSpectrum.Proofs.BlockDecomposition.CechTripleRestrictCompositeInjectiveCohomologyFo
// Imports: public import Init public meta import Init public import Mathlib public import Development.WeilBound.CoreStatements.TemperedRepresentationTheory.HodgeWedgeFields.H1CommutesBaseChange public import Development.AbelianVarietyTheory.Proofs.DivisorProofs.CechTripleRestrictCompositeInjectiveSecond
#include <lean/lean.h>
#if defined(__clang__)
#pragma clang diagnostic ignored "-Wunused-parameter"
#pragma clang diagnostic ignored "-Wunused-label"
#elif defined(__GNUC__) && !defined(__CLANG__)
#pragma GCC diagnostic ignored "-Wunused-parameter"
#pragma GCC diagnostic ignored "-Wunused-label"
#pragma GCC diagnostic ignored "-Wunused-but-set-variable"
#endif
#ifdef __cplusplus
extern "C" {
#endif
lean_object* lp_tree_GlobalTheory_CechDR_pairPull___redArg(lean_object*, lean_object*, lean_object*);
lean_object* lp_tree_GlobalTheory_CechDR_secPull___redArg(lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_CompanionTheory_HopfSys_secA___redArg(lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_CompanionTheory_HopfSys_secA(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_CompanionTheory_HopfSys_secA___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_CompanionTheory_HopfSys_pairFn___redArg___lam__0(lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_CompanionTheory_HopfSys_pairFn___redArg___lam__1(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_CompanionTheory_HopfSys_pairFn___redArg___lam__1___boxed(lean_object*, lean_object*, lean_object*);
static const lean_closure_object lp_tree_GlobalTheory_CompanionTheory_HopfSys_pairFn___redArg___closed__0_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_closure_object) + sizeof(void*)*0, .m_other = 0, .m_tag = 245}, .m_fun = (void*)lp_tree_GlobalTheory_CompanionTheory_HopfSys_pairFn___redArg___lam__1___boxed, .m_arity = 3, .m_num_fixed = 0, .m_objs = {} };
static const lean_object* lp_tree_GlobalTheory_CompanionTheory_HopfSys_pairFn___redArg___closed__0 = (const lean_object*)&lp_tree_GlobalTheory_CompanionTheory_HopfSys_pairFn___redArg___closed__0_value;
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_CompanionTheory_HopfSys_pairFn___redArg(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_CompanionTheory_HopfSys_pairFn(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_CompanionTheory_HopfSys_pairFn___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_CompanionTheory_HopfSys_liftAlong___redArg___lam__0(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_CompanionTheory_HopfSys_liftAlong___redArg(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_CompanionTheory_HopfSys_liftAlong(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_CompanionTheory_HopfSys_liftAlong___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_CompanionTheory_HopfSys_toAlg___redArg(lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_CompanionTheory_HopfSys_toAlg(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_CompanionTheory_HopfSys_toAlg___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_CompanionTheory_HopfSys_tK___redArg___lam__0(lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_CompanionTheory_HopfSys_tK___redArg___lam__1(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_CompanionTheory_HopfSys_tK___redArg___lam__1___boxed(lean_object*, lean_object*, lean_object*);
static const lean_closure_object lp_tree_GlobalTheory_CompanionTheory_HopfSys_tK___redArg___closed__0_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_closure_object) + sizeof(void*)*0, .m_other = 0, .m_tag = 245}, .m_fun = (void*)lp_tree_GlobalTheory_CompanionTheory_HopfSys_tK___redArg___lam__1___boxed, .m_arity = 3, .m_num_fixed = 0, .m_objs = {} };
static const lean_object* lp_tree_GlobalTheory_CompanionTheory_HopfSys_tK___redArg___closed__0 = (const lean_object*)&lp_tree_GlobalTheory_CompanionTheory_HopfSys_tK___redArg___closed__0_value;
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_CompanionTheory_HopfSys_tK___redArg(lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_CompanionTheory_HopfSys_tK(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_CompanionTheory_HopfSys_tK___boxed(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_CompanionTheory_HopfSys_secA___redArg(lean_object* v_X_1_, lean_object* v_X_x27_2_, lean_object* v_00_u03c6_3_, lean_object* v_p_4_){
_start:
{
lean_object* v___x_5_; 
v___x_5_ = lp_tree_GlobalTheory_CechDR_secPull___redArg(v_X_1_, v_X_x27_2_, v_00_u03c6_3_, v_p_4_);
return v___x_5_;
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_CompanionTheory_HopfSys_secA(lean_object* v_R_6_, lean_object* v_inst_7_, lean_object* v_X_8_, lean_object* v_X_x27_9_, lean_object* v_s_10_, lean_object* v_s_x27_11_, lean_object* v_00_u03c6_12_, lean_object* v_h_13_, lean_object* v_p_14_){
_start:
{
lean_object* v___x_15_; 
v___x_15_ = lp_tree_GlobalTheory_CechDR_secPull___redArg(v_X_8_, v_X_x27_9_, v_00_u03c6_12_, v_p_14_);
return v___x_15_;
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_CompanionTheory_HopfSys_secA___boxed(lean_object* v_R_16_, lean_object* v_inst_17_, lean_object* v_X_18_, lean_object* v_X_x27_19_, lean_object* v_s_20_, lean_object* v_s_x27_21_, lean_object* v_00_u03c6_22_, lean_object* v_h_23_, lean_object* v_p_24_){
_start:
{
lean_object* v_res_25_; 
v_res_25_ = lp_tree_GlobalTheory_CompanionTheory_HopfSys_secA(v_R_16_, v_inst_17_, v_X_18_, v_X_x27_19_, v_s_20_, v_s_x27_21_, v_00_u03c6_22_, v_h_23_, v_p_24_);
lean_dec_ref(v_s_x27_21_);
lean_dec_ref(v_s_20_);
lean_dec_ref(v_inst_17_);
return v_res_25_;
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_CompanionTheory_HopfSys_pairFn___redArg___lam__0(lean_object* v_fb_26_, lean_object* v_u_27_, lean_object* v_t_28_, lean_object* v_d_29_){
_start:
{
lean_object* v_obj_30_; lean_object* v_obj_31_; lean_object* v_obj_32_; lean_object* v___x_34_; uint8_t v_isShared_35_; uint8_t v_isSharedCheck_42_; 
v_obj_30_ = lean_ctor_get(v_fb_26_, 0);
lean_inc(v_obj_30_);
lean_dec_ref(v_fb_26_);
v_obj_31_ = lean_ctor_get(v_u_27_, 0);
lean_inc(v_obj_31_);
lean_dec_ref(v_u_27_);
v_obj_32_ = lean_ctor_get(v_t_28_, 0);
v_isSharedCheck_42_ = !lean_is_exclusive(v_t_28_);
if (v_isSharedCheck_42_ == 0)
{
lean_object* v_unused_43_; 
v_unused_43_ = lean_ctor_get(v_t_28_, 1);
lean_dec(v_unused_43_);
v___x_34_ = v_t_28_;
v_isShared_35_ = v_isSharedCheck_42_;
goto v_resetjp_33_;
}
else
{
lean_inc(v_obj_32_);
lean_dec(v_t_28_);
v___x_34_ = lean_box(0);
v_isShared_35_ = v_isSharedCheck_42_;
goto v_resetjp_33_;
}
v_resetjp_33_:
{
lean_object* v___x_36_; lean_object* v___x_37_; lean_object* v___x_38_; lean_object* v___x_40_; 
lean_inc(v_d_29_);
v___x_36_ = lean_apply_1(v_obj_30_, v_d_29_);
v___x_37_ = lean_apply_1(v_obj_32_, v_d_29_);
v___x_38_ = lean_apply_1(v_obj_31_, v___x_37_);
if (v_isShared_35_ == 0)
{
lean_ctor_set(v___x_34_, 1, v___x_38_);
lean_ctor_set(v___x_34_, 0, v___x_36_);
v___x_40_ = v___x_34_;
goto v_reusejp_39_;
}
else
{
lean_object* v_reuseFailAlloc_41_; 
v_reuseFailAlloc_41_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_41_, 0, v___x_36_);
lean_ctor_set(v_reuseFailAlloc_41_, 1, v___x_38_);
v___x_40_ = v_reuseFailAlloc_41_;
goto v_reusejp_39_;
}
v_reusejp_39_:
{
return v___x_40_;
}
}
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_CompanionTheory_HopfSys_pairFn___redArg___lam__1(lean_object* v_d_44_, lean_object* v_d_x27_45_, lean_object* v_a_46_){
_start:
{
lean_object* v___x_47_; 
v___x_47_ = lean_box(0);
return v___x_47_;
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_CompanionTheory_HopfSys_pairFn___redArg___lam__1___boxed(lean_object* v_d_48_, lean_object* v_d_x27_49_, lean_object* v_a_50_){
_start:
{
lean_object* v_res_51_; 
v_res_51_ = lp_tree_GlobalTheory_CompanionTheory_HopfSys_pairFn___redArg___lam__1(v_d_48_, v_d_x27_49_, v_a_50_);
lean_dec(v_a_50_);
lean_dec(v_d_x27_49_);
lean_dec(v_d_48_);
return v_res_51_;
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_CompanionTheory_HopfSys_pairFn___redArg(lean_object* v_u_53_, lean_object* v_t_54_, lean_object* v_fb_55_){
_start:
{
lean_object* v___f_56_; lean_object* v___f_57_; lean_object* v___x_58_; 
v___f_56_ = lean_alloc_closure((void*)(lp_tree_GlobalTheory_CompanionTheory_HopfSys_pairFn___redArg___lam__0), 4, 3);
lean_closure_set(v___f_56_, 0, v_fb_55_);
lean_closure_set(v___f_56_, 1, v_u_53_);
lean_closure_set(v___f_56_, 2, v_t_54_);
v___f_57_ = ((lean_object*)(lp_tree_GlobalTheory_CompanionTheory_HopfSys_pairFn___redArg___closed__0));
v___x_58_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_58_, 0, v___f_56_);
lean_ctor_set(v___x_58_, 1, v___f_57_);
return v___x_58_;
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_CompanionTheory_HopfSys_pairFn(lean_object* v_X_59_, lean_object* v_X_x27_60_, lean_object* v_C_61_, lean_object* v_D_62_, lean_object* v_inst_63_, lean_object* v_inst_64_, lean_object* v_00_u03c6_65_, lean_object* v_u_66_, lean_object* v_t_67_, lean_object* v_fb_68_, lean_object* v_hle_69_){
_start:
{
lean_object* v___x_70_; 
v___x_70_ = lp_tree_GlobalTheory_CompanionTheory_HopfSys_pairFn___redArg(v_u_66_, v_t_67_, v_fb_68_);
return v___x_70_;
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_CompanionTheory_HopfSys_pairFn___boxed(lean_object* v_X_71_, lean_object* v_X_x27_72_, lean_object* v_C_73_, lean_object* v_D_74_, lean_object* v_inst_75_, lean_object* v_inst_76_, lean_object* v_00_u03c6_77_, lean_object* v_u_78_, lean_object* v_t_79_, lean_object* v_fb_80_, lean_object* v_hle_81_){
_start:
{
lean_object* v_res_82_; 
v_res_82_ = lp_tree_GlobalTheory_CompanionTheory_HopfSys_pairFn(v_X_71_, v_X_x27_72_, v_C_73_, v_D_74_, v_inst_75_, v_inst_76_, v_00_u03c6_77_, v_u_78_, v_t_79_, v_fb_80_, v_hle_81_);
lean_dec_ref(v_00_u03c6_77_);
lean_dec_ref(v_inst_76_);
lean_dec_ref(v_inst_75_);
lean_dec_ref(v_X_x27_72_);
lean_dec_ref(v_X_71_);
return v_res_82_;
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_CompanionTheory_HopfSys_liftAlong___redArg___lam__0(lean_object* v_X_83_, lean_object* v_X_x27_84_, lean_object* v_00_u03c6_85_, lean_object* v_u_86_, lean_object* v_t_87_, lean_object* v_fb_88_, lean_object* v_d_89_, lean_object* v___y_90_){
_start:
{
lean_object* v___x_91_; lean_object* v_00_u03b1_92_; lean_object* v___x_93_; lean_object* v_obj_94_; lean_object* v___x_95_; lean_object* v___x_96_; 
v___x_91_ = lp_tree_GlobalTheory_CechDR_pairPull___redArg(v_X_83_, v_X_x27_84_, v_00_u03c6_85_);
v_00_u03b1_92_ = lean_ctor_get(v___x_91_, 1);
lean_inc(v_00_u03b1_92_);
lean_dec_ref(v___x_91_);
v___x_93_ = lp_tree_GlobalTheory_CompanionTheory_HopfSys_pairFn___redArg(v_u_86_, v_t_87_, v_fb_88_);
v_obj_94_ = lean_ctor_get(v___x_93_, 0);
lean_inc(v_obj_94_);
lean_dec_ref(v___x_93_);
v___x_95_ = lean_apply_1(v_obj_94_, v_d_89_);
v___x_96_ = lean_apply_2(v_00_u03b1_92_, v___x_95_, v___y_90_);
return v___x_96_;
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_CompanionTheory_HopfSys_liftAlong___redArg(lean_object* v_X_97_, lean_object* v_X_x27_98_, lean_object* v_00_u03c6_99_, lean_object* v_u_100_, lean_object* v_t_101_, lean_object* v_fb_102_){
_start:
{
lean_object* v___f_103_; lean_object* v___x_104_; 
lean_inc_ref(v_t_101_);
v___f_103_ = lean_alloc_closure((void*)(lp_tree_GlobalTheory_CompanionTheory_HopfSys_liftAlong___redArg___lam__0), 8, 6);
lean_closure_set(v___f_103_, 0, v_X_97_);
lean_closure_set(v___f_103_, 1, v_X_x27_98_);
lean_closure_set(v___f_103_, 2, v_00_u03c6_99_);
lean_closure_set(v___f_103_, 3, v_u_100_);
lean_closure_set(v___f_103_, 4, v_t_101_);
lean_closure_set(v___f_103_, 5, v_fb_102_);
v___x_104_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_104_, 0, v_t_101_);
lean_ctor_set(v___x_104_, 1, v___f_103_);
return v___x_104_;
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_CompanionTheory_HopfSys_liftAlong(lean_object* v_R_105_, lean_object* v_inst_106_, lean_object* v_X_107_, lean_object* v_X_x27_108_, lean_object* v_s_109_, lean_object* v_s_x27_110_, lean_object* v_00_u03c6_111_, lean_object* v_C_112_, lean_object* v_D_113_, lean_object* v_inst_114_, lean_object* v_inst_115_, lean_object* v_h_116_, lean_object* v_u_117_, lean_object* v_t_118_, lean_object* v_fb_119_, lean_object* v_hle_120_){
_start:
{
lean_object* v___x_121_; 
v___x_121_ = lp_tree_GlobalTheory_CompanionTheory_HopfSys_liftAlong___redArg(v_X_107_, v_X_x27_108_, v_00_u03c6_111_, v_u_117_, v_t_118_, v_fb_119_);
return v___x_121_;
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_CompanionTheory_HopfSys_liftAlong___boxed(lean_object* v_R_122_, lean_object* v_inst_123_, lean_object* v_X_124_, lean_object* v_X_x27_125_, lean_object* v_s_126_, lean_object* v_s_x27_127_, lean_object* v_00_u03c6_128_, lean_object* v_C_129_, lean_object* v_D_130_, lean_object* v_inst_131_, lean_object* v_inst_132_, lean_object* v_h_133_, lean_object* v_u_134_, lean_object* v_t_135_, lean_object* v_fb_136_, lean_object* v_hle_137_){
_start:
{
lean_object* v_res_138_; 
v_res_138_ = lp_tree_GlobalTheory_CompanionTheory_HopfSys_liftAlong(v_R_122_, v_inst_123_, v_X_124_, v_X_x27_125_, v_s_126_, v_s_x27_127_, v_00_u03c6_128_, v_C_129_, v_D_130_, v_inst_131_, v_inst_132_, v_h_133_, v_u_134_, v_t_135_, v_fb_136_, v_hle_137_);
lean_dec_ref(v_inst_132_);
lean_dec_ref(v_inst_131_);
lean_dec_ref(v_s_x27_127_);
lean_dec_ref(v_s_126_);
lean_dec_ref(v_inst_123_);
return v_res_138_;
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_CompanionTheory_HopfSys_toAlg___redArg(lean_object* v_m_139_, lean_object* v_T_140_){
_start:
{
lean_object* v_00_u03b1_141_; lean_object* v___x_142_; 
v_00_u03b1_141_ = lean_ctor_get(v_m_139_, 1);
lean_inc(v_00_u03b1_141_);
lean_dec_ref(v_m_139_);
v___x_142_ = lean_apply_1(v_00_u03b1_141_, v_T_140_);
return v___x_142_;
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_CompanionTheory_HopfSys_toAlg(lean_object* v_R_143_, lean_object* v_inst_144_, lean_object* v_C_145_, lean_object* v_D_146_, lean_object* v_inst_147_, lean_object* v_inst_148_, lean_object* v_F_149_, lean_object* v_G_150_, lean_object* v_m_151_, lean_object* v_T_152_){
_start:
{
lean_object* v___x_153_; 
v___x_153_ = lp_tree_GlobalTheory_CompanionTheory_HopfSys_toAlg___redArg(v_m_151_, v_T_152_);
return v___x_153_;
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_CompanionTheory_HopfSys_toAlg___boxed(lean_object* v_R_154_, lean_object* v_inst_155_, lean_object* v_C_156_, lean_object* v_D_157_, lean_object* v_inst_158_, lean_object* v_inst_159_, lean_object* v_F_160_, lean_object* v_G_161_, lean_object* v_m_162_, lean_object* v_T_163_){
_start:
{
lean_object* v_res_164_; 
v_res_164_ = lp_tree_GlobalTheory_CompanionTheory_HopfSys_toAlg(v_R_154_, v_inst_155_, v_C_156_, v_D_157_, v_inst_158_, v_inst_159_, v_F_160_, v_G_161_, v_m_162_, v_T_163_);
lean_dec_ref(v_G_161_);
lean_dec_ref(v_F_160_);
lean_dec_ref(v_inst_159_);
lean_dec_ref(v_inst_158_);
lean_dec_ref(v_inst_155_);
return v_res_164_;
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_CompanionTheory_HopfSys_tK___redArg___lam__0(lean_object* v_a_u2080_165_, lean_object* v_b_166_){
_start:
{
lean_object* v___x_167_; lean_object* v___x_168_; 
lean_inc(v_b_166_);
v___x_167_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_167_, 0, v_a_u2080_165_);
lean_ctor_set(v___x_167_, 1, v_b_166_);
v___x_168_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_168_, 0, v___x_167_);
lean_ctor_set(v___x_168_, 1, v_b_166_);
return v___x_168_;
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_CompanionTheory_HopfSys_tK___redArg___lam__1(lean_object* v_X_169_, lean_object* v_Y_170_, lean_object* v_f_171_){
_start:
{
lean_object* v___x_172_; lean_object* v___x_173_; 
v___x_172_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_172_, 0, lean_box(0));
lean_ctor_set(v___x_172_, 1, lean_box(0));
v___x_173_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_173_, 0, v___x_172_);
lean_ctor_set(v___x_173_, 1, lean_box(0));
return v___x_173_;
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_CompanionTheory_HopfSys_tK___redArg___lam__1___boxed(lean_object* v_X_174_, lean_object* v_Y_175_, lean_object* v_f_176_){
_start:
{
lean_object* v_res_177_; 
v_res_177_ = lp_tree_GlobalTheory_CompanionTheory_HopfSys_tK___redArg___lam__1(v_X_174_, v_Y_175_, v_f_176_);
lean_dec(v_Y_175_);
lean_dec(v_X_174_);
return v_res_177_;
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_CompanionTheory_HopfSys_tK___redArg(lean_object* v_a_u2080_179_){
_start:
{
lean_object* v___f_180_; lean_object* v___f_181_; lean_object* v___x_182_; 
v___f_180_ = lean_alloc_closure((void*)(lp_tree_GlobalTheory_CompanionTheory_HopfSys_tK___redArg___lam__0), 2, 1);
lean_closure_set(v___f_180_, 0, v_a_u2080_179_);
v___f_181_ = ((lean_object*)(lp_tree_GlobalTheory_CompanionTheory_HopfSys_tK___redArg___closed__0));
v___x_182_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_182_, 0, v___f_180_);
lean_ctor_set(v___x_182_, 1, v___f_181_);
return v___x_182_;
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_CompanionTheory_HopfSys_tK(lean_object* v_P_183_, lean_object* v_inst_184_, lean_object* v_a_u2080_185_){
_start:
{
lean_object* v___x_186_; 
v___x_186_ = lp_tree_GlobalTheory_CompanionTheory_HopfSys_tK___redArg(v_a_u2080_185_);
return v___x_186_;
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_CompanionTheory_HopfSys_tK___boxed(lean_object* v_P_187_, lean_object* v_inst_188_, lean_object* v_a_u2080_189_){
_start:
{
lean_object* v_res_190_; 
v_res_190_ = lp_tree_GlobalTheory_CompanionTheory_HopfSys_tK(v_P_187_, v_inst_188_, v_a_u2080_189_);
lean_dec_ref(v_inst_188_);
return v_res_190_;
}
}
lean_object* initialize_Init(uint8_t builtin);
lean_object* initialize_Init(uint8_t builtin);
lean_object* initialize_mathlib_Mathlib(uint8_t builtin);
lean_object* initialize_tree_Development_WeilBound_CoreStatements_TemperedRepresentationTheory_HodgeWedgeFields_H1CommutesBaseChange(uint8_t builtin);
lean_object* initialize_tree_Development_AbelianVarietyTheory_Proofs_DivisorProofs_CechTripleRestrictCompositeInjectiveSecond(uint8_t builtin);
static bool _G_initialized = false;
LEAN_EXPORT lean_object* initialize_tree_Development_AutomorphicSpectrum_Proofs_BlockDecomposition_CechTripleRestrictCompositeInjectiveCohomologyFo(uint8_t builtin) {
lean_object * res;
if (_G_initialized) return lean_io_result_mk_ok(lean_box(0));
_G_initialized = true;
res = initialize_Init(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_Init(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_mathlib_Mathlib(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_Development_WeilBound_CoreStatements_TemperedRepresentationTheory_HodgeWedgeFields_H1CommutesBaseChange(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_Development_AbelianVarietyTheory_Proofs_DivisorProofs_CechTripleRestrictCompositeInjectiveSecond(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
return lean_io_result_mk_ok(lean_box(0));
}
#ifdef __cplusplus
}
#endif
