// Lean compiler output
// Module: Development.AbelianVarietyTheory.Proofs.ThetaShiftProofs.ExistsWitDataLevelAgree
// Imports: public import Init public meta import Init public import Mathlib public import ReciprocityTheory.ReductiveGroups.ArithmeticGeometry.BirationalGeometry.ToroidalCompactification.DataRigidSt public import Development.AbelianVarietyTheory.Definitions.ArchimedeanThetaValues.IsPrimitiveRootArcRoot public import Development.AbelianVarietyTheory.Definitions.ArchimedeanThetaValues.ArcVarZpowInjective
#include <lean/lean.h>
#if defined(__clang__)
#pragma clang diagnostic ignored "-Wunused-parameter"
#pragma clang diagnostic ignored "-Wunused-label"
#elif defined(__GNUC__) && !defined(__CLANG__)
#pragma GCC diagnostic ignored "-Wunused-parameter"
#pragma GCC diagnostic ignored "-Wunused-label"
#pragma GCC diagnostic ignored "-Wunused-but-set-variable"
#endif
#ifdef __cplusplus
extern "C" {
#endif
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_HostModel_instModuleWitP___aux__1___redArg(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_HostModel_instModuleWitP___aux__1(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_HostModel_instModuleWitP___aux__1___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_HostModel_instModuleWitP___redArg(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_HostModel_instModuleWitP(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_HostModel_instModuleWitP___aux__1___redArg(lean_object* v_inst_1_, lean_object* v_x1_2_, lean_object* v_x2_3_){
_start:
{
lean_object* v_toCommRing_4_; lean_object* v_toSemiring_5_; lean_object* v_toMonoid_6_; lean_object* v_toSemigroup_7_; lean_object* v___x_8_; 
v_toCommRing_4_ = lean_ctor_get(v_inst_1_, 0);
lean_inc_ref(v_toCommRing_4_);
lean_dec_ref(v_inst_1_);
v_toSemiring_5_ = lean_ctor_get(v_toCommRing_4_, 0);
lean_inc_ref(v_toSemiring_5_);
lean_dec_ref(v_toCommRing_4_);
v_toMonoid_6_ = lean_ctor_get(v_toSemiring_5_, 1);
lean_inc_ref(v_toMonoid_6_);
lean_dec_ref(v_toSemiring_5_);
v_toSemigroup_7_ = lean_ctor_get(v_toMonoid_6_, 0);
lean_inc(v_toSemigroup_7_);
lean_dec_ref(v_toMonoid_6_);
v___x_8_ = lean_apply_2(v_toSemigroup_7_, v_x1_2_, v_x2_3_);
return v___x_8_;
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_HostModel_instModuleWitP___aux__1(lean_object* v_E_9_, lean_object* v_inst_10_, lean_object* v_inst_11_, lean_object* v_inst_12_, lean_object* v_H_13_, lean_object* v_l_14_, lean_object* v_c_15_, lean_object* v_k_16_, lean_object* v_inst_17_, lean_object* v_bF_18_, lean_object* v_x1_19_, lean_object* v_x2_20_){
_start:
{
lean_object* v_toCommRing_21_; lean_object* v_toSemiring_22_; lean_object* v_toMonoid_23_; lean_object* v_toSemigroup_24_; lean_object* v___x_25_; 
v_toCommRing_21_ = lean_ctor_get(v_inst_10_, 0);
lean_inc_ref(v_toCommRing_21_);
lean_dec_ref(v_inst_10_);
v_toSemiring_22_ = lean_ctor_get(v_toCommRing_21_, 0);
lean_inc_ref(v_toSemiring_22_);
lean_dec_ref(v_toCommRing_21_);
v_toMonoid_23_ = lean_ctor_get(v_toSemiring_22_, 1);
lean_inc_ref(v_toMonoid_23_);
lean_dec_ref(v_toSemiring_22_);
v_toSemigroup_24_ = lean_ctor_get(v_toMonoid_23_, 0);
lean_inc(v_toSemigroup_24_);
lean_dec_ref(v_toMonoid_23_);
v___x_25_ = lean_apply_2(v_toSemigroup_24_, v_x1_19_, v_x2_20_);
return v___x_25_;
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_HostModel_instModuleWitP___aux__1___boxed(lean_object* v_E_26_, lean_object* v_inst_27_, lean_object* v_inst_28_, lean_object* v_inst_29_, lean_object* v_H_30_, lean_object* v_l_31_, lean_object* v_c_32_, lean_object* v_k_33_, lean_object* v_inst_34_, lean_object* v_bF_35_, lean_object* v_x1_36_, lean_object* v_x2_37_){
_start:
{
lean_object* v_res_38_; 
v_res_38_ = lp_tree_GlobalTheory_HostModel_instModuleWitP___aux__1(v_E_26_, v_inst_27_, v_inst_28_, v_inst_29_, v_H_30_, v_l_31_, v_c_32_, v_k_33_, v_inst_34_, v_bF_35_, v_x1_36_, v_x2_37_);
lean_dec(v_bF_35_);
lean_dec_ref(v_inst_34_);
lean_dec_ref(v_l_31_);
lean_dec_ref(v_H_30_);
return v_res_38_;
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_HostModel_instModuleWitP___redArg(lean_object* v_inst_39_, lean_object* v_H_40_, lean_object* v_l_41_, lean_object* v_c_42_, lean_object* v_inst_43_, lean_object* v_bF_44_){
_start:
{
lean_object* v___x_45_; 
v___x_45_ = lean_alloc_closure((void*)(lp_tree_GlobalTheory_HostModel_instModuleWitP___aux__1___boxed), 12, 10);
lean_closure_set(v___x_45_, 0, lean_box(0));
lean_closure_set(v___x_45_, 1, v_inst_39_);
lean_closure_set(v___x_45_, 2, lean_box(0));
lean_closure_set(v___x_45_, 3, lean_box(0));
lean_closure_set(v___x_45_, 4, v_H_40_);
lean_closure_set(v___x_45_, 5, v_l_41_);
lean_closure_set(v___x_45_, 6, v_c_42_);
lean_closure_set(v___x_45_, 7, lean_box(0));
lean_closure_set(v___x_45_, 8, v_inst_43_);
lean_closure_set(v___x_45_, 9, v_bF_44_);
return v___x_45_;
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_HostModel_instModuleWitP(lean_object* v_E_46_, lean_object* v_inst_47_, lean_object* v_inst_48_, lean_object* v_inst_49_, lean_object* v_H_50_, lean_object* v_l_51_, lean_object* v_c_52_, lean_object* v_k_53_, lean_object* v_inst_54_, lean_object* v_bF_55_){
_start:
{
lean_object* v___x_56_; 
v___x_56_ = lean_alloc_closure((void*)(lp_tree_GlobalTheory_HostModel_instModuleWitP___aux__1___boxed), 12, 10);
lean_closure_set(v___x_56_, 0, lean_box(0));
lean_closure_set(v___x_56_, 1, v_inst_47_);
lean_closure_set(v___x_56_, 2, lean_box(0));
lean_closure_set(v___x_56_, 3, lean_box(0));
lean_closure_set(v___x_56_, 4, v_H_50_);
lean_closure_set(v___x_56_, 5, v_l_51_);
lean_closure_set(v___x_56_, 6, v_c_52_);
lean_closure_set(v___x_56_, 7, lean_box(0));
lean_closure_set(v___x_56_, 8, v_inst_54_);
lean_closure_set(v___x_56_, 9, v_bF_55_);
return v___x_56_;
}
}
lean_object* initialize_Init(uint8_t builtin);
lean_object* initialize_Init(uint8_t builtin);
lean_object* initialize_mathlib_Mathlib(uint8_t builtin);
lean_object* initialize_tree_ReciprocityTheory_ReductiveGroups_ArithmeticGeometry_BirationalGeometry_ToroidalCompactification_DataRigidSt(uint8_t builtin);
lean_object* initialize_tree_Development_AbelianVarietyTheory_Definitions_ArchimedeanThetaValues_IsPrimitiveRootArcRoot(uint8_t builtin);
lean_object* initialize_tree_Development_AbelianVarietyTheory_Definitions_ArchimedeanThetaValues_ArcVarZpowInjective(uint8_t builtin);
static bool _G_initialized = false;
LEAN_EXPORT lean_object* initialize_tree_Development_AbelianVarietyTheory_Proofs_ThetaShiftProofs_ExistsWitDataLevelAgree(uint8_t builtin) {
lean_object * res;
if (_G_initialized) return lean_io_result_mk_ok(lean_box(0));
_G_initialized = true;
res = initialize_Init(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_Init(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_mathlib_Mathlib(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_ReciprocityTheory_ReductiveGroups_ArithmeticGeometry_BirationalGeometry_ToroidalCompactification_DataRigidSt(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_Development_AbelianVarietyTheory_Definitions_ArchimedeanThetaValues_IsPrimitiveRootArcRoot(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_Development_AbelianVarietyTheory_Definitions_ArchimedeanThetaValues_ArcVarZpowInjective(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
return lean_io_result_mk_ok(lean_box(0));
}
#ifdef __cplusplus
}
#endif
