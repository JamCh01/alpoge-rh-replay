// Lean compiler output
// Module: ReciprocityTheory.ReductiveGroups.DiscreteSeries.MultiplicityOne.JBePos
// Imports: public import Init public meta import Init public import ReciprocityTheory.ReductiveGroups.DiscreteSeries.MultiplicityOne.StSchurW public import ReciprocityTheory.ReductiveGroups.DiscreteSeries.MultiplicityOne.UnitaryGroupStructuralFacts public import ReciprocityTheory.ReductiveGroups.DiscreteSeries.MultiplicityOne.JSchurG public import ReciprocityTheory.ReductiveGroups.DiscreteSeries.MultiplicityOne.StSInt public import ReciprocityTheory.ReductiveGroups.DiscreteSeries.MultiplicityOne.JBePosB
#include <lean/lean.h>
#if defined(__clang__)
#pragma clang diagnostic ignored "-Wunused-parameter"
#pragma clang diagnostic ignored "-Wunused-label"
#elif defined(__GNUC__) && !defined(__CLANG__)
#pragma GCC diagnostic ignored "-Wunused-parameter"
#pragma GCC diagnostic ignored "-Wunused-label"
#pragma GCC diagnostic ignored "-Wunused-but-set-variable"
#endif
#ifdef __cplusplus
extern "C" {
#endif
lean_object* initialize_Init(uint8_t builtin);
lean_object* initialize_Init(uint8_t builtin);
lean_object* initialize_tree_ReciprocityTheory_ReductiveGroups_DiscreteSeries_MultiplicityOne_StSchurW(uint8_t builtin);
lean_object* initialize_tree_ReciprocityTheory_ReductiveGroups_DiscreteSeries_MultiplicityOne_UnitaryGroupStructuralFacts(uint8_t builtin);
lean_object* initialize_tree_ReciprocityTheory_ReductiveGroups_DiscreteSeries_MultiplicityOne_JSchurG(uint8_t builtin);
lean_object* initialize_tree_ReciprocityTheory_ReductiveGroups_DiscreteSeries_MultiplicityOne_StSInt(uint8_t builtin);
lean_object* initialize_tree_ReciprocityTheory_ReductiveGroups_DiscreteSeries_MultiplicityOne_JBePosB(uint8_t builtin);
static bool _G_initialized = false;
LEAN_EXPORT lean_object* initialize_tree_ReciprocityTheory_ReductiveGroups_DiscreteSeries_MultiplicityOne_JBePos(uint8_t builtin) {
lean_object * res;
if (_G_initialized) return lean_io_result_mk_ok(lean_box(0));
_G_initialized = true;
res = initialize_Init(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_Init(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_ReciprocityTheory_ReductiveGroups_DiscreteSeries_MultiplicityOne_StSchurW(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_ReciprocityTheory_ReductiveGroups_DiscreteSeries_MultiplicityOne_UnitaryGroupStructuralFacts(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_ReciprocityTheory_ReductiveGroups_DiscreteSeries_MultiplicityOne_JSchurG(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_ReciprocityTheory_ReductiveGroups_DiscreteSeries_MultiplicityOne_StSInt(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_ReciprocityTheory_ReductiveGroups_DiscreteSeries_MultiplicityOne_JBePosB(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
return lean_io_result_mk_ok(lean_box(0));
}
#ifdef __cplusplus
}
#endif
