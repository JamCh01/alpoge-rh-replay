// Lean compiler output
// Module: ReciprocityTheory.ReductiveGroups.DiscreteSeries.LaplaceOperators.KTypeLemma.VermaCone
// Imports: public import Init public meta import Init public import ReciprocityTheory.ReductiveGroups.DiscreteSeries.LaplaceOperators.KTypeLemma.VermaConeC
#include <lean/lean.h>
#if defined(__clang__)
#pragma clang diagnostic ignored "-Wunused-parameter"
#pragma clang diagnostic ignored "-Wunused-label"
#elif defined(__GNUC__) && !defined(__CLANG__)
#pragma GCC diagnostic ignored "-Wunused-parameter"
#pragma GCC diagnostic ignored "-Wunused-label"
#pragma GCC diagnostic ignored "-Wunused-but-set-variable"
#endif
#ifdef __cplusplus
extern "C" {
#endif
lean_object* lp_mathlib_SubNegZeroMonoid_toNegZeroClass___redArg(lean_object*);
lean_object* l_instDecidableEqFin___boxed(lean_object*, lean_object*, lean_object*);
lean_object* lp_mathlib_Pi_single___redArg(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
lean_object* lean_nat_add(lean_object*, lean_object*);
lean_object* lean_nat_sub(lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_ReciprocityTheory_ChartRestriction_DS_Lap_LemK_vcSgl___redArg___lam__0(lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_ReciprocityTheory_ChartRestriction_DS_Lap_LemK_vcSgl___redArg___lam__0___boxed(lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_ReciprocityTheory_ChartRestriction_DS_Lap_LemK_vcSgl___redArg(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_ReciprocityTheory_ChartRestriction_DS_Lap_LemK_vcSgl___redArg___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_ReciprocityTheory_ChartRestriction_DS_Lap_LemK_vcSgl(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_ReciprocityTheory_ChartRestriction_DS_Lap_LemK_vcSgl___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_ReciprocityTheory_ChartRestriction_DS_Lap_LemK_vcRV___redArg(lean_object*);
LEAN_EXPORT lean_object* lp_tree_ReciprocityTheory_ChartRestriction_DS_Lap_LemK_vcRV___redArg___boxed(lean_object*);
LEAN_EXPORT lean_object* lp_tree_ReciprocityTheory_ChartRestriction_DS_Lap_LemK_vcRV(lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_ReciprocityTheory_ChartRestriction_DS_Lap_LemK_vcRV___boxed(lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_ReciprocityTheory_ChartRestriction_DS_Lap_LemK_vcRVd(lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_ReciprocityTheory_ChartRestriction_DS_Lap_LemK_vcRVd___boxed(lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_ReciprocityTheory_ChartRestriction_DS_Lap_LemK_vcSgl___redArg___lam__0(lean_object* v_toZero_1_, lean_object* v_i_2_){
_start:
{
lean_inc(v_toZero_1_);
return v_toZero_1_;
}
}
LEAN_EXPORT lean_object* lp_tree_ReciprocityTheory_ChartRestriction_DS_Lap_LemK_vcSgl___redArg___lam__0___boxed(lean_object* v_toZero_3_, lean_object* v_i_4_){
_start:
{
lean_object* v_res_5_; 
v_res_5_ = lp_tree_ReciprocityTheory_ChartRestriction_DS_Lap_LemK_vcSgl___redArg___lam__0(v_toZero_3_, v_i_4_);
lean_dec(v_i_4_);
lean_dec(v_toZero_3_);
return v_res_5_;
}
}
LEAN_EXPORT lean_object* lp_tree_ReciprocityTheory_ChartRestriction_DS_Lap_LemK_vcSgl___redArg(lean_object* v_n_6_, lean_object* v_inst_7_, lean_object* v_00_u03c6_8_, lean_object* v_t_9_, lean_object* v_j_10_){
_start:
{
lean_object* v___x_11_; lean_object* v_toZero_12_; lean_object* v___f_13_; lean_object* v___x_14_; lean_object* v___x_15_; 
v___x_11_ = lp_mathlib_SubNegZeroMonoid_toNegZeroClass___redArg(v_inst_7_);
v_toZero_12_ = lean_ctor_get(v___x_11_, 0);
lean_inc(v_toZero_12_);
lean_dec_ref(v___x_11_);
v___f_13_ = lean_alloc_closure((void*)(lp_tree_ReciprocityTheory_ChartRestriction_DS_Lap_LemK_vcSgl___redArg___lam__0___boxed), 2, 1);
lean_closure_set(v___f_13_, 0, v_toZero_12_);
v___x_14_ = lean_alloc_closure((void*)(l_instDecidableEqFin___boxed), 3, 1);
lean_closure_set(v___x_14_, 0, v_n_6_);
v___x_15_ = lp_mathlib_Pi_single___redArg(v___f_13_, v___x_14_, v_t_9_, v_00_u03c6_8_, v_j_10_);
return v___x_15_;
}
}
LEAN_EXPORT lean_object* lp_tree_ReciprocityTheory_ChartRestriction_DS_Lap_LemK_vcSgl___redArg___boxed(lean_object* v_n_16_, lean_object* v_inst_17_, lean_object* v_00_u03c6_18_, lean_object* v_t_19_, lean_object* v_j_20_){
_start:
{
lean_object* v_res_21_; 
v_res_21_ = lp_tree_ReciprocityTheory_ChartRestriction_DS_Lap_LemK_vcSgl___redArg(v_n_16_, v_inst_17_, v_00_u03c6_18_, v_t_19_, v_j_20_);
lean_dec(v_00_u03c6_18_);
lean_dec_ref(v_inst_17_);
return v_res_21_;
}
}
LEAN_EXPORT lean_object* lp_tree_ReciprocityTheory_ChartRestriction_DS_Lap_LemK_vcSgl(lean_object* v_n_22_, lean_object* v_M_23_, lean_object* v_inst_24_, lean_object* v_00_u03c6_25_, lean_object* v_t_26_, lean_object* v_j_27_){
_start:
{
lean_object* v___x_28_; 
v___x_28_ = lp_tree_ReciprocityTheory_ChartRestriction_DS_Lap_LemK_vcSgl___redArg(v_n_22_, v_inst_24_, v_00_u03c6_25_, v_t_26_, v_j_27_);
return v___x_28_;
}
}
LEAN_EXPORT lean_object* lp_tree_ReciprocityTheory_ChartRestriction_DS_Lap_LemK_vcSgl___boxed(lean_object* v_n_29_, lean_object* v_M_30_, lean_object* v_inst_31_, lean_object* v_00_u03c6_32_, lean_object* v_t_33_, lean_object* v_j_34_){
_start:
{
lean_object* v_res_35_; 
v_res_35_ = lp_tree_ReciprocityTheory_ChartRestriction_DS_Lap_LemK_vcSgl(v_n_29_, v_M_30_, v_inst_31_, v_00_u03c6_32_, v_t_33_, v_j_34_);
lean_dec(v_00_u03c6_32_);
lean_dec_ref(v_inst_31_);
return v_res_35_;
}
}
LEAN_EXPORT lean_object* lp_tree_ReciprocityTheory_ChartRestriction_DS_Lap_LemK_vcRV___redArg(lean_object* v_t_36_){
_start:
{
lean_inc(v_t_36_);
return v_t_36_;
}
}
LEAN_EXPORT lean_object* lp_tree_ReciprocityTheory_ChartRestriction_DS_Lap_LemK_vcRV___redArg___boxed(lean_object* v_t_37_){
_start:
{
lean_object* v_res_38_; 
v_res_38_ = lp_tree_ReciprocityTheory_ChartRestriction_DS_Lap_LemK_vcRV___redArg(v_t_37_);
lean_dec(v_t_37_);
return v_res_38_;
}
}
LEAN_EXPORT lean_object* lp_tree_ReciprocityTheory_ChartRestriction_DS_Lap_LemK_vcRV(lean_object* v_n_39_, lean_object* v_t_40_){
_start:
{
lean_inc(v_t_40_);
return v_t_40_;
}
}
LEAN_EXPORT lean_object* lp_tree_ReciprocityTheory_ChartRestriction_DS_Lap_LemK_vcRV___boxed(lean_object* v_n_41_, lean_object* v_t_42_){
_start:
{
lean_object* v_res_43_; 
v_res_43_ = lp_tree_ReciprocityTheory_ChartRestriction_DS_Lap_LemK_vcRV(v_n_41_, v_t_42_);
lean_dec(v_t_42_);
lean_dec(v_n_41_);
return v_res_43_;
}
}
LEAN_EXPORT lean_object* lp_tree_ReciprocityTheory_ChartRestriction_DS_Lap_LemK_vcRVd(lean_object* v_n_44_, lean_object* v_t_45_){
_start:
{
lean_object* v___x_46_; lean_object* v___x_47_; lean_object* v___x_48_; 
v___x_46_ = lean_unsigned_to_nat(1u);
v___x_47_ = lean_nat_add(v_t_45_, v___x_46_);
v___x_48_ = lean_nat_sub(v_n_44_, v___x_47_);
lean_dec(v___x_47_);
return v___x_48_;
}
}
LEAN_EXPORT lean_object* lp_tree_ReciprocityTheory_ChartRestriction_DS_Lap_LemK_vcRVd___boxed(lean_object* v_n_49_, lean_object* v_t_50_){
_start:
{
lean_object* v_res_51_; 
v_res_51_ = lp_tree_ReciprocityTheory_ChartRestriction_DS_Lap_LemK_vcRVd(v_n_49_, v_t_50_);
lean_dec(v_t_50_);
lean_dec(v_n_49_);
return v_res_51_;
}
}
lean_object* initialize_Init(uint8_t builtin);
lean_object* initialize_Init(uint8_t builtin);
lean_object* initialize_tree_ReciprocityTheory_ReductiveGroups_DiscreteSeries_LaplaceOperators_KTypeLemma_VermaConeC(uint8_t builtin);
static bool _G_initialized = false;
LEAN_EXPORT lean_object* initialize_tree_ReciprocityTheory_ReductiveGroups_DiscreteSeries_LaplaceOperators_KTypeLemma_VermaCone(uint8_t builtin) {
lean_object * res;
if (_G_initialized) return lean_io_result_mk_ok(lean_box(0));
_G_initialized = true;
res = initialize_Init(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_Init(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_ReciprocityTheory_ReductiveGroups_DiscreteSeries_LaplaceOperators_KTypeLemma_VermaConeC(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
return lean_io_result_mk_ok(lean_box(0));
}
#ifdef __cplusplus
}
#endif
