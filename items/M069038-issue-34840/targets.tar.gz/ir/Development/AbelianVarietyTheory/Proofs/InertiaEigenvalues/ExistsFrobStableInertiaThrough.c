// Lean compiler output
// Module: Development.AbelianVarietyTheory.Proofs.InertiaEigenvalues.ExistsFrobStableInertiaThrough
// Imports: public import Init public meta import Init public import Mathlib public import Formalism.WeaklyAdmissibleFiltrations.CrystallineStableLifts.DPotCrisStableAndExistsPotentiallyCrystallineDat public import Development.AbelianVarietyTheory.Proofs.SatakeParameters.IsCrystallineJumpsOfIsIsoMatrixGaloisRepresentat
#include <lean/lean.h>
#if defined(__clang__)
#pragma clang diagnostic ignored "-Wunused-parameter"
#pragma clang diagnostic ignored "-Wunused-label"
#elif defined(__GNUC__) && !defined(__CLANG__)
#pragma GCC diagnostic ignored "-Wunused-parameter"
#pragma GCC diagnostic ignored "-Wunused-label"
#pragma GCC diagnostic ignored "-Wunused-but-set-variable"
#endif
#ifdef __cplusplus
extern "C" {
#endif
lean_object* lp_mathlib_Monoid_toMulOneClass___redArg(lean_object*);
lean_object* lp_mathlib_DivInvOneMonoid_toInvOneClass___redArg(lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_inerConj___redArg___lam__0(lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_inerConj___redArg(lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_inerConj___redArg___boxed(lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_inerConj(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_inerConj___boxed(lean_object**);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_inerConj___redArg___lam__0(lean_object* v_toInv_1_, lean_object* v_F_2_, lean_object* v_toMul_3_, lean_object* v_g_4_){
_start:
{
lean_object* v___x_5_; lean_object* v___x_6_; lean_object* v___x_7_; 
lean_inc(v_F_2_);
v___x_5_ = lean_apply_1(v_toInv_1_, v_F_2_);
lean_inc(v_toMul_3_);
v___x_6_ = lean_apply_2(v_toMul_3_, v___x_5_, v_g_4_);
v___x_7_ = lean_apply_2(v_toMul_3_, v___x_6_, v_F_2_);
return v___x_7_;
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_inerConj___redArg(lean_object* v_inst_8_, lean_object* v_F_9_){
_start:
{
lean_object* v_toMonoid_10_; lean_object* v___x_11_; lean_object* v_toMul_12_; lean_object* v___x_13_; lean_object* v_toInv_14_; lean_object* v___f_15_; 
v_toMonoid_10_ = lean_ctor_get(v_inst_8_, 0);
v___x_11_ = lp_mathlib_Monoid_toMulOneClass___redArg(v_toMonoid_10_);
v_toMul_12_ = lean_ctor_get(v___x_11_, 1);
lean_inc(v_toMul_12_);
lean_dec_ref(v___x_11_);
v___x_13_ = lp_mathlib_DivInvOneMonoid_toInvOneClass___redArg(v_inst_8_);
v_toInv_14_ = lean_ctor_get(v___x_13_, 1);
lean_inc(v_toInv_14_);
lean_dec_ref(v___x_13_);
v___f_15_ = lean_alloc_closure((void*)(lp_tree_GlobalTheory_inerConj___redArg___lam__0), 4, 3);
lean_closure_set(v___f_15_, 0, v_toInv_14_);
lean_closure_set(v___f_15_, 1, v_F_9_);
lean_closure_set(v___f_15_, 2, v_toMul_12_);
return v___f_15_;
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_inerConj___redArg___boxed(lean_object* v_inst_16_, lean_object* v_F_17_){
_start:
{
lean_object* v_res_18_; 
v_res_18_ = lp_tree_GlobalTheory_inerConj___redArg(v_inst_16_, v_F_17_);
lean_dec_ref(v_inst_16_);
return v_res_18_;
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_inerConj(lean_object* v_G_19_, lean_object* v_inst_20_, lean_object* v_Qp_21_, lean_object* v_K_u2080_22_, lean_object* v_K_23_, lean_object* v_K_u2080_x27_24_, lean_object* v_K_x27_25_, lean_object* v_inst_26_, lean_object* v_inst_27_, lean_object* v_inst_28_, lean_object* v_inst_29_, lean_object* v_inst_30_, lean_object* v_inst_31_, lean_object* v_inst_32_, lean_object* v_inst_33_, lean_object* v_inst_34_, lean_object* v_inst_35_, lean_object* v_inst_36_, lean_object* v_inst_37_, lean_object* v_inst_38_, lean_object* v_B_39_, lean_object* v_BdR_40_, lean_object* v_inst_41_, lean_object* v_inst_42_, lean_object* v_inst_43_, lean_object* v_inst_44_, lean_object* v_inst_45_, lean_object* v_inst_46_, lean_object* v_inst_47_, lean_object* v_inst_48_, lean_object* v_inst_49_, lean_object* v_inst_50_, lean_object* v_inst_51_, lean_object* v_inst_52_, lean_object* v_inst_53_, lean_object* v_inst_54_, lean_object* v_inst_55_, lean_object* v_inst_56_, lean_object* v_inst_57_, lean_object* v_inst_58_, lean_object* v_PC_59_, lean_object* v_F_60_){
_start:
{
lean_object* v___x_61_; 
v___x_61_ = lp_tree_GlobalTheory_inerConj___redArg(v_inst_20_, v_F_60_);
return v___x_61_;
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_inerConj___boxed(lean_object** _args){
lean_object* v_G_62_ = _args[0];
lean_object* v_inst_63_ = _args[1];
lean_object* v_Qp_64_ = _args[2];
lean_object* v_K_u2080_65_ = _args[3];
lean_object* v_K_66_ = _args[4];
lean_object* v_K_u2080_x27_67_ = _args[5];
lean_object* v_K_x27_68_ = _args[6];
lean_object* v_inst_69_ = _args[7];
lean_object* v_inst_70_ = _args[8];
lean_object* v_inst_71_ = _args[9];
lean_object* v_inst_72_ = _args[10];
lean_object* v_inst_73_ = _args[11];
lean_object* v_inst_74_ = _args[12];
lean_object* v_inst_75_ = _args[13];
lean_object* v_inst_76_ = _args[14];
lean_object* v_inst_77_ = _args[15];
lean_object* v_inst_78_ = _args[16];
lean_object* v_inst_79_ = _args[17];
lean_object* v_inst_80_ = _args[18];
lean_object* v_inst_81_ = _args[19];
lean_object* v_B_82_ = _args[20];
lean_object* v_BdR_83_ = _args[21];
lean_object* v_inst_84_ = _args[22];
lean_object* v_inst_85_ = _args[23];
lean_object* v_inst_86_ = _args[24];
lean_object* v_inst_87_ = _args[25];
lean_object* v_inst_88_ = _args[26];
lean_object* v_inst_89_ = _args[27];
lean_object* v_inst_90_ = _args[28];
lean_object* v_inst_91_ = _args[29];
lean_object* v_inst_92_ = _args[30];
lean_object* v_inst_93_ = _args[31];
lean_object* v_inst_94_ = _args[32];
lean_object* v_inst_95_ = _args[33];
lean_object* v_inst_96_ = _args[34];
lean_object* v_inst_97_ = _args[35];
lean_object* v_inst_98_ = _args[36];
lean_object* v_inst_99_ = _args[37];
lean_object* v_inst_100_ = _args[38];
lean_object* v_inst_101_ = _args[39];
lean_object* v_PC_102_ = _args[40];
lean_object* v_F_103_ = _args[41];
_start:
{
lean_object* v_res_104_; 
v_res_104_ = lp_tree_GlobalTheory_inerConj(v_G_62_, v_inst_63_, v_Qp_64_, v_K_u2080_65_, v_K_66_, v_K_u2080_x27_67_, v_K_x27_68_, v_inst_69_, v_inst_70_, v_inst_71_, v_inst_72_, v_inst_73_, v_inst_74_, v_inst_75_, v_inst_76_, v_inst_77_, v_inst_78_, v_inst_79_, v_inst_80_, v_inst_81_, v_B_82_, v_BdR_83_, v_inst_84_, v_inst_85_, v_inst_86_, v_inst_87_, v_inst_88_, v_inst_89_, v_inst_90_, v_inst_91_, v_inst_92_, v_inst_93_, v_inst_94_, v_inst_95_, v_inst_96_, v_inst_97_, v_inst_98_, v_inst_99_, v_inst_100_, v_inst_101_, v_PC_102_, v_F_103_);
lean_dec_ref(v_PC_102_);
lean_dec_ref(v_inst_98_);
lean_dec_ref(v_inst_97_);
lean_dec_ref(v_inst_93_);
lean_dec_ref(v_inst_92_);
lean_dec_ref(v_inst_91_);
lean_dec_ref(v_inst_89_);
lean_dec_ref(v_inst_87_);
lean_dec_ref(v_inst_86_);
lean_dec_ref(v_inst_85_);
lean_dec_ref(v_inst_84_);
lean_dec_ref(v_inst_80_);
lean_dec_ref(v_inst_79_);
lean_dec_ref(v_inst_78_);
lean_dec_ref(v_inst_76_);
lean_dec_ref(v_inst_75_);
lean_dec_ref(v_inst_74_);
lean_dec_ref(v_inst_73_);
lean_dec_ref(v_inst_72_);
lean_dec_ref(v_inst_71_);
lean_dec_ref(v_inst_70_);
lean_dec_ref(v_inst_69_);
lean_dec_ref(v_inst_63_);
return v_res_104_;
}
}
lean_object* initialize_Init(uint8_t builtin);
lean_object* initialize_Init(uint8_t builtin);
lean_object* initialize_mathlib_Mathlib(uint8_t builtin);
lean_object* initialize_tree_Formalism_WeaklyAdmissibleFiltrations_CrystallineStableLifts_DPotCrisStableAndExistsPotentiallyCrystallineDat(uint8_t builtin);
lean_object* initialize_tree_Development_AbelianVarietyTheory_Proofs_SatakeParameters_IsCrystallineJumpsOfIsIsoMatrixGaloisRepresentat(uint8_t builtin);
static bool _G_initialized = false;
LEAN_EXPORT lean_object* initialize_tree_Development_AbelianVarietyTheory_Proofs_InertiaEigenvalues_ExistsFrobStableInertiaThrough(uint8_t builtin) {
lean_object * res;
if (_G_initialized) return lean_io_result_mk_ok(lean_box(0));
_G_initialized = true;
res = initialize_Init(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_Init(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_mathlib_Mathlib(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_Formalism_WeaklyAdmissibleFiltrations_CrystallineStableLifts_DPotCrisStableAndExistsPotentiallyCrystallineDat(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_Development_AbelianVarietyTheory_Proofs_SatakeParameters_IsCrystallineJumpsOfIsIsoMatrixGaloisRepresentat(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
return lean_io_result_mk_ok(lean_box(0));
}
#ifdef __cplusplus
}
#endif
