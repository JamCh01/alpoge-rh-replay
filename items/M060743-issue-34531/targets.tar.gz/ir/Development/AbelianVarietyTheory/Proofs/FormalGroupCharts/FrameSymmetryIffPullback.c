// Lean compiler output
// Module: Development.AbelianVarietyTheory.Proofs.FormalGroupCharts.FrameSymmetryIffPullback
// Imports: public import Init public meta import Init public import Mathlib public import Formalism.SharpRestriction.Divisibility.GeneratorPowers.GermCut public import Formalism.SharpRestriction.Divisibility.GeneratorPowers.GermBGen public import Formalism.SharpRestriction.Divisibility.GeneratorPowers.ChartPrimTrPfA public import Formalism.SharpRestriction.Divisibility.GeneratorPowers.IntChartPf public import Formalism.SharpRestriction.Divisibility.GeneratorPowers.ExistsTruncatedIntegralChart public import Formalism.LocalToGlobal.ProjectiveLattices.PlaceBelow public import ReciprocityTheory.ReductiveGroups.ArithmeticGeometry.ExtensionDescent.SecBaseChangeAnySt
#include <lean/lean.h>
#if defined(__clang__)
#pragma clang diagnostic ignored "-Wunused-parameter"
#pragma clang diagnostic ignored "-Wunused-label"
#elif defined(__GNUC__) && !defined(__CLANG__)
#pragma GCC diagnostic ignored "-Wunused-parameter"
#pragma GCC diagnostic ignored "-Wunused-label"
#pragma GCC diagnostic ignored "-Wunused-but-set-variable"
#endif
#ifdef __cplusplus
extern "C" {
#endif
lean_object* lp_tree_ReciprocityTheory_ChartRestriction_G_Semi_LB_LinComb___redArg(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
lean_object* lp_mathlib_Monoid_toMulOneClass___redArg(lean_object*);
lean_object* lp_tree_ReciprocityTheory_ChartRestriction_G_Semi_res___redArg(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_FrameSym_scale___redArg___lam__0(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_FrameSym_scale___redArg(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_FrameSym_scale(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_FrameSym_scale___redArg___lam__0(lean_object* v_Y_1_, lean_object* v___x_2_, lean_object* v_u_3_, lean_object* v_g_4_, lean_object* v_j_5_){
_start:
{
lean_object* v_presheaf_6_; lean_object* v_obj_7_; lean_object* v_U_8_; lean_object* v___x_9_; lean_object* v___x_10_; lean_object* v_toSemiring_11_; lean_object* v_toMonoid_12_; lean_object* v___x_13_; lean_object* v_toMul_14_; lean_object* v___x_15_; lean_object* v___x_157__overap_16_; lean_object* v___x_17_; lean_object* v_val_18_; lean_object* v_inv_19_; lean_object* v___x_20_; lean_object* v_val_21_; lean_object* v_inv_22_; lean_object* v___x_24_; uint8_t v_isShared_25_; uint8_t v_isSharedCheck_31_; 
v_presheaf_6_ = lean_ctor_get(v_Y_1_, 1);
v_obj_7_ = lean_ctor_get(v_presheaf_6_, 0);
v_U_8_ = lean_ctor_get(v___x_2_, 0);
lean_inc_ref(v_U_8_);
lean_dec_ref(v___x_2_);
lean_inc(v_j_5_);
v___x_9_ = lean_apply_1(v_U_8_, v_j_5_);
lean_inc(v_obj_7_);
v___x_10_ = lean_apply_1(v_obj_7_, v___x_9_);
v_toSemiring_11_ = lean_ctor_get(v___x_10_, 0);
lean_inc_ref(v_toSemiring_11_);
lean_dec_ref(v___x_10_);
v_toMonoid_12_ = lean_ctor_get(v_toSemiring_11_, 1);
lean_inc_ref(v_toMonoid_12_);
lean_dec_ref(v_toSemiring_11_);
v___x_13_ = lp_mathlib_Monoid_toMulOneClass___redArg(v_toMonoid_12_);
lean_dec_ref(v_toMonoid_12_);
v_toMul_14_ = lean_ctor_get(v___x_13_, 1);
lean_inc(v_toMul_14_);
lean_dec_ref(v___x_13_);
v___x_15_ = lean_box(0);
v___x_157__overap_16_ = lp_tree_ReciprocityTheory_ChartRestriction_G_Semi_res___redArg(v_Y_1_, v___x_15_, v___x_9_);
v___x_17_ = lean_apply_1(v___x_157__overap_16_, v_u_3_);
v_val_18_ = lean_ctor_get(v___x_17_, 0);
lean_inc(v_val_18_);
v_inv_19_ = lean_ctor_get(v___x_17_, 1);
lean_inc(v_inv_19_);
lean_dec_ref(v___x_17_);
v___x_20_ = lean_apply_1(v_g_4_, v_j_5_);
v_val_21_ = lean_ctor_get(v___x_20_, 0);
v_inv_22_ = lean_ctor_get(v___x_20_, 1);
v_isSharedCheck_31_ = !lean_is_exclusive(v___x_20_);
if (v_isSharedCheck_31_ == 0)
{
v___x_24_ = v___x_20_;
v_isShared_25_ = v_isSharedCheck_31_;
goto v_resetjp_23_;
}
else
{
lean_inc(v_inv_22_);
lean_inc(v_val_21_);
lean_dec(v___x_20_);
v___x_24_ = lean_box(0);
v_isShared_25_ = v_isSharedCheck_31_;
goto v_resetjp_23_;
}
v_resetjp_23_:
{
lean_object* v___x_26_; lean_object* v___x_27_; lean_object* v___x_29_; 
lean_inc(v_toMul_14_);
v___x_26_ = lean_apply_2(v_toMul_14_, v_val_18_, v_val_21_);
v___x_27_ = lean_apply_2(v_toMul_14_, v_inv_22_, v_inv_19_);
if (v_isShared_25_ == 0)
{
lean_ctor_set(v___x_24_, 1, v___x_27_);
lean_ctor_set(v___x_24_, 0, v___x_26_);
v___x_29_ = v___x_24_;
goto v_reusejp_28_;
}
else
{
lean_object* v_reuseFailAlloc_30_; 
v_reuseFailAlloc_30_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_30_, 0, v___x_26_);
lean_ctor_set(v_reuseFailAlloc_30_, 1, v___x_27_);
v___x_29_ = v_reuseFailAlloc_30_;
goto v_reusejp_28_;
}
v_reusejp_28_:
{
return v___x_29_;
}
}
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_FrameSym_scale___redArg(lean_object* v_X_32_, lean_object* v_Y_33_, lean_object* v_L_34_, lean_object* v_inst_35_, lean_object* v_00_u03c6_36_, lean_object* v_00_u03b5_37_, lean_object* v_u_38_, lean_object* v_g_39_){
_start:
{
lean_object* v___x_40_; lean_object* v___f_41_; 
lean_inc_ref(v_Y_33_);
v___x_40_ = lp_tree_ReciprocityTheory_ChartRestriction_G_Semi_LB_LinComb___redArg(v_X_32_, v_Y_33_, v_L_34_, v_inst_35_, v_00_u03c6_36_, v_00_u03b5_37_);
v___f_41_ = lean_alloc_closure((void*)(lp_tree_GlobalTheory_FrameSym_scale___redArg___lam__0), 5, 4);
lean_closure_set(v___f_41_, 0, v_Y_33_);
lean_closure_set(v___f_41_, 1, v___x_40_);
lean_closure_set(v___f_41_, 2, v_u_38_);
lean_closure_set(v___f_41_, 3, v_g_39_);
return v___f_41_;
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_FrameSym_scale(lean_object* v_X_42_, lean_object* v_Y_43_, lean_object* v_L_44_, lean_object* v_K_45_, lean_object* v_inst_46_, lean_object* v_00_u03c6_47_, lean_object* v_00_u03b5_48_, lean_object* v_u_49_, lean_object* v_g_50_){
_start:
{
lean_object* v___x_51_; 
v___x_51_ = lp_tree_GlobalTheory_FrameSym_scale___redArg(v_X_42_, v_Y_43_, v_L_44_, v_inst_46_, v_00_u03c6_47_, v_00_u03b5_48_, v_u_49_, v_g_50_);
return v___x_51_;
}
}
lean_object* initialize_Init(uint8_t builtin);
lean_object* initialize_Init(uint8_t builtin);
lean_object* initialize_mathlib_Mathlib(uint8_t builtin);
lean_object* initialize_tree_Formalism_SharpRestriction_Divisibility_GeneratorPowers_GermCut(uint8_t builtin);
lean_object* initialize_tree_Formalism_SharpRestriction_Divisibility_GeneratorPowers_GermBGen(uint8_t builtin);
lean_object* initialize_tree_Formalism_SharpRestriction_Divisibility_GeneratorPowers_ChartPrimTrPfA(uint8_t builtin);
lean_object* initialize_tree_Formalism_SharpRestriction_Divisibility_GeneratorPowers_IntChartPf(uint8_t builtin);
lean_object* initialize_tree_Formalism_SharpRestriction_Divisibility_GeneratorPowers_ExistsTruncatedIntegralChart(uint8_t builtin);
lean_object* initialize_tree_Formalism_LocalToGlobal_ProjectiveLattices_PlaceBelow(uint8_t builtin);
lean_object* initialize_tree_ReciprocityTheory_ReductiveGroups_ArithmeticGeometry_ExtensionDescent_SecBaseChangeAnySt(uint8_t builtin);
static bool _G_initialized = false;
LEAN_EXPORT lean_object* initialize_tree_Development_AbelianVarietyTheory_Proofs_FormalGroupCharts_FrameSymmetryIffPullback(uint8_t builtin) {
lean_object * res;
if (_G_initialized) return lean_io_result_mk_ok(lean_box(0));
_G_initialized = true;
res = initialize_Init(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_Init(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_mathlib_Mathlib(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_Formalism_SharpRestriction_Divisibility_GeneratorPowers_GermCut(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_Formalism_SharpRestriction_Divisibility_GeneratorPowers_GermBGen(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_Formalism_SharpRestriction_Divisibility_GeneratorPowers_ChartPrimTrPfA(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_Formalism_SharpRestriction_Divisibility_GeneratorPowers_IntChartPf(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_Formalism_SharpRestriction_Divisibility_GeneratorPowers_ExistsTruncatedIntegralChart(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_Formalism_LocalToGlobal_ProjectiveLattices_PlaceBelow(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_ReciprocityTheory_ReductiveGroups_ArithmeticGeometry_ExtensionDescent_SecBaseChangeAnySt(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
return lean_io_result_mk_ok(lean_box(0));
}
#ifdef __cplusplus
}
#endif
