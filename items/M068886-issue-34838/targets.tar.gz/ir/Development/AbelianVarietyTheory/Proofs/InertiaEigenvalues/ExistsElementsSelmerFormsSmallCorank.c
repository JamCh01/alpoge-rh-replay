// Lean compiler output
// Module: Development.AbelianVarietyTheory.Proofs.InertiaEigenvalues.ExistsElementsSelmerFormsSmallCorank
// Imports: public import Init public meta import Init public import Mathlib public import Development.AbelianVarietyTheory.Definitions.NonGaloisDescent.IsDualDualRep public import Development.AbelianVarietyTheory.PublishedTheorems.GaloisCohomology₂.PoitouTateNineTermTransgressionZeroApply public import Development.AbelianVarietyTheory.PublishedTheorems.GaloisCohomology₂.CohDimTwoLocalOfLocalFiniteness public import Development.AbelianVarietyTheory.PublishedTheorems.GaloisCohomology₂.ContinuousCycMod public import Development.AbelianVarietyTheory.Proofs.InertiaEigenvalues.IsPlaceOverMoveValCc public import Development.AbelianVarietyTheory.Proofs.InertiaEigenvalues.ExistsAlternatingFormLeftCorankLeOneStatement public import Development.AbelianVarietyTheory.Proofs.InertiaEigenvalues.SemilinearCoefficientMapCocycles public import Development.AutomorphicArithmetic.CyclotomicBounds.CyclotomicOrders.ExistsCycZPowNeOne
#include <lean/lean.h>
#if defined(__clang__)
#pragma clang diagnostic ignored "-Wunused-parameter"
#pragma clang diagnostic ignored "-Wunused-label"
#elif defined(__GNUC__) && !defined(__CLANG__)
#pragma GCC diagnostic ignored "-Wunused-parameter"
#pragma GCC diagnostic ignored "-Wunused-label"
#pragma GCC diagnostic ignored "-Wunused-but-set-variable"
#endif
#ifdef __cplusplus
extern "C" {
#endif
lean_object* lp_mathlib_Field_toSemifield___redArg(lean_object*);
lean_object* lp_mathlib_Semifield_toDivisionSemiring___redArg(lean_object*);
lean_object* lp_mathlib_Field_toDivisionRing___redArg(lean_object*);
lean_object* lp_mathlib_Ring_toAddCommGroup___redArg(lean_object*);
lean_object* lp_mathlib_Semiring_toModule___redArg(lean_object*);
lean_object* lp_mathlib_Pi_Function_module___redArg(lean_object*);
lean_object* lp_mathlib_Pi_addCommGroup___redArg(lean_object*);
lean_object* lp_tree_ReciprocityTheory_Gal_mapH1___redArg(lean_object*, lean_object*, lean_object*, lean_object*);
lean_object* lp_tree_ReciprocityTheory_Gal_resH1___redArg(lean_object*, lean_object*, lean_object*, lean_object*);
lean_object* lp_mathlib_LinearMap_comp___redArg___lam__0(lean_object*, lean_object*, lean_object*);
lean_object* lp_mathlib_Ring_toAddGroupWithOne___redArg(lean_object*);
lean_object* lp_mathlib_AddGroupWithOne_toAddGroup___redArg(lean_object*);
lean_object* lp_mathlib_instDistribOfSemiring___redArg(lean_object*);
lean_object* l_List_finRange(lean_object*);
lean_object* lp_mathlib_dotProduct___redArg(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
lean_object* lp_tree_ReciprocityTheory_Gal_cocycles1MapOfEquivariant___redArg___lam__0(lean_object*, lean_object*, lean_object*);
lean_object* lp_tree_ReciprocityTheory_Gal_restrictCocycles1___redArg___lam__0(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_ChooseForms_fm___redArg(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_ChooseForms_fm(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_ChooseForms_fm___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_ChooseForms_kerOn(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_ChooseForms_kerOn___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_ChooseForms_twZ___redArg(lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_ChooseForms_twZ(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_ChooseForms_twZ___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_ChooseForms_twH___redArg___lam__0(lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_ChooseForms_twH___redArg___lam__0___boxed(lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_ChooseForms_twH___redArg(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_ChooseForms_twH(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_ChooseForms_twH___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_ChooseForms_mapC___redArg___lam__0(lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_ChooseForms_mapC___redArg(lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_ChooseForms_mapC(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_ChooseForms_mapC___boxed(lean_object**);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_ChooseForms_fm___redArg(lean_object* v_inst_1_, lean_object* v_r_2_, lean_object* v_cj_3_, lean_object* v_x_4_, lean_object* v_y_5_, lean_object* v_h_6_){
_start:
{
lean_object* v___x_7_; lean_object* v_toRing_8_; lean_object* v___x_9_; lean_object* v___x_10_; lean_object* v_toSub_11_; lean_object* v___x_12_; lean_object* v___x_13_; lean_object* v_toSemiring_14_; lean_object* v___x_15_; lean_object* v_toMul_16_; lean_object* v_toAddCommMonoid_17_; lean_object* v___x_18_; lean_object* v___x_19_; lean_object* v___x_20_; lean_object* v___x_21_; lean_object* v___x_22_; lean_object* v___x_23_; lean_object* v___x_24_; lean_object* v___x_25_; lean_object* v___x_26_; 
lean_inc_ref(v_inst_1_);
v___x_7_ = lp_mathlib_Field_toDivisionRing___redArg(v_inst_1_);
v_toRing_8_ = lean_ctor_get(v___x_7_, 0);
lean_inc_ref(v_toRing_8_);
lean_dec_ref(v___x_7_);
v___x_9_ = lp_mathlib_Ring_toAddGroupWithOne___redArg(v_toRing_8_);
v___x_10_ = lp_mathlib_AddGroupWithOne_toAddGroup___redArg(v___x_9_);
lean_dec_ref(v___x_9_);
v_toSub_11_ = lean_ctor_get(v___x_10_, 2);
lean_inc(v_toSub_11_);
lean_dec_ref(v___x_10_);
v___x_12_ = lp_mathlib_Field_toSemifield___redArg(v_inst_1_);
lean_dec_ref(v_inst_1_);
v___x_13_ = lp_mathlib_Semifield_toDivisionSemiring___redArg(v___x_12_);
v_toSemiring_14_ = lean_ctor_get(v___x_13_, 0);
lean_inc_ref_n(v_toSemiring_14_, 2);
lean_dec_ref(v___x_13_);
v___x_15_ = lp_mathlib_instDistribOfSemiring___redArg(v_toSemiring_14_);
v_toMul_16_ = lean_ctor_get(v___x_15_, 0);
lean_inc_n(v_toMul_16_, 2);
lean_dec_ref(v___x_15_);
v_toAddCommMonoid_17_ = lean_ctor_get(v_toSemiring_14_, 0);
lean_inc_ref(v_toAddCommMonoid_17_);
lean_dec_ref(v_toSemiring_14_);
v___x_18_ = l_List_finRange(v_r_2_);
lean_inc(v_x_4_);
lean_inc_n(v_h_6_, 2);
v___x_19_ = lean_apply_1(v_x_4_, v_h_6_);
lean_inc(v_y_5_);
v___x_20_ = lean_apply_1(v_y_5_, v_h_6_);
lean_inc(v___x_18_);
v___x_21_ = lp_mathlib_dotProduct___redArg(v___x_18_, v_toMul_16_, v_toAddCommMonoid_17_, v___x_19_, v___x_20_);
v___x_22_ = lean_apply_1(v_cj_3_, v_h_6_);
lean_inc(v___x_22_);
v___x_23_ = lean_apply_1(v_x_4_, v___x_22_);
v___x_24_ = lean_apply_1(v_y_5_, v___x_22_);
v___x_25_ = lp_mathlib_dotProduct___redArg(v___x_18_, v_toMul_16_, v_toAddCommMonoid_17_, v___x_23_, v___x_24_);
lean_dec_ref(v_toAddCommMonoid_17_);
v___x_26_ = lean_apply_2(v_toSub_11_, v___x_21_, v___x_25_);
return v___x_26_;
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_ChooseForms_fm(lean_object* v_K_27_, lean_object* v_inst_28_, lean_object* v_inst_29_, lean_object* v_inst_30_, lean_object* v_00_u0393_31_, lean_object* v_inst_32_, lean_object* v_inst_33_, lean_object* v_r_34_, lean_object* v_cj_35_, lean_object* v_00_u03c1_36_, lean_object* v_00_u03c1_x27_37_, lean_object* v_x_38_, lean_object* v_y_39_, lean_object* v_h_40_){
_start:
{
lean_object* v___x_41_; 
v___x_41_ = lp_tree_GlobalTheory_ChooseForms_fm___redArg(v_inst_28_, v_r_34_, v_cj_35_, v_x_38_, v_y_39_, v_h_40_);
return v___x_41_;
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_ChooseForms_fm___boxed(lean_object* v_K_42_, lean_object* v_inst_43_, lean_object* v_inst_44_, lean_object* v_inst_45_, lean_object* v_00_u0393_46_, lean_object* v_inst_47_, lean_object* v_inst_48_, lean_object* v_r_49_, lean_object* v_cj_50_, lean_object* v_00_u03c1_51_, lean_object* v_00_u03c1_x27_52_, lean_object* v_x_53_, lean_object* v_y_54_, lean_object* v_h_55_){
_start:
{
lean_object* v_res_56_; 
v_res_56_ = lp_tree_GlobalTheory_ChooseForms_fm(v_K_42_, v_inst_43_, v_inst_44_, v_inst_45_, v_00_u0393_46_, v_inst_47_, v_inst_48_, v_r_49_, v_cj_50_, v_00_u03c1_51_, v_00_u03c1_x27_52_, v_x_53_, v_y_54_, v_h_55_);
lean_dec(v_00_u03c1_x27_52_);
lean_dec(v_00_u03c1_51_);
lean_dec_ref(v_inst_47_);
return v_res_56_;
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_ChooseForms_kerOn(lean_object* v_K_57_, lean_object* v_inst_58_, lean_object* v_inst_59_, lean_object* v_inst_60_, lean_object* v_00_u0393_61_, lean_object* v_inst_62_, lean_object* v_inst_63_, lean_object* v_r_64_, lean_object* v_00_u03c1_65_, lean_object* v_L_66_, lean_object* v_hL_67_, lean_object* v_x_68_){
_start:
{
lean_object* v___x_69_; 
v___x_69_ = lean_box(0);
return v___x_69_;
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_ChooseForms_kerOn___boxed(lean_object* v_K_70_, lean_object* v_inst_71_, lean_object* v_inst_72_, lean_object* v_inst_73_, lean_object* v_00_u0393_74_, lean_object* v_inst_75_, lean_object* v_inst_76_, lean_object* v_r_77_, lean_object* v_00_u03c1_78_, lean_object* v_L_79_, lean_object* v_hL_80_, lean_object* v_x_81_){
_start:
{
lean_object* v_res_82_; 
v_res_82_ = lp_tree_GlobalTheory_ChooseForms_kerOn(v_K_70_, v_inst_71_, v_inst_72_, v_inst_73_, v_00_u0393_74_, v_inst_75_, v_inst_76_, v_r_77_, v_00_u03c1_78_, v_L_79_, v_hL_80_, v_x_81_);
lean_dec(v_x_81_);
lean_dec(v_00_u03c1_78_);
lean_dec(v_r_77_);
lean_dec_ref(v_inst_75_);
lean_dec_ref(v_inst_71_);
return v_res_82_;
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_ChooseForms_twZ___redArg(lean_object* v_cj_83_, lean_object* v_A_84_){
_start:
{
lean_object* v___f_85_; lean_object* v___f_86_; lean_object* v___f_87_; 
v___f_85_ = lean_alloc_closure((void*)(lp_tree_ReciprocityTheory_Gal_cocycles1MapOfEquivariant___redArg___lam__0), 3, 1);
lean_closure_set(v___f_85_, 0, v_A_84_);
v___f_86_ = lean_alloc_closure((void*)(lp_tree_ReciprocityTheory_Gal_restrictCocycles1___redArg___lam__0), 3, 1);
lean_closure_set(v___f_86_, 0, v_cj_83_);
v___f_87_ = lean_alloc_closure((void*)(lp_mathlib_LinearMap_comp___redArg___lam__0), 3, 2);
lean_closure_set(v___f_87_, 0, v___f_86_);
lean_closure_set(v___f_87_, 1, v___f_85_);
return v___f_87_;
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_ChooseForms_twZ(lean_object* v_K_88_, lean_object* v_inst_89_, lean_object* v_inst_90_, lean_object* v_inst_91_, lean_object* v_00_u0393_92_, lean_object* v_inst_93_, lean_object* v_inst_94_, lean_object* v_r_95_, lean_object* v_00_u03c1_96_, lean_object* v_00_u03c1_x27_97_, lean_object* v_cj_98_, lean_object* v_hcj_99_, lean_object* v_A_100_, lean_object* v_hA_101_){
_start:
{
lean_object* v___x_102_; 
v___x_102_ = lp_tree_GlobalTheory_ChooseForms_twZ___redArg(v_cj_98_, v_A_100_);
return v___x_102_;
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_ChooseForms_twZ___boxed(lean_object* v_K_103_, lean_object* v_inst_104_, lean_object* v_inst_105_, lean_object* v_inst_106_, lean_object* v_00_u0393_107_, lean_object* v_inst_108_, lean_object* v_inst_109_, lean_object* v_r_110_, lean_object* v_00_u03c1_111_, lean_object* v_00_u03c1_x27_112_, lean_object* v_cj_113_, lean_object* v_hcj_114_, lean_object* v_A_115_, lean_object* v_hA_116_){
_start:
{
lean_object* v_res_117_; 
v_res_117_ = lp_tree_GlobalTheory_ChooseForms_twZ(v_K_103_, v_inst_104_, v_inst_105_, v_inst_106_, v_00_u0393_107_, v_inst_108_, v_inst_109_, v_r_110_, v_00_u03c1_111_, v_00_u03c1_x27_112_, v_cj_113_, v_hcj_114_, v_A_115_, v_hA_116_);
lean_dec(v_00_u03c1_x27_112_);
lean_dec(v_00_u03c1_111_);
lean_dec(v_r_110_);
lean_dec_ref(v_inst_108_);
lean_dec_ref(v_inst_104_);
return v_res_117_;
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_ChooseForms_twH___redArg___lam__0(lean_object* v___x_118_, lean_object* v_i_119_){
_start:
{
lean_inc_ref(v___x_118_);
return v___x_118_;
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_ChooseForms_twH___redArg___lam__0___boxed(lean_object* v___x_120_, lean_object* v_i_121_){
_start:
{
lean_object* v_res_122_; 
v_res_122_ = lp_tree_GlobalTheory_ChooseForms_twH___redArg___lam__0(v___x_120_, v_i_121_);
lean_dec(v_i_121_);
lean_dec_ref(v___x_120_);
return v_res_122_;
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_ChooseForms_twH___redArg(lean_object* v_inst_123_, lean_object* v_cj_124_, lean_object* v_A_125_){
_start:
{
lean_object* v___x_126_; lean_object* v___x_127_; lean_object* v_toSemiring_128_; lean_object* v_toCommRing_129_; lean_object* v___x_130_; lean_object* v_toRing_131_; lean_object* v___x_132_; lean_object* v___f_133_; lean_object* v___x_134_; lean_object* v___x_135_; lean_object* v___x_136_; lean_object* v___x_137_; lean_object* v___x_138_; lean_object* v___f_139_; 
v___x_126_ = lp_mathlib_Field_toSemifield___redArg(v_inst_123_);
v___x_127_ = lp_mathlib_Semifield_toDivisionSemiring___redArg(v___x_126_);
v_toSemiring_128_ = lean_ctor_get(v___x_127_, 0);
lean_inc_ref(v_toSemiring_128_);
lean_dec_ref(v___x_127_);
v_toCommRing_129_ = lean_ctor_get(v_inst_123_, 0);
lean_inc_ref_n(v_toCommRing_129_, 2);
v___x_130_ = lp_mathlib_Field_toDivisionRing___redArg(v_inst_123_);
v_toRing_131_ = lean_ctor_get(v___x_130_, 0);
lean_inc_ref(v_toRing_131_);
lean_dec_ref(v___x_130_);
v___x_132_ = lp_mathlib_Ring_toAddCommGroup___redArg(v_toRing_131_);
lean_dec_ref(v_toRing_131_);
v___f_133_ = lean_alloc_closure((void*)(lp_tree_GlobalTheory_ChooseForms_twH___redArg___lam__0___boxed), 2, 1);
lean_closure_set(v___f_133_, 0, v___x_132_);
v___x_134_ = lp_mathlib_Semiring_toModule___redArg(v_toSemiring_128_);
lean_dec_ref(v_toSemiring_128_);
v___x_135_ = lp_mathlib_Pi_Function_module___redArg(v___x_134_);
v___x_136_ = lp_mathlib_Pi_addCommGroup___redArg(v___f_133_);
lean_inc(v___x_135_);
lean_inc_ref(v___x_136_);
v___x_137_ = lp_tree_ReciprocityTheory_Gal_mapH1___redArg(v_toCommRing_129_, v___x_136_, v___x_135_, v_A_125_);
v___x_138_ = lp_tree_ReciprocityTheory_Gal_resH1___redArg(v_toCommRing_129_, v___x_136_, v___x_135_, v_cj_124_);
v___f_139_ = lean_alloc_closure((void*)(lp_mathlib_LinearMap_comp___redArg___lam__0), 3, 2);
lean_closure_set(v___f_139_, 0, v___x_138_);
lean_closure_set(v___f_139_, 1, v___x_137_);
return v___f_139_;
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_ChooseForms_twH(lean_object* v_K_140_, lean_object* v_inst_141_, lean_object* v_inst_142_, lean_object* v_inst_143_, lean_object* v_00_u0393_144_, lean_object* v_inst_145_, lean_object* v_inst_146_, lean_object* v_r_147_, lean_object* v_00_u03c1_148_, lean_object* v_00_u03c1_x27_149_, lean_object* v_cj_150_, lean_object* v_hcj_151_, lean_object* v_A_152_, lean_object* v_hA_153_){
_start:
{
lean_object* v___x_154_; 
v___x_154_ = lp_tree_GlobalTheory_ChooseForms_twH___redArg(v_inst_141_, v_cj_150_, v_A_152_);
return v___x_154_;
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_ChooseForms_twH___boxed(lean_object* v_K_155_, lean_object* v_inst_156_, lean_object* v_inst_157_, lean_object* v_inst_158_, lean_object* v_00_u0393_159_, lean_object* v_inst_160_, lean_object* v_inst_161_, lean_object* v_r_162_, lean_object* v_00_u03c1_163_, lean_object* v_00_u03c1_x27_164_, lean_object* v_cj_165_, lean_object* v_hcj_166_, lean_object* v_A_167_, lean_object* v_hA_168_){
_start:
{
lean_object* v_res_169_; 
v_res_169_ = lp_tree_GlobalTheory_ChooseForms_twH(v_K_155_, v_inst_156_, v_inst_157_, v_inst_158_, v_00_u0393_159_, v_inst_160_, v_inst_161_, v_r_162_, v_00_u03c1_163_, v_00_u03c1_x27_164_, v_cj_165_, v_hcj_166_, v_A_167_, v_hA_168_);
lean_dec(v_00_u03c1_x27_164_);
lean_dec(v_00_u03c1_163_);
lean_dec(v_r_162_);
lean_dec_ref(v_inst_160_);
return v_res_169_;
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_ChooseForms_mapC___redArg___lam__0(lean_object* v_x_170_, lean_object* v_f_171_, lean_object* v_g_172_, lean_object* v_a_173_){
_start:
{
lean_object* v___x_174_; lean_object* v___x_175_; 
v___x_174_ = lean_apply_2(v_x_170_, v_g_172_, v_a_173_);
v___x_175_ = lean_apply_1(v_f_171_, v___x_174_);
return v___x_175_;
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_ChooseForms_mapC___redArg(lean_object* v_f_176_, lean_object* v_x_177_){
_start:
{
lean_object* v___f_178_; 
v___f_178_ = lean_alloc_closure((void*)(lp_tree_GlobalTheory_ChooseForms_mapC___redArg___lam__0), 4, 2);
lean_closure_set(v___f_178_, 0, v_x_177_);
lean_closure_set(v___f_178_, 1, v_f_176_);
return v___f_178_;
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_ChooseForms_mapC(lean_object* v_D_179_, lean_object* v_N_180_, lean_object* v_X_181_, lean_object* v_i_182_, lean_object* v_K_183_, lean_object* v_K_x27_184_, lean_object* v_inst_185_, lean_object* v_inst_186_, lean_object* v_inst_187_, lean_object* v_inst_188_, lean_object* v_inst_189_, lean_object* v_inst_190_, lean_object* v_inst_191_, lean_object* v_inst_192_, lean_object* v_f_193_, lean_object* v_00_u03c1_194_, lean_object* v_x_195_){
_start:
{
lean_object* v___f_196_; 
v___f_196_ = lean_alloc_closure((void*)(lp_tree_GlobalTheory_ChooseForms_mapC___redArg___lam__0), 4, 2);
lean_closure_set(v___f_196_, 0, v_x_195_);
lean_closure_set(v___f_196_, 1, v_f_193_);
return v___f_196_;
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_ChooseForms_mapC___boxed(lean_object** _args){
lean_object* v_D_197_ = _args[0];
lean_object* v_N_198_ = _args[1];
lean_object* v_X_199_ = _args[2];
lean_object* v_i_200_ = _args[3];
lean_object* v_K_201_ = _args[4];
lean_object* v_K_x27_202_ = _args[5];
lean_object* v_inst_203_ = _args[6];
lean_object* v_inst_204_ = _args[7];
lean_object* v_inst_205_ = _args[8];
lean_object* v_inst_206_ = _args[9];
lean_object* v_inst_207_ = _args[10];
lean_object* v_inst_208_ = _args[11];
lean_object* v_inst_209_ = _args[12];
lean_object* v_inst_210_ = _args[13];
lean_object* v_f_211_ = _args[14];
lean_object* v_00_u03c1_212_ = _args[15];
lean_object* v_x_213_ = _args[16];
_start:
{
lean_object* v_res_214_; 
v_res_214_ = lp_tree_GlobalTheory_ChooseForms_mapC(v_D_197_, v_N_198_, v_X_199_, v_i_200_, v_K_201_, v_K_x27_202_, v_inst_203_, v_inst_204_, v_inst_205_, v_inst_206_, v_inst_207_, v_inst_208_, v_inst_209_, v_inst_210_, v_f_211_, v_00_u03c1_212_, v_x_213_);
lean_dec_ref(v_00_u03c1_212_);
lean_dec_ref(v_inst_208_);
lean_dec_ref(v_inst_207_);
lean_dec_ref(v_inst_204_);
lean_dec_ref(v_inst_203_);
lean_dec(v_i_200_);
lean_dec_ref(v_X_199_);
lean_dec_ref(v_N_198_);
lean_dec_ref(v_D_197_);
return v_res_214_;
}
}
lean_object* initialize_Init(uint8_t builtin);
lean_object* initialize_Init(uint8_t builtin);
lean_object* initialize_mathlib_Mathlib(uint8_t builtin);
lean_object* initialize_tree_Development_AbelianVarietyTheory_Definitions_NonGaloisDescent_IsDualDualRep(uint8_t builtin);
lean_object* initialize_tree_Development_AbelianVarietyTheory_PublishedTheorems_GaloisCohomology_u2082_PoitouTateNineTermTransgressionZeroApply(uint8_t builtin);
lean_object* initialize_tree_Development_AbelianVarietyTheory_PublishedTheorems_GaloisCohomology_u2082_CohDimTwoLocalOfLocalFiniteness(uint8_t builtin);
lean_object* initialize_tree_Development_AbelianVarietyTheory_PublishedTheorems_GaloisCohomology_u2082_ContinuousCycMod(uint8_t builtin);
lean_object* initialize_tree_Development_AbelianVarietyTheory_Proofs_InertiaEigenvalues_IsPlaceOverMoveValCc(uint8_t builtin);
lean_object* initialize_tree_Development_AbelianVarietyTheory_Proofs_InertiaEigenvalues_ExistsAlternatingFormLeftCorankLeOneStatement(uint8_t builtin);
lean_object* initialize_tree_Development_AbelianVarietyTheory_Proofs_InertiaEigenvalues_SemilinearCoefficientMapCocycles(uint8_t builtin);
lean_object* initialize_tree_Development_AutomorphicArithmetic_CyclotomicBounds_CyclotomicOrders_ExistsCycZPowNeOne(uint8_t builtin);
static bool _G_initialized = false;
LEAN_EXPORT lean_object* initialize_tree_Development_AbelianVarietyTheory_Proofs_InertiaEigenvalues_ExistsElementsSelmerFormsSmallCorank(uint8_t builtin) {
lean_object * res;
if (_G_initialized) return lean_io_result_mk_ok(lean_box(0));
_G_initialized = true;
res = initialize_Init(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_Init(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_mathlib_Mathlib(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_Development_AbelianVarietyTheory_Definitions_NonGaloisDescent_IsDualDualRep(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_Development_AbelianVarietyTheory_PublishedTheorems_GaloisCohomology_u2082_PoitouTateNineTermTransgressionZeroApply(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_Development_AbelianVarietyTheory_PublishedTheorems_GaloisCohomology_u2082_CohDimTwoLocalOfLocalFiniteness(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_Development_AbelianVarietyTheory_PublishedTheorems_GaloisCohomology_u2082_ContinuousCycMod(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_Development_AbelianVarietyTheory_Proofs_InertiaEigenvalues_IsPlaceOverMoveValCc(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_Development_AbelianVarietyTheory_Proofs_InertiaEigenvalues_ExistsAlternatingFormLeftCorankLeOneStatement(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_Development_AbelianVarietyTheory_Proofs_InertiaEigenvalues_SemilinearCoefficientMapCocycles(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_Development_AutomorphicArithmetic_CyclotomicBounds_CyclotomicOrders_ExistsCycZPowNeOne(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
return lean_io_result_mk_ok(lean_box(0));
}
#ifdef __cplusplus
}
#endif
