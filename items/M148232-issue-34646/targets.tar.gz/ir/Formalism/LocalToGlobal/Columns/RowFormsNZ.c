// Lean compiler output
// Module: Formalism.LocalToGlobal.Columns.RowFormsNZ
// Imports: public import Init public meta import Init public import Mathlib public import Formalism.LocalToGlobal.Columns.RowFormsRank public import Formalism.LocalToGlobal.Columns.RowFormsNZs public import Formalism.LocalToGlobal.Columns.RowFormsNZc public import Formalism.LocalToGlobal.Columns.RowFormsNZw
#include <lean/lean.h>
#if defined(__clang__)
#pragma clang diagnostic ignored "-Wunused-parameter"
#pragma clang diagnostic ignored "-Wunused-label"
#elif defined(__GNUC__) && !defined(__CLANG__)
#pragma GCC diagnostic ignored "-Wunused-parameter"
#pragma GCC diagnostic ignored "-Wunused-label"
#pragma GCC diagnostic ignored "-Wunused-but-set-variable"
#endif
#ifdef __cplusplus
extern "C" {
#endif
lean_object* lp_mathlib_Ring_toNonAssocRing___redArg(lean_object*);
lean_object* lp_mathlib_Int_castRingHom___redArg(lean_object*);
lean_object* lp_mathlib_Units_map___redArg___lam__0(lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_Formalism_L2_Col_sgnU___redArg(lean_object*);
LEAN_EXPORT lean_object* lp_tree_Formalism_L2_Col_sgnU___redArg___boxed(lean_object*);
LEAN_EXPORT lean_object* lp_tree_Formalism_L2_Col_sgnU(lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_Formalism_L2_Col_sgnU___boxed(lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_Formalism_L2_Col_sgnU___redArg(lean_object* v_inst_1_){
_start:
{
lean_object* v___x_2_; lean_object* v___x_3_; lean_object* v___f_4_; 
v___x_2_ = lp_mathlib_Ring_toNonAssocRing___redArg(v_inst_1_);
v___x_3_ = lp_mathlib_Int_castRingHom___redArg(v___x_2_);
v___f_4_ = lean_alloc_closure((void*)(lp_mathlib_Units_map___redArg___lam__0), 2, 1);
lean_closure_set(v___f_4_, 0, v___x_3_);
return v___f_4_;
}
}
LEAN_EXPORT lean_object* lp_tree_Formalism_L2_Col_sgnU___redArg___boxed(lean_object* v_inst_5_){
_start:
{
lean_object* v_res_6_; 
v_res_6_ = lp_tree_Formalism_L2_Col_sgnU___redArg(v_inst_5_);
lean_dec_ref(v_inst_5_);
return v_res_6_;
}
}
LEAN_EXPORT lean_object* lp_tree_Formalism_L2_Col_sgnU(lean_object* v_00_u03ba_7_, lean_object* v_inst_8_){
_start:
{
lean_object* v___x_9_; 
v___x_9_ = lp_tree_Formalism_L2_Col_sgnU___redArg(v_inst_8_);
return v___x_9_;
}
}
LEAN_EXPORT lean_object* lp_tree_Formalism_L2_Col_sgnU___boxed(lean_object* v_00_u03ba_10_, lean_object* v_inst_11_){
_start:
{
lean_object* v_res_12_; 
v_res_12_ = lp_tree_Formalism_L2_Col_sgnU(v_00_u03ba_10_, v_inst_11_);
lean_dec_ref(v_inst_11_);
return v_res_12_;
}
}
lean_object* initialize_Init(uint8_t builtin);
lean_object* initialize_Init(uint8_t builtin);
lean_object* initialize_mathlib_Mathlib(uint8_t builtin);
lean_object* initialize_tree_Formalism_LocalToGlobal_Columns_RowFormsRank(uint8_t builtin);
lean_object* initialize_tree_Formalism_LocalToGlobal_Columns_RowFormsNZs(uint8_t builtin);
lean_object* initialize_tree_Formalism_LocalToGlobal_Columns_RowFormsNZc(uint8_t builtin);
lean_object* initialize_tree_Formalism_LocalToGlobal_Columns_RowFormsNZw(uint8_t builtin);
static bool _G_initialized = false;
LEAN_EXPORT lean_object* initialize_tree_Formalism_LocalToGlobal_Columns_RowFormsNZ(uint8_t builtin) {
lean_object * res;
if (_G_initialized) return lean_io_result_mk_ok(lean_box(0));
_G_initialized = true;
res = initialize_Init(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_Init(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_mathlib_Mathlib(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_Formalism_LocalToGlobal_Columns_RowFormsRank(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_Formalism_LocalToGlobal_Columns_RowFormsNZs(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_Formalism_LocalToGlobal_Columns_RowFormsNZc(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_Formalism_LocalToGlobal_Columns_RowFormsNZw(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
return lean_io_result_mk_ok(lean_box(0));
}
#ifdef __cplusplus
}
#endif
