// Lean compiler output
// Module: Development.AbelianVarietyTheory.Proofs.InertiaEigenvalues.JumpsOverLettersOfCrysWith
// Imports: public import Init public meta import Init public import Mathlib public import Development.AbelianVarietyTheory.Definitions.NonGaloisDescent.Saturated public import Development.AbelianVarietyTheory.BlockTheory.NonGaloisCusps.LettersFreeOfRank public import Development.AbelianVarietyTheory.BlockTheory.NonGaloisCusps.PointRingCommRing public import Development.AbelianVarietyTheory.BlockTheory.NonGaloisCusps.WachModuleUniqueness public import Formalism.LocalRingCardinality.AdicCompletionLocal.LocTied public import Development.AbelianVarietyTheory.Proofs.InertiaEigenvalues.JumpIffMultNeZero
#include <lean/lean.h>
#if defined(__clang__)
#pragma clang diagnostic ignored "-Wunused-parameter"
#pragma clang diagnostic ignored "-Wunused-label"
#elif defined(__GNUC__) && !defined(__CLANG__)
#pragma GCC diagnostic ignored "-Wunused-parameter"
#pragma GCC diagnostic ignored "-Wunused-label"
#pragma GCC diagnostic ignored "-Wunused-but-set-variable"
#endif
#ifdef __cplusplus
extern "C" {
#endif
lean_object* initialize_Init(uint8_t builtin);
lean_object* initialize_Init(uint8_t builtin);
lean_object* initialize_mathlib_Mathlib(uint8_t builtin);
lean_object* initialize_tree_Development_AbelianVarietyTheory_Definitions_NonGaloisDescent_Saturated(uint8_t builtin);
lean_object* initialize_tree_Development_AbelianVarietyTheory_BlockTheory_NonGaloisCusps_LettersFreeOfRank(uint8_t builtin);
lean_object* initialize_tree_Development_AbelianVarietyTheory_BlockTheory_NonGaloisCusps_PointRingCommRing(uint8_t builtin);
lean_object* initialize_tree_Development_AbelianVarietyTheory_BlockTheory_NonGaloisCusps_WachModuleUniqueness(uint8_t builtin);
lean_object* initialize_tree_Formalism_LocalRingCardinality_AdicCompletionLocal_LocTied(uint8_t builtin);
lean_object* initialize_tree_Development_AbelianVarietyTheory_Proofs_InertiaEigenvalues_JumpIffMultNeZero(uint8_t builtin);
static bool _G_initialized = false;
LEAN_EXPORT lean_object* initialize_tree_Development_AbelianVarietyTheory_Proofs_InertiaEigenvalues_JumpsOverLettersOfCrysWith(uint8_t builtin) {
lean_object * res;
if (_G_initialized) return lean_io_result_mk_ok(lean_box(0));
_G_initialized = true;
res = initialize_Init(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_Init(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_mathlib_Mathlib(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_Development_AbelianVarietyTheory_Definitions_NonGaloisDescent_Saturated(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_Development_AbelianVarietyTheory_BlockTheory_NonGaloisCusps_LettersFreeOfRank(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_Development_AbelianVarietyTheory_BlockTheory_NonGaloisCusps_PointRingCommRing(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_Development_AbelianVarietyTheory_BlockTheory_NonGaloisCusps_WachModuleUniqueness(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_Formalism_LocalRingCardinality_AdicCompletionLocal_LocTied(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_Development_AbelianVarietyTheory_Proofs_InertiaEigenvalues_JumpIffMultNeZero(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
return lean_io_result_mk_ok(lean_box(0));
}
#ifdef __cplusplus
}
#endif
