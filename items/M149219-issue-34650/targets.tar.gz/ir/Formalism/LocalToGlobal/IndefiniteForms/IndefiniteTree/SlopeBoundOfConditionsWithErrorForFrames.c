// Lean compiler output
// Module: Formalism.LocalToGlobal.IndefiniteForms.IndefiniteTree.SlopeBoundOfConditionsWithErrorForFrames
// Imports: public import Init public meta import Init public import Mathlib public import Formalism.LocalToGlobal.IndefiniteForms.IndefiniteTree.SlopeBoundSingleLiftOfDefinitions
#include <lean/lean.h>
#if defined(__clang__)
#pragma clang diagnostic ignored "-Wunused-parameter"
#pragma clang diagnostic ignored "-Wunused-label"
#elif defined(__GNUC__) && !defined(__CLANG__)
#pragma GCC diagnostic ignored "-Wunused-parameter"
#pragma GCC diagnostic ignored "-Wunused-label"
#pragma GCC diagnostic ignored "-Wunused-but-set-variable"
#endif
#ifdef __cplusplus
extern "C" {
#endif
extern lean_object* lp_mathlib_Real_definition_00___x40_Mathlib_Data_Real_Basic_1279875089____hygCtx___hyg_8_;
extern lean_object* lp_mathlib_Real_definition_00___x40_Mathlib_Data_Real_Basic_1850581184____hygCtx___hyg_8_;
lean_object* lp_mathlib_AddMonoid_toAddZeroClass___redArg(lean_object*);
lean_object* lp_mathlib_Complex_ofReal(lean_object*);
extern lean_object* lp_mathlib_Complex_instZero;
lean_object* l_instDecidableEqFin___boxed(lean_object*, lean_object*, lean_object*);
lean_object* lp_mathlib_Matrix_diagonal___redArg(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
lean_object* lp_mathlib_Nat_cast___at___00Nat_cast___at___00Nat_cast___at___00Nat_cast___at___00__private_Mathlib_NumberTheory_ModularForms_EisensteinSeries_E2_Transform_0__EisensteinSeries_00_u03b4_spec__0_spec__0_spec__2_spec__3(lean_object*);
lean_object* lp_mathlib_Field_toSemifield___redArg(lean_object*);
lean_object* lp_mathlib_Semifield_toDivisionSemiring___redArg(lean_object*);
extern lean_object* lp_mathlib_PUnit_fintype;
extern lean_object* lp_mathlib_Real_instNatCast;
lean_object* lp_tree_Formalism_L2_Indef_Tree_slopeBoundConstant(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
lean_object* lp_mathlib_Real_definition___lam__0_00___x40_Mathlib_Data_Real_Basic_4214226450____hygCtx___hyg_8_(lean_object*, lean_object*, lean_object*);
lean_object* lp_mathlib_Real_definition___lam__0_00___x40_Mathlib_Data_Real_Basic_1138242547____hygCtx___hyg_8_(lean_object*, lean_object*, lean_object*);
static lean_once_cell_t lp_tree_Formalism_L2_Indef_Tree_slopeBoundConstantWithError___closed__0_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* lp_tree_Formalism_L2_Indef_Tree_slopeBoundConstantWithError___closed__0;
LEAN_EXPORT lean_object* lp_tree_Formalism_L2_Indef_Tree_slopeBoundConstantWithError(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_Formalism_L2_Indef_Tree_exampleFac4___redArg___lam__0(lean_object*);
LEAN_EXPORT lean_object* lp_tree_Formalism_L2_Indef_Tree_exampleFac4___redArg___lam__1(lean_object*);
static lean_once_cell_t lp_tree_Formalism_L2_Indef_Tree_exampleFac4___redArg___lam__2___closed__0_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* lp_tree_Formalism_L2_Indef_Tree_exampleFac4___redArg___lam__2___closed__0;
LEAN_EXPORT lean_object* lp_tree_Formalism_L2_Indef_Tree_exampleFac4___redArg___lam__2(lean_object*);
LEAN_EXPORT lean_object* lp_tree_Formalism_L2_Indef_Tree_exampleFac4___redArg___lam__2___boxed(lean_object*);
LEAN_EXPORT lean_object* lp_tree_Formalism_L2_Indef_Tree_exampleFac4___redArg___lam__3(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_Formalism_L2_Indef_Tree_exampleFac4___redArg___lam__3___boxed(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_Formalism_L2_Indef_Tree_exampleFac4___redArg___lam__4(lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_Formalism_L2_Indef_Tree_exampleFac4___redArg___lam__4___boxed(lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_Formalism_L2_Indef_Tree_exampleFac4___redArg___lam__6(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_Formalism_L2_Indef_Tree_exampleFac4___redArg___lam__6___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
static const lean_closure_object lp_tree_Formalism_L2_Indef_Tree_exampleFac4___redArg___closed__0_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_closure_object) + sizeof(void*)*0, .m_other = 0, .m_tag = 245}, .m_fun = (void*)lp_tree_Formalism_L2_Indef_Tree_exampleFac4___redArg___lam__0, .m_arity = 1, .m_num_fixed = 0, .m_objs = {} };
static const lean_object* lp_tree_Formalism_L2_Indef_Tree_exampleFac4___redArg___closed__0 = (const lean_object*)&lp_tree_Formalism_L2_Indef_Tree_exampleFac4___redArg___closed__0_value;
static const lean_closure_object lp_tree_Formalism_L2_Indef_Tree_exampleFac4___redArg___closed__1_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_closure_object) + sizeof(void*)*0, .m_other = 0, .m_tag = 245}, .m_fun = (void*)lp_tree_Formalism_L2_Indef_Tree_exampleFac4___redArg___lam__1, .m_arity = 1, .m_num_fixed = 0, .m_objs = {} };
static const lean_object* lp_tree_Formalism_L2_Indef_Tree_exampleFac4___redArg___closed__1 = (const lean_object*)&lp_tree_Formalism_L2_Indef_Tree_exampleFac4___redArg___closed__1_value;
static const lean_closure_object lp_tree_Formalism_L2_Indef_Tree_exampleFac4___redArg___closed__2_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_closure_object) + sizeof(void*)*0, .m_other = 0, .m_tag = 245}, .m_fun = (void*)lp_tree_Formalism_L2_Indef_Tree_exampleFac4___redArg___lam__2___boxed, .m_arity = 1, .m_num_fixed = 0, .m_objs = {} };
static const lean_object* lp_tree_Formalism_L2_Indef_Tree_exampleFac4___redArg___closed__2 = (const lean_object*)&lp_tree_Formalism_L2_Indef_Tree_exampleFac4___redArg___closed__2_value;
static lean_once_cell_t lp_tree_Formalism_L2_Indef_Tree_exampleFac4___redArg___closed__3_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* lp_tree_Formalism_L2_Indef_Tree_exampleFac4___redArg___closed__3;
static lean_once_cell_t lp_tree_Formalism_L2_Indef_Tree_exampleFac4___redArg___closed__4_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* lp_tree_Formalism_L2_Indef_Tree_exampleFac4___redArg___closed__4;
static lean_once_cell_t lp_tree_Formalism_L2_Indef_Tree_exampleFac4___redArg___closed__5_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* lp_tree_Formalism_L2_Indef_Tree_exampleFac4___redArg___closed__5;
LEAN_EXPORT lean_object* lp_tree_Formalism_L2_Indef_Tree_exampleFac4___redArg(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_Formalism_L2_Indef_Tree_exampleFac4___redArg___boxed(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_Formalism_L2_Indef_Tree_exampleFac4(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_Formalism_L2_Indef_Tree_exampleFac4___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
static lean_object* _init_lp_tree_Formalism_L2_Indef_Tree_slopeBoundConstantWithError___closed__0(void){
_start:
{
lean_object* v___x_1_; lean_object* v___x_2_; 
v___x_1_ = lean_unsigned_to_nat(16u);
v___x_2_ = lp_mathlib_Nat_cast___at___00Nat_cast___at___00Nat_cast___at___00Nat_cast___at___00__private_Mathlib_NumberTheory_ModularForms_EisensteinSeries_E2_Transform_0__EisensteinSeries_00_u03b4_spec__0_spec__0_spec__2_spec__3(v___x_1_);
return v___x_2_;
}
}
LEAN_EXPORT lean_object* lp_tree_Formalism_L2_Indef_Tree_slopeBoundConstantWithError(lean_object* v_Ca_3_, lean_object* v_Cb_4_, lean_object* v_Cf_5_, lean_object* v_Cc_6_, lean_object* v_C1_7_, lean_object* v_Cm_8_, lean_object* v_C2_9_){
_start:
{
lean_object* v___x_10_; lean_object* v___x_11_; lean_object* v___f_12_; lean_object* v___f_13_; 
v___x_10_ = lp_tree_Formalism_L2_Indef_Tree_slopeBoundConstant(v_Ca_3_, v_Cb_4_, v_Cf_5_, v_Cc_6_, v_C1_7_, v_Cm_8_);
v___x_11_ = lean_obj_once(&lp_tree_Formalism_L2_Indef_Tree_slopeBoundConstantWithError___closed__0, &lp_tree_Formalism_L2_Indef_Tree_slopeBoundConstantWithError___closed__0_once, _init_lp_tree_Formalism_L2_Indef_Tree_slopeBoundConstantWithError___closed__0);
v___f_12_ = lean_alloc_closure((void*)(lp_mathlib_Real_definition___lam__0_00___x40_Mathlib_Data_Real_Basic_4214226450____hygCtx___hyg_8_), 3, 2);
lean_closure_set(v___f_12_, 0, v___x_11_);
lean_closure_set(v___f_12_, 1, v_C2_9_);
v___f_13_ = lean_alloc_closure((void*)(lp_mathlib_Real_definition___lam__0_00___x40_Mathlib_Data_Real_Basic_1138242547____hygCtx___hyg_8_), 3, 2);
lean_closure_set(v___f_13_, 0, v___x_10_);
lean_closure_set(v___f_13_, 1, v___f_12_);
return v___f_13_;
}
}
LEAN_EXPORT lean_object* lp_tree_Formalism_L2_Indef_Tree_exampleFac4___redArg___lam__0(lean_object* v_x_14_){
_start:
{
lean_object* v___x_15_; 
v___x_15_ = lp_mathlib_Real_definition_00___x40_Mathlib_Data_Real_Basic_1850581184____hygCtx___hyg_8_;
return v___x_15_;
}
}
LEAN_EXPORT lean_object* lp_tree_Formalism_L2_Indef_Tree_exampleFac4___redArg___lam__1(lean_object* v_x_16_){
_start:
{
lean_object* v___x_17_; 
v___x_17_ = lp_mathlib_Real_definition_00___x40_Mathlib_Data_Real_Basic_1279875089____hygCtx___hyg_8_;
return v___x_17_;
}
}
static lean_object* _init_lp_tree_Formalism_L2_Indef_Tree_exampleFac4___redArg___lam__2___closed__0(void){
_start:
{
lean_object* v___x_18_; lean_object* v___x_19_; 
v___x_18_ = lp_mathlib_Real_definition_00___x40_Mathlib_Data_Real_Basic_1279875089____hygCtx___hyg_8_;
v___x_19_ = lp_mathlib_Complex_ofReal(v___x_18_);
return v___x_19_;
}
}
LEAN_EXPORT lean_object* lp_tree_Formalism_L2_Indef_Tree_exampleFac4___redArg___lam__2(lean_object* v_x_20_){
_start:
{
lean_object* v___x_21_; 
v___x_21_ = lean_obj_once(&lp_tree_Formalism_L2_Indef_Tree_exampleFac4___redArg___lam__2___closed__0, &lp_tree_Formalism_L2_Indef_Tree_exampleFac4___redArg___lam__2___closed__0_once, _init_lp_tree_Formalism_L2_Indef_Tree_exampleFac4___redArg___lam__2___closed__0);
return v___x_21_;
}
}
LEAN_EXPORT lean_object* lp_tree_Formalism_L2_Indef_Tree_exampleFac4___redArg___lam__2___boxed(lean_object* v_x_22_){
_start:
{
lean_object* v_res_23_; 
v_res_23_ = lp_tree_Formalism_L2_Indef_Tree_exampleFac4___redArg___lam__2(v_x_22_);
lean_dec(v_x_22_);
return v_res_23_;
}
}
LEAN_EXPORT lean_object* lp_tree_Formalism_L2_Indef_Tree_exampleFac4___redArg___lam__3(lean_object* v_toAddCommMonoid_24_, lean_object* v_x_25_, lean_object* v___y_26_){
_start:
{
lean_object* v___x_27_; lean_object* v_toZero_28_; 
v___x_27_ = lp_mathlib_AddMonoid_toAddZeroClass___redArg(v_toAddCommMonoid_24_);
v_toZero_28_ = lean_ctor_get(v___x_27_, 0);
lean_inc(v_toZero_28_);
lean_dec_ref(v___x_27_);
return v_toZero_28_;
}
}
LEAN_EXPORT lean_object* lp_tree_Formalism_L2_Indef_Tree_exampleFac4___redArg___lam__3___boxed(lean_object* v_toAddCommMonoid_29_, lean_object* v_x_30_, lean_object* v___y_31_){
_start:
{
lean_object* v_res_32_; 
v_res_32_ = lp_tree_Formalism_L2_Indef_Tree_exampleFac4___redArg___lam__3(v_toAddCommMonoid_29_, v_x_30_, v___y_31_);
lean_dec(v___y_31_);
lean_dec(v_x_30_);
lean_dec_ref(v_toAddCommMonoid_29_);
return v_res_32_;
}
}
LEAN_EXPORT lean_object* lp_tree_Formalism_L2_Indef_Tree_exampleFac4___redArg___lam__4(lean_object* v___x_33_, lean_object* v_x_34_){
_start:
{
lean_inc(v___x_33_);
return v___x_33_;
}
}
LEAN_EXPORT lean_object* lp_tree_Formalism_L2_Indef_Tree_exampleFac4___redArg___lam__4___boxed(lean_object* v___x_35_, lean_object* v_x_36_){
_start:
{
lean_object* v_res_37_; 
v_res_37_ = lp_tree_Formalism_L2_Indef_Tree_exampleFac4___redArg___lam__4(v___x_35_, v_x_36_);
lean_dec(v___x_35_);
return v_res_37_;
}
}
LEAN_EXPORT lean_object* lp_tree_Formalism_L2_Indef_Tree_exampleFac4___redArg___lam__6(lean_object* v___x_38_, lean_object* v___x_39_, lean_object* v___f_40_, lean_object* v_x_41_, lean_object* v___y_42_, lean_object* v___y_43_){
_start:
{
lean_object* v___x_44_; lean_object* v___x_45_; 
v___x_44_ = lean_alloc_closure((void*)(l_instDecidableEqFin___boxed), 3, 1);
lean_closure_set(v___x_44_, 0, v___x_38_);
v___x_45_ = lp_mathlib_Matrix_diagonal___redArg(v___x_44_, v___x_39_, v___f_40_, v___y_42_, v___y_43_);
return v___x_45_;
}
}
LEAN_EXPORT lean_object* lp_tree_Formalism_L2_Indef_Tree_exampleFac4___redArg___lam__6___boxed(lean_object* v___x_46_, lean_object* v___x_47_, lean_object* v___f_48_, lean_object* v_x_49_, lean_object* v___y_50_, lean_object* v___y_51_){
_start:
{
lean_object* v_res_52_; 
v_res_52_ = lp_tree_Formalism_L2_Indef_Tree_exampleFac4___redArg___lam__6(v___x_46_, v___x_47_, v___f_48_, v_x_49_, v___y_50_, v___y_51_);
lean_dec(v_x_49_);
return v_res_52_;
}
}
static lean_object* _init_lp_tree_Formalism_L2_Indef_Tree_exampleFac4___redArg___closed__3(void){
_start:
{
lean_object* v___x_56_; lean_object* v___f_57_; 
v___x_56_ = lp_mathlib_Real_definition_00___x40_Mathlib_Data_Real_Basic_1279875089____hygCtx___hyg_8_;
v___f_57_ = lean_alloc_closure((void*)(lp_tree_Formalism_L2_Indef_Tree_exampleFac4___redArg___lam__4___boxed), 2, 1);
lean_closure_set(v___f_57_, 0, v___x_56_);
return v___f_57_;
}
}
static lean_object* _init_lp_tree_Formalism_L2_Indef_Tree_exampleFac4___redArg___closed__4(void){
_start:
{
lean_object* v___x_58_; lean_object* v___f_59_; 
v___x_58_ = lp_mathlib_Real_definition_00___x40_Mathlib_Data_Real_Basic_1850581184____hygCtx___hyg_8_;
v___f_59_ = lean_alloc_closure((void*)(lp_tree_Formalism_L2_Indef_Tree_exampleFac4___redArg___lam__4___boxed), 2, 1);
lean_closure_set(v___f_59_, 0, v___x_58_);
return v___f_59_;
}
}
static lean_object* _init_lp_tree_Formalism_L2_Indef_Tree_exampleFac4___redArg___closed__5(void){
_start:
{
lean_object* v___f_60_; lean_object* v___x_61_; lean_object* v___x_62_; lean_object* v___f_63_; 
v___f_60_ = ((lean_object*)(lp_tree_Formalism_L2_Indef_Tree_exampleFac4___redArg___closed__2));
v___x_61_ = lp_mathlib_Complex_instZero;
v___x_62_ = lean_unsigned_to_nat(0u);
v___f_63_ = lean_alloc_closure((void*)(lp_tree_Formalism_L2_Indef_Tree_exampleFac4___redArg___lam__6___boxed), 6, 3);
lean_closure_set(v___f_63_, 0, v___x_62_);
lean_closure_set(v___f_63_, 1, v___x_61_);
lean_closure_set(v___f_63_, 2, v___f_60_);
return v___f_63_;
}
}
LEAN_EXPORT lean_object* lp_tree_Formalism_L2_Indef_Tree_exampleFac4___redArg(lean_object* v_inst_64_, lean_object* v_cc_65_, lean_object* v_R1_66_){
_start:
{
lean_object* v___x_67_; lean_object* v___x_68_; lean_object* v_toSemiring_69_; lean_object* v_toAddCommMonoid_70_; lean_object* v___f_71_; lean_object* v___f_72_; lean_object* v___x_73_; lean_object* v___f_74_; lean_object* v___x_75_; lean_object* v___f_76_; lean_object* v___x_77_; lean_object* v___x_78_; lean_object* v___x_290__overap_79_; lean_object* v___x_80_; lean_object* v___x_81_; lean_object* v___f_82_; lean_object* v___x_83_; lean_object* v___f_84_; lean_object* v___x_85_; lean_object* v___x_86_; 
v___x_67_ = lp_mathlib_Field_toSemifield___redArg(v_inst_64_);
v___x_68_ = lp_mathlib_Semifield_toDivisionSemiring___redArg(v___x_67_);
v_toSemiring_69_ = lean_ctor_get(v___x_68_, 0);
lean_inc_ref(v_toSemiring_69_);
lean_dec_ref(v___x_68_);
v_toAddCommMonoid_70_ = lean_ctor_get(v_toSemiring_69_, 0);
lean_inc_ref(v_toAddCommMonoid_70_);
lean_dec_ref(v_toSemiring_69_);
v___f_71_ = ((lean_object*)(lp_tree_Formalism_L2_Indef_Tree_exampleFac4___redArg___closed__0));
v___f_72_ = ((lean_object*)(lp_tree_Formalism_L2_Indef_Tree_exampleFac4___redArg___closed__1));
v___x_73_ = lp_mathlib_PUnit_fintype;
v___f_74_ = lean_alloc_closure((void*)(lp_tree_Formalism_L2_Indef_Tree_exampleFac4___redArg___lam__3___boxed), 3, 1);
lean_closure_set(v___f_74_, 0, v_toAddCommMonoid_70_);
v___x_75_ = lp_mathlib_Real_definition_00___x40_Mathlib_Data_Real_Basic_1279875089____hygCtx___hyg_8_;
v___f_76_ = lean_obj_once(&lp_tree_Formalism_L2_Indef_Tree_exampleFac4___redArg___closed__3, &lp_tree_Formalism_L2_Indef_Tree_exampleFac4___redArg___closed__3_once, _init_lp_tree_Formalism_L2_Indef_Tree_exampleFac4___redArg___closed__3);
v___x_77_ = lean_unsigned_to_nat(1u);
v___x_78_ = lean_unsigned_to_nat(2u);
v___x_290__overap_79_ = lp_mathlib_Real_instNatCast;
v___x_80_ = lean_apply_1(v___x_290__overap_79_, v___x_78_);
v___x_81_ = lp_mathlib_Real_definition_00___x40_Mathlib_Data_Real_Basic_1850581184____hygCtx___hyg_8_;
v___f_82_ = lean_obj_once(&lp_tree_Formalism_L2_Indef_Tree_exampleFac4___redArg___closed__4, &lp_tree_Formalism_L2_Indef_Tree_exampleFac4___redArg___closed__4_once, _init_lp_tree_Formalism_L2_Indef_Tree_exampleFac4___redArg___closed__4);
v___x_83_ = lean_unsigned_to_nat(0u);
v___f_84_ = lean_obj_once(&lp_tree_Formalism_L2_Indef_Tree_exampleFac4___redArg___closed__5, &lp_tree_Formalism_L2_Indef_Tree_exampleFac4___redArg___closed__5_once, _init_lp_tree_Formalism_L2_Indef_Tree_exampleFac4___redArg___closed__5);
v___x_85_ = lean_box(0);
lean_inc_ref(v___f_74_);
v___x_86_ = lean_alloc_ctor(0, 46, 0);
lean_ctor_set(v___x_86_, 0, v___f_71_);
lean_ctor_set(v___x_86_, 1, v___f_71_);
lean_ctor_set(v___x_86_, 2, v___f_71_);
lean_ctor_set(v___x_86_, 3, v___f_72_);
lean_ctor_set(v___x_86_, 4, v___x_75_);
lean_ctor_set(v___x_86_, 5, v___x_77_);
lean_ctor_set(v___x_86_, 6, v___x_75_);
lean_ctor_set(v___x_86_, 7, v___x_73_);
lean_ctor_set(v___x_86_, 8, v___x_80_);
lean_ctor_set(v___x_86_, 9, v___x_75_);
lean_ctor_set(v___x_86_, 10, v___x_81_);
lean_ctor_set(v___x_86_, 11, v___x_81_);
lean_ctor_set(v___x_86_, 12, v_cc_65_);
lean_ctor_set(v___x_86_, 13, v___x_81_);
lean_ctor_set(v___x_86_, 14, v___x_81_);
lean_ctor_set(v___x_86_, 15, v___x_81_);
lean_ctor_set(v___x_86_, 16, v_R1_66_);
lean_ctor_set(v___x_86_, 17, v___x_81_);
lean_ctor_set(v___x_86_, 18, v___x_75_);
lean_ctor_set(v___x_86_, 19, v___x_75_);
lean_ctor_set(v___x_86_, 20, v___f_82_);
lean_ctor_set(v___x_86_, 21, v___f_82_);
lean_ctor_set(v___x_86_, 22, v___f_76_);
lean_ctor_set(v___x_86_, 23, v___f_76_);
lean_ctor_set(v___x_86_, 24, v___f_82_);
lean_ctor_set(v___x_86_, 25, v___x_81_);
lean_ctor_set(v___x_86_, 26, v___x_81_);
lean_ctor_set(v___x_86_, 27, v___x_81_);
lean_ctor_set(v___x_86_, 28, v___x_83_);
lean_ctor_set(v___x_86_, 29, v___x_83_);
lean_ctor_set(v___x_86_, 30, v___x_83_);
lean_ctor_set(v___x_86_, 31, v___f_84_);
lean_ctor_set(v___x_86_, 32, v___f_84_);
lean_ctor_set(v___x_86_, 33, v___f_84_);
lean_ctor_set(v___x_86_, 34, v___x_85_);
lean_ctor_set(v___x_86_, 35, v___x_85_);
lean_ctor_set(v___x_86_, 36, v___x_85_);
lean_ctor_set(v___x_86_, 37, v___x_85_);
lean_ctor_set(v___x_86_, 38, v___f_74_);
lean_ctor_set(v___x_86_, 39, v___f_74_);
lean_ctor_set(v___x_86_, 40, v___x_77_);
lean_ctor_set(v___x_86_, 41, v___x_81_);
lean_ctor_set(v___x_86_, 42, v___x_81_);
lean_ctor_set(v___x_86_, 43, v___x_81_);
lean_ctor_set(v___x_86_, 44, v___x_81_);
lean_ctor_set(v___x_86_, 45, v___x_81_);
return v___x_86_;
}
}
LEAN_EXPORT lean_object* lp_tree_Formalism_L2_Indef_Tree_exampleFac4___redArg___boxed(lean_object* v_inst_87_, lean_object* v_cc_88_, lean_object* v_R1_89_){
_start:
{
lean_object* v_res_90_; 
v_res_90_ = lp_tree_Formalism_L2_Indef_Tree_exampleFac4___redArg(v_inst_87_, v_cc_88_, v_R1_89_);
lean_dec_ref(v_inst_87_);
return v_res_90_;
}
}
LEAN_EXPORT lean_object* lp_tree_Formalism_L2_Indef_Tree_exampleFac4(lean_object* v_K_91_, lean_object* v_inst_92_, lean_object* v_inst_93_, lean_object* v_inst_94_, lean_object* v_cc_95_, lean_object* v_R1_96_){
_start:
{
lean_object* v___x_97_; 
v___x_97_ = lp_tree_Formalism_L2_Indef_Tree_exampleFac4___redArg(v_inst_92_, v_cc_95_, v_R1_96_);
return v___x_97_;
}
}
LEAN_EXPORT lean_object* lp_tree_Formalism_L2_Indef_Tree_exampleFac4___boxed(lean_object* v_K_98_, lean_object* v_inst_99_, lean_object* v_inst_100_, lean_object* v_inst_101_, lean_object* v_cc_102_, lean_object* v_R1_103_){
_start:
{
lean_object* v_res_104_; 
v_res_104_ = lp_tree_Formalism_L2_Indef_Tree_exampleFac4(v_K_98_, v_inst_99_, v_inst_100_, v_inst_101_, v_cc_102_, v_R1_103_);
lean_dec(v_inst_101_);
lean_dec_ref(v_inst_99_);
return v_res_104_;
}
}
lean_object* initialize_Init(uint8_t builtin);
lean_object* initialize_Init(uint8_t builtin);
lean_object* initialize_mathlib_Mathlib(uint8_t builtin);
lean_object* initialize_tree_Formalism_LocalToGlobal_IndefiniteForms_IndefiniteTree_SlopeBoundSingleLiftOfDefinitions(uint8_t builtin);
static bool _G_initialized = false;
LEAN_EXPORT lean_object* initialize_tree_Formalism_LocalToGlobal_IndefiniteForms_IndefiniteTree_SlopeBoundOfConditionsWithErrorForFrames(uint8_t builtin) {
lean_object * res;
if (_G_initialized) return lean_io_result_mk_ok(lean_box(0));
_G_initialized = true;
res = initialize_Init(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_Init(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_mathlib_Mathlib(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_Formalism_LocalToGlobal_IndefiniteForms_IndefiniteTree_SlopeBoundSingleLiftOfDefinitions(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
return lean_io_result_mk_ok(lean_box(0));
}
#ifdef __cplusplus
}
#endif
