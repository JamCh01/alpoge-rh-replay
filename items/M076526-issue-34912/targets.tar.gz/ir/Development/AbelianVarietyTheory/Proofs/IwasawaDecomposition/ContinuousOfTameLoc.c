// Lean compiler output
// Module: Development.AbelianVarietyTheory.Proofs.IwasawaDecomposition.ContinuousOfTameLoc
// Imports: public import Init public meta import Init public import Mathlib public import Formalism.LocalRingCardinality.RhoDetPrimeEqMuTildeMulChiPow public import Formalism.LocalToGlobal.UnitaryNorms.CharTied public import Development.AbelianVarietyTheory.Definitions.AutomorphicMembership.IsRationalUnitaryDeterminantMapRationalUnitaryTo public import Development.AbelianVarietyTheory.Proofs.IwasawaDecomposition.ContinuousInfIdele
#include <lean/lean.h>
#if defined(__clang__)
#pragma clang diagnostic ignored "-Wunused-parameter"
#pragma clang diagnostic ignored "-Wunused-label"
#elif defined(__GNUC__) && !defined(__CLANG__)
#pragma GCC diagnostic ignored "-Wunused-parameter"
#pragma GCC diagnostic ignored "-Wunused-label"
#pragma GCC diagnostic ignored "-Wunused-but-set-variable"
#endif
#ifdef __cplusplus
extern "C" {
#endif
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_ModelChar_finEv___redArg___lam__0(lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_ModelChar_finEv___redArg(lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_ModelChar_finEv(lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_ModelChar_finEv___boxed(lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_ModelChar_infEv___redArg___lam__0(lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_ModelChar_infEv___redArg(lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_ModelChar_infEv(lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_ModelChar_infEv___boxed(lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_ModelChar_finEv___redArg___lam__0(lean_object* v_v_1_, lean_object* v_a_2_){
_start:
{
lean_object* v_snd_3_; lean_object* v___x_4_; 
v_snd_3_ = lean_ctor_get(v_a_2_, 1);
lean_inc(v_snd_3_);
lean_dec_ref(v_a_2_);
v___x_4_ = lean_apply_1(v_snd_3_, v_v_1_);
return v___x_4_;
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_ModelChar_finEv___redArg(lean_object* v_v_5_){
_start:
{
lean_object* v___f_6_; 
v___f_6_ = lean_alloc_closure((void*)(lp_tree_GlobalTheory_ModelChar_finEv___redArg___lam__0), 2, 1);
lean_closure_set(v___f_6_, 0, v_v_5_);
return v___f_6_;
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_ModelChar_finEv(lean_object* v_L_7_, lean_object* v_inst_8_, lean_object* v_inst_9_, lean_object* v_v_10_){
_start:
{
lean_object* v___f_11_; 
v___f_11_ = lean_alloc_closure((void*)(lp_tree_GlobalTheory_ModelChar_finEv___redArg___lam__0), 2, 1);
lean_closure_set(v___f_11_, 0, v_v_10_);
return v___f_11_;
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_ModelChar_finEv___boxed(lean_object* v_L_12_, lean_object* v_inst_13_, lean_object* v_inst_14_, lean_object* v_v_15_){
_start:
{
lean_object* v_res_16_; 
v_res_16_ = lp_tree_GlobalTheory_ModelChar_finEv(v_L_12_, v_inst_13_, v_inst_14_, v_v_15_);
lean_dec_ref(v_inst_13_);
return v_res_16_;
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_ModelChar_infEv___redArg___lam__0(lean_object* v_w_17_, lean_object* v_a_18_){
_start:
{
lean_object* v_fst_19_; lean_object* v___x_20_; 
v_fst_19_ = lean_ctor_get(v_a_18_, 0);
lean_inc(v_fst_19_);
lean_dec_ref(v_a_18_);
v___x_20_ = lean_apply_1(v_fst_19_, v_w_17_);
return v___x_20_;
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_ModelChar_infEv___redArg(lean_object* v_w_21_){
_start:
{
lean_object* v___f_22_; 
v___f_22_ = lean_alloc_closure((void*)(lp_tree_GlobalTheory_ModelChar_infEv___redArg___lam__0), 2, 1);
lean_closure_set(v___f_22_, 0, v_w_21_);
return v___f_22_;
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_ModelChar_infEv(lean_object* v_L_23_, lean_object* v_inst_24_, lean_object* v_inst_25_, lean_object* v_w_26_){
_start:
{
lean_object* v___f_27_; 
v___f_27_ = lean_alloc_closure((void*)(lp_tree_GlobalTheory_ModelChar_infEv___redArg___lam__0), 2, 1);
lean_closure_set(v___f_27_, 0, v_w_26_);
return v___f_27_;
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_ModelChar_infEv___boxed(lean_object* v_L_28_, lean_object* v_inst_29_, lean_object* v_inst_30_, lean_object* v_w_31_){
_start:
{
lean_object* v_res_32_; 
v_res_32_ = lp_tree_GlobalTheory_ModelChar_infEv(v_L_28_, v_inst_29_, v_inst_30_, v_w_31_);
lean_dec_ref(v_inst_29_);
return v_res_32_;
}
}
lean_object* initialize_Init(uint8_t builtin);
lean_object* initialize_Init(uint8_t builtin);
lean_object* initialize_mathlib_Mathlib(uint8_t builtin);
lean_object* initialize_tree_Formalism_LocalRingCardinality_RhoDetPrimeEqMuTildeMulChiPow(uint8_t builtin);
lean_object* initialize_tree_Formalism_LocalToGlobal_UnitaryNorms_CharTied(uint8_t builtin);
lean_object* initialize_tree_Development_AbelianVarietyTheory_Definitions_AutomorphicMembership_IsRationalUnitaryDeterminantMapRationalUnitaryTo(uint8_t builtin);
lean_object* initialize_tree_Development_AbelianVarietyTheory_Proofs_IwasawaDecomposition_ContinuousInfIdele(uint8_t builtin);
static bool _G_initialized = false;
LEAN_EXPORT lean_object* initialize_tree_Development_AbelianVarietyTheory_Proofs_IwasawaDecomposition_ContinuousOfTameLoc(uint8_t builtin) {
lean_object * res;
if (_G_initialized) return lean_io_result_mk_ok(lean_box(0));
_G_initialized = true;
res = initialize_Init(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_Init(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_mathlib_Mathlib(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_Formalism_LocalRingCardinality_RhoDetPrimeEqMuTildeMulChiPow(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_Formalism_LocalToGlobal_UnitaryNorms_CharTied(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_Development_AbelianVarietyTheory_Definitions_AutomorphicMembership_IsRationalUnitaryDeterminantMapRationalUnitaryTo(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_Development_AbelianVarietyTheory_Proofs_IwasawaDecomposition_ContinuousInfIdele(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
return lean_io_result_mk_ok(lean_box(0));
}
#ifdef __cplusplus
}
#endif
