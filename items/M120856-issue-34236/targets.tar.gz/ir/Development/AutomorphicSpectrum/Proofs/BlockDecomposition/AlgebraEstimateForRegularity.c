// Lean compiler output
// Module: Development.AutomorphicSpectrum.Proofs.BlockDecomposition.AlgebraEstimateForRegularity
// Imports: public import Init public meta import Init public import Mathlib public import Development.WeilBound.RepresentationTheoryGL.ArchimedeanBaseChange.ArchimedeanBaseChangeProof.ArchimedeanGelfandKernels.WaveSt
#include <lean/lean.h>
#if defined(__clang__)
#pragma clang diagnostic ignored "-Wunused-parameter"
#pragma clang diagnostic ignored "-Wunused-label"
#elif defined(__GNUC__) && !defined(__CLANG__)
#pragma GCC diagnostic ignored "-Wunused-parameter"
#pragma GCC diagnostic ignored "-Wunused-label"
#pragma GCC diagnostic ignored "-Wunused-but-set-variable"
#endif
#ifdef __cplusplus
extern "C" {
#endif
lean_object* lp_mathlib_Module_End_instMul___lam__0(lean_object*, lean_object*, lean_object*);
lean_object* lp_mathlib_LinearMap_id___lam__0___boxed(lean_object*);
lean_object* l_List_mapTR_loop___redArg(lean_object*, lean_object*, lean_object*);
lean_object* l_List_prod___redArg(lean_object*, lean_object*, lean_object*);
lean_object* lp_mathlib_Finset_sum___redArg(lean_object*, lean_object*, lean_object*);
extern lean_object* lp_mathlib_Real_instAddCommMonoid;
lean_object* lean_nat_add(lean_object*, lean_object*);
lean_object* l_List_range(lean_object*);
lean_object* lp_mathlib_SubNegZeroMonoid_toNegZeroClass___redArg(lean_object*);
lean_object* lp_mathlib_LinearMap_comp___redArg___lam__0(lean_object*, lean_object*, lean_object*);
lean_object* lp_mathlib_LinearMap_addMonoid___redArg(lean_object*);
lean_object* lp_mathlib_npowBinRec_go___redArg(lean_object*, lean_object*, lean_object*, lean_object*);
lean_object* lp_mathlib_Equiv_vectorEquivFin___redArg(lean_object*);
lean_object* l_instDecidableEqFin___boxed(lean_object*, lean_object*, lean_object*);
lean_object* lp_mathlib_Equiv_symm___redArg(lean_object*);
lean_object* l_List_finRange(lean_object*);
lean_object* lp_mathlib_Fintype_piFinset___redArg(lean_object*, lean_object*, lean_object*);
lean_object* lp_mathlib_Finset_map___redArg(lean_object*, lean_object*);
static const lean_closure_object lp_tree_GlobalTheory_CompanionTheory_SkewWords_wd___redArg___closed__0_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_closure_object) + sizeof(void*)*0, .m_other = 0, .m_tag = 245}, .m_fun = (void*)lp_mathlib_Module_End_instMul___lam__0, .m_arity = 3, .m_num_fixed = 0, .m_objs = {} };
static const lean_object* lp_tree_GlobalTheory_CompanionTheory_SkewWords_wd___redArg___closed__0 = (const lean_object*)&lp_tree_GlobalTheory_CompanionTheory_SkewWords_wd___redArg___closed__0_value;
static const lean_closure_object lp_tree_GlobalTheory_CompanionTheory_SkewWords_wd___redArg___closed__1_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_closure_object) + sizeof(void*)*0, .m_other = 0, .m_tag = 245}, .m_fun = (void*)lp_mathlib_LinearMap_id___lam__0___boxed, .m_arity = 1, .m_num_fixed = 0, .m_objs = {} };
static const lean_object* lp_tree_GlobalTheory_CompanionTheory_SkewWords_wd___redArg___closed__1 = (const lean_object*)&lp_tree_GlobalTheory_CompanionTheory_SkewWords_wd___redArg___closed__1_value;
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_CompanionTheory_SkewWords_wd___redArg(lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_CompanionTheory_SkewWords_wd(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_CompanionTheory_SkewWords_wd___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_CompanionTheory_SkewWords_lap___redArg___lam__0(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_CompanionTheory_SkewWords_lap___redArg___lam__1(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_CompanionTheory_SkewWords_lap___redArg___lam__1___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_CompanionTheory_SkewWords_lap___redArg(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_CompanionTheory_SkewWords_lap(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_CompanionTheory_SkewWords_lap___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_CompanionTheory_SkewWords_bsum___redArg___lam__0(lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_CompanionTheory_SkewWords_bsum___redArg___lam__0___boxed(lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_CompanionTheory_SkewWords_bsum___redArg___lam__1(lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_CompanionTheory_SkewWords_bsum___redArg___lam__2(lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_CompanionTheory_SkewWords_bsum___redArg(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_CompanionTheory_SkewWords_bsum(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_CompanionTheory_SkewWords_bsum___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_CompanionTheory_SkewWords_qsum___redArg___lam__0(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_CompanionTheory_SkewWords_qsum___redArg___lam__0___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_CompanionTheory_SkewWords_qsum___redArg(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_CompanionTheory_SkewWords_qsum___redArg___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_CompanionTheory_SkewWords_qsum(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_CompanionTheory_SkewWords_qsum___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_CompanionTheory_SkewWords_wspan(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_CompanionTheory_SkewWords_wspan___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_CompanionTheory_SkewWords_wd___redArg(lean_object* v_X_3_, lean_object* v_w_4_){
_start:
{
lean_object* v___f_5_; lean_object* v___f_6_; lean_object* v___x_7_; lean_object* v___x_8_; lean_object* v___x_9_; 
v___f_5_ = ((lean_object*)(lp_tree_GlobalTheory_CompanionTheory_SkewWords_wd___redArg___closed__0));
v___f_6_ = ((lean_object*)(lp_tree_GlobalTheory_CompanionTheory_SkewWords_wd___redArg___closed__1));
v___x_7_ = lean_box(0);
v___x_8_ = l_List_mapTR_loop___redArg(v_X_3_, v_w_4_, v___x_7_);
v___x_9_ = l_List_prod___redArg(v___f_5_, v___f_6_, v___x_8_);
return v___x_9_;
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_CompanionTheory_SkewWords_wd(lean_object* v_V_10_, lean_object* v_00_u03b9_11_, lean_object* v_inst_12_, lean_object* v_inst_13_, lean_object* v_X_14_, lean_object* v_w_15_){
_start:
{
lean_object* v___x_16_; 
v___x_16_ = lp_tree_GlobalTheory_CompanionTheory_SkewWords_wd___redArg(v_X_14_, v_w_15_);
return v___x_16_;
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_CompanionTheory_SkewWords_wd___boxed(lean_object* v_V_17_, lean_object* v_00_u03b9_18_, lean_object* v_inst_19_, lean_object* v_inst_20_, lean_object* v_X_21_, lean_object* v_w_22_){
_start:
{
lean_object* v_res_23_; 
v_res_23_ = lp_tree_GlobalTheory_CompanionTheory_SkewWords_wd(v_V_17_, v_00_u03b9_18_, v_inst_19_, v_inst_20_, v_X_21_, v_w_22_);
lean_dec_ref(v_inst_20_);
lean_dec_ref(v_inst_19_);
return v_res_23_;
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_CompanionTheory_SkewWords_lap___redArg___lam__0(lean_object* v_X_24_, lean_object* v_i_25_, lean_object* v___y_26_){
_start:
{
lean_object* v___x_27_; lean_object* v___x_28_; 
v___x_27_ = lean_apply_1(v_X_24_, v_i_25_);
lean_inc(v___x_27_);
v___x_28_ = lp_mathlib_LinearMap_comp___redArg___lam__0(v___x_27_, v___x_27_, v___y_26_);
return v___x_28_;
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_CompanionTheory_SkewWords_lap___redArg___lam__1(lean_object* v___x_29_, lean_object* v_inst_30_, lean_object* v___f_31_, lean_object* v_toNeg_32_, lean_object* v___y_33_){
_start:
{
lean_object* v___x_135__overap_34_; lean_object* v___x_35_; lean_object* v___x_36_; 
v___x_135__overap_34_ = lp_mathlib_Finset_sum___redArg(v___x_29_, v_inst_30_, v___f_31_);
v___x_35_ = lean_apply_1(v___x_135__overap_34_, v___y_33_);
v___x_36_ = lean_apply_1(v_toNeg_32_, v___x_35_);
return v___x_36_;
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_CompanionTheory_SkewWords_lap___redArg___lam__1___boxed(lean_object* v___x_37_, lean_object* v_inst_38_, lean_object* v___f_39_, lean_object* v_toNeg_40_, lean_object* v___y_41_){
_start:
{
lean_object* v_res_42_; 
v_res_42_ = lp_tree_GlobalTheory_CompanionTheory_SkewWords_lap___redArg___lam__1(v___x_37_, v_inst_38_, v___f_39_, v_toNeg_40_, v___y_41_);
lean_dec_ref(v___x_37_);
return v_res_42_;
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_CompanionTheory_SkewWords_lap___redArg(lean_object* v_inst_43_, lean_object* v_inst_44_, lean_object* v_X_45_){
_start:
{
lean_object* v_toAddCommGroup_46_; lean_object* v_toAddMonoid_47_; lean_object* v___x_48_; lean_object* v_toNeg_49_; lean_object* v___f_50_; lean_object* v___x_51_; lean_object* v___f_52_; 
v_toAddCommGroup_46_ = lean_ctor_get(v_inst_43_, 1);
lean_inc_ref(v_toAddCommGroup_46_);
lean_dec_ref(v_inst_43_);
v_toAddMonoid_47_ = lean_ctor_get(v_toAddCommGroup_46_, 0);
lean_inc_ref(v_toAddMonoid_47_);
v___x_48_ = lp_mathlib_SubNegZeroMonoid_toNegZeroClass___redArg(v_toAddCommGroup_46_);
lean_dec_ref(v_toAddCommGroup_46_);
v_toNeg_49_ = lean_ctor_get(v___x_48_, 1);
lean_inc(v_toNeg_49_);
lean_dec_ref(v___x_48_);
v___f_50_ = lean_alloc_closure((void*)(lp_tree_GlobalTheory_CompanionTheory_SkewWords_lap___redArg___lam__0), 3, 1);
lean_closure_set(v___f_50_, 0, v_X_45_);
v___x_51_ = lp_mathlib_LinearMap_addMonoid___redArg(v_toAddMonoid_47_);
v___f_52_ = lean_alloc_closure((void*)(lp_tree_GlobalTheory_CompanionTheory_SkewWords_lap___redArg___lam__1___boxed), 5, 4);
lean_closure_set(v___f_52_, 0, v___x_51_);
lean_closure_set(v___f_52_, 1, v_inst_44_);
lean_closure_set(v___f_52_, 2, v___f_50_);
lean_closure_set(v___f_52_, 3, v_toNeg_49_);
return v___f_52_;
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_CompanionTheory_SkewWords_lap(lean_object* v_V_53_, lean_object* v_00_u03b9_54_, lean_object* v_inst_55_, lean_object* v_inst_56_, lean_object* v_inst_57_, lean_object* v_X_58_){
_start:
{
lean_object* v___x_59_; 
v___x_59_ = lp_tree_GlobalTheory_CompanionTheory_SkewWords_lap___redArg(v_inst_55_, v_inst_57_, v_X_58_);
return v___x_59_;
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_CompanionTheory_SkewWords_lap___boxed(lean_object* v_V_60_, lean_object* v_00_u03b9_61_, lean_object* v_inst_62_, lean_object* v_inst_63_, lean_object* v_inst_64_, lean_object* v_X_65_){
_start:
{
lean_object* v_res_66_; 
v_res_66_ = lp_tree_GlobalTheory_CompanionTheory_SkewWords_lap(v_V_60_, v_00_u03b9_61_, v_inst_62_, v_inst_63_, v_inst_64_, v_X_65_);
lean_dec_ref(v_inst_63_);
return v_res_66_;
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_CompanionTheory_SkewWords_bsum___redArg___lam__0(lean_object* v_inst_67_, lean_object* v_x_68_){
_start:
{
lean_inc(v_inst_67_);
return v_inst_67_;
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_CompanionTheory_SkewWords_bsum___redArg___lam__0___boxed(lean_object* v_inst_69_, lean_object* v_x_70_){
_start:
{
lean_object* v_res_71_; 
v_res_71_ = lp_tree_GlobalTheory_CompanionTheory_SkewWords_bsum___redArg___lam__0(v_inst_69_, v_x_70_);
lean_dec(v_x_70_);
lean_dec(v_inst_69_);
return v_res_71_;
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_CompanionTheory_SkewWords_bsum___redArg___lam__1(lean_object* v___x_72_, lean_object* v___y_73_){
_start:
{
lean_object* v_toFun_74_; lean_object* v___x_75_; 
v_toFun_74_ = lean_ctor_get(v___x_72_, 0);
lean_inc(v_toFun_74_);
lean_dec_ref(v___x_72_);
v___x_75_ = lean_apply_1(v_toFun_74_, v___y_73_);
return v___x_75_;
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_CompanionTheory_SkewWords_bsum___redArg___lam__2(lean_object* v_X_76_, lean_object* v_u_77_, lean_object* v_toNorm_78_, lean_object* v_v_79_){
_start:
{
lean_object* v___x_60__overap_80_; lean_object* v___x_81_; lean_object* v___x_82_; 
v___x_60__overap_80_ = lp_tree_GlobalTheory_CompanionTheory_SkewWords_wd___redArg(v_X_76_, v_v_79_);
v___x_81_ = lean_apply_1(v___x_60__overap_80_, v_u_77_);
v___x_82_ = lean_apply_1(v_toNorm_78_, v___x_81_);
return v___x_82_;
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_CompanionTheory_SkewWords_bsum___redArg(lean_object* v_inst_83_, lean_object* v_inst_84_, lean_object* v_X_85_, lean_object* v_m_86_, lean_object* v_u_87_){
_start:
{
lean_object* v___x_88_; lean_object* v_toNorm_89_; lean_object* v___x_90_; lean_object* v___x_91_; lean_object* v___f_92_; lean_object* v___x_93_; lean_object* v___f_94_; lean_object* v___x_95_; lean_object* v___x_96_; lean_object* v___x_97_; lean_object* v___f_98_; lean_object* v___x_99_; 
v___x_88_ = lp_mathlib_Real_instAddCommMonoid;
v_toNorm_89_ = lean_ctor_get(v_inst_83_, 0);
lean_inc(v_toNorm_89_);
lean_dec_ref(v_inst_83_);
lean_inc_n(v_m_86_, 2);
v___x_90_ = lp_mathlib_Equiv_vectorEquivFin___redArg(v_m_86_);
v___x_91_ = lean_alloc_closure((void*)(l_instDecidableEqFin___boxed), 3, 1);
lean_closure_set(v___x_91_, 0, v_m_86_);
v___f_92_ = lean_alloc_closure((void*)(lp_tree_GlobalTheory_CompanionTheory_SkewWords_bsum___redArg___lam__0___boxed), 2, 1);
lean_closure_set(v___f_92_, 0, v_inst_84_);
v___x_93_ = lp_mathlib_Equiv_symm___redArg(v___x_90_);
v___f_94_ = lean_alloc_closure((void*)(lp_tree_GlobalTheory_CompanionTheory_SkewWords_bsum___redArg___lam__1), 2, 1);
lean_closure_set(v___f_94_, 0, v___x_93_);
v___x_95_ = l_List_finRange(v_m_86_);
v___x_96_ = lp_mathlib_Fintype_piFinset___redArg(v___x_91_, v___x_95_, v___f_92_);
v___x_97_ = lp_mathlib_Finset_map___redArg(v___f_94_, v___x_96_);
v___f_98_ = lean_alloc_closure((void*)(lp_tree_GlobalTheory_CompanionTheory_SkewWords_bsum___redArg___lam__2), 4, 3);
lean_closure_set(v___f_98_, 0, v_X_85_);
lean_closure_set(v___f_98_, 1, v_u_87_);
lean_closure_set(v___f_98_, 2, v_toNorm_89_);
v___x_99_ = lp_mathlib_Finset_sum___redArg(v___x_88_, v___x_97_, v___f_98_);
return v___x_99_;
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_CompanionTheory_SkewWords_bsum(lean_object* v_V_100_, lean_object* v_00_u03b9_101_, lean_object* v_inst_102_, lean_object* v_inst_103_, lean_object* v_inst_104_, lean_object* v_X_105_, lean_object* v_m_106_, lean_object* v_u_107_){
_start:
{
lean_object* v___x_108_; 
v___x_108_ = lp_tree_GlobalTheory_CompanionTheory_SkewWords_bsum___redArg(v_inst_102_, v_inst_104_, v_X_105_, v_m_106_, v_u_107_);
return v___x_108_;
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_CompanionTheory_SkewWords_bsum___boxed(lean_object* v_V_109_, lean_object* v_00_u03b9_110_, lean_object* v_inst_111_, lean_object* v_inst_112_, lean_object* v_inst_113_, lean_object* v_X_114_, lean_object* v_m_115_, lean_object* v_u_116_){
_start:
{
lean_object* v_res_117_; 
v_res_117_ = lp_tree_GlobalTheory_CompanionTheory_SkewWords_bsum(v_V_109_, v_00_u03b9_110_, v_inst_111_, v_inst_112_, v_inst_113_, v_X_114_, v_m_115_, v_u_116_);
lean_dec_ref(v_inst_112_);
return v_res_117_;
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_CompanionTheory_SkewWords_qsum___redArg___lam__0(lean_object* v_inst_118_, lean_object* v_inst_119_, lean_object* v_X_120_, lean_object* v_u_121_, lean_object* v_toNorm_122_, lean_object* v_j_123_){
_start:
{
lean_object* v___x_124_; lean_object* v___f_125_; lean_object* v___f_126_; lean_object* v___x_88__overap_127_; lean_object* v___x_128_; lean_object* v___x_129_; 
v___x_124_ = lp_tree_GlobalTheory_CompanionTheory_SkewWords_lap___redArg(v_inst_118_, v_inst_119_, v_X_120_);
v___f_125_ = ((lean_object*)(lp_tree_GlobalTheory_CompanionTheory_SkewWords_wd___redArg___closed__0));
v___f_126_ = ((lean_object*)(lp_tree_GlobalTheory_CompanionTheory_SkewWords_wd___redArg___closed__1));
v___x_88__overap_127_ = lp_mathlib_npowBinRec_go___redArg(v___f_125_, v_j_123_, v___f_126_, v___x_124_);
v___x_128_ = lean_apply_1(v___x_88__overap_127_, v_u_121_);
v___x_129_ = lean_apply_1(v_toNorm_122_, v___x_128_);
return v___x_129_;
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_CompanionTheory_SkewWords_qsum___redArg___lam__0___boxed(lean_object* v_inst_130_, lean_object* v_inst_131_, lean_object* v_X_132_, lean_object* v_u_133_, lean_object* v_toNorm_134_, lean_object* v_j_135_){
_start:
{
lean_object* v_res_136_; 
v_res_136_ = lp_tree_GlobalTheory_CompanionTheory_SkewWords_qsum___redArg___lam__0(v_inst_130_, v_inst_131_, v_X_132_, v_u_133_, v_toNorm_134_, v_j_135_);
lean_dec(v_j_135_);
return v_res_136_;
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_CompanionTheory_SkewWords_qsum___redArg(lean_object* v_inst_137_, lean_object* v_inst_138_, lean_object* v_X_139_, lean_object* v_m_140_, lean_object* v_u_141_){
_start:
{
lean_object* v___x_142_; lean_object* v_toNorm_143_; lean_object* v___x_144_; lean_object* v___x_145_; lean_object* v___x_146_; lean_object* v___f_147_; lean_object* v___x_148_; 
v___x_142_ = lp_mathlib_Real_instAddCommMonoid;
v_toNorm_143_ = lean_ctor_get(v_inst_137_, 0);
lean_inc(v_toNorm_143_);
v___x_144_ = lean_unsigned_to_nat(1u);
v___x_145_ = lean_nat_add(v_m_140_, v___x_144_);
v___x_146_ = l_List_range(v___x_145_);
v___f_147_ = lean_alloc_closure((void*)(lp_tree_GlobalTheory_CompanionTheory_SkewWords_qsum___redArg___lam__0___boxed), 6, 5);
lean_closure_set(v___f_147_, 0, v_inst_137_);
lean_closure_set(v___f_147_, 1, v_inst_138_);
lean_closure_set(v___f_147_, 2, v_X_139_);
lean_closure_set(v___f_147_, 3, v_u_141_);
lean_closure_set(v___f_147_, 4, v_toNorm_143_);
v___x_148_ = lp_mathlib_Finset_sum___redArg(v___x_142_, v___x_146_, v___f_147_);
return v___x_148_;
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_CompanionTheory_SkewWords_qsum___redArg___boxed(lean_object* v_inst_149_, lean_object* v_inst_150_, lean_object* v_X_151_, lean_object* v_m_152_, lean_object* v_u_153_){
_start:
{
lean_object* v_res_154_; 
v_res_154_ = lp_tree_GlobalTheory_CompanionTheory_SkewWords_qsum___redArg(v_inst_149_, v_inst_150_, v_X_151_, v_m_152_, v_u_153_);
lean_dec(v_m_152_);
return v_res_154_;
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_CompanionTheory_SkewWords_qsum(lean_object* v_V_155_, lean_object* v_00_u03b9_156_, lean_object* v_inst_157_, lean_object* v_inst_158_, lean_object* v_inst_159_, lean_object* v_X_160_, lean_object* v_m_161_, lean_object* v_u_162_){
_start:
{
lean_object* v___x_163_; 
v___x_163_ = lp_tree_GlobalTheory_CompanionTheory_SkewWords_qsum___redArg(v_inst_157_, v_inst_159_, v_X_160_, v_m_161_, v_u_162_);
return v___x_163_;
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_CompanionTheory_SkewWords_qsum___boxed(lean_object* v_V_164_, lean_object* v_00_u03b9_165_, lean_object* v_inst_166_, lean_object* v_inst_167_, lean_object* v_inst_168_, lean_object* v_X_169_, lean_object* v_m_170_, lean_object* v_u_171_){
_start:
{
lean_object* v_res_172_; 
v_res_172_ = lp_tree_GlobalTheory_CompanionTheory_SkewWords_qsum(v_V_164_, v_00_u03b9_165_, v_inst_166_, v_inst_167_, v_inst_168_, v_X_169_, v_m_170_, v_u_171_);
lean_dec(v_m_170_);
lean_dec_ref(v_inst_167_);
return v_res_172_;
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_CompanionTheory_SkewWords_wspan(lean_object* v_V_173_, lean_object* v_00_u03b9_174_, lean_object* v_inst_175_, lean_object* v_inst_176_, lean_object* v_X_177_, lean_object* v_m_178_){
_start:
{
lean_object* v___x_179_; 
v___x_179_ = lean_box(0);
return v___x_179_;
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_CompanionTheory_SkewWords_wspan___boxed(lean_object* v_V_180_, lean_object* v_00_u03b9_181_, lean_object* v_inst_182_, lean_object* v_inst_183_, lean_object* v_X_184_, lean_object* v_m_185_){
_start:
{
lean_object* v_res_186_; 
v_res_186_ = lp_tree_GlobalTheory_CompanionTheory_SkewWords_wspan(v_V_180_, v_00_u03b9_181_, v_inst_182_, v_inst_183_, v_X_184_, v_m_185_);
lean_dec(v_m_185_);
lean_dec(v_X_184_);
lean_dec_ref(v_inst_183_);
lean_dec_ref(v_inst_182_);
return v_res_186_;
}
}
lean_object* initialize_Init(uint8_t builtin);
lean_object* initialize_Init(uint8_t builtin);
lean_object* initialize_mathlib_Mathlib(uint8_t builtin);
lean_object* initialize_tree_Development_WeilBound_RepresentationTheoryGL_ArchimedeanBaseChange_ArchimedeanBaseChangeProof_ArchimedeanGelfandKernels_WaveSt(uint8_t builtin);
static bool _G_initialized = false;
LEAN_EXPORT lean_object* initialize_tree_Development_AutomorphicSpectrum_Proofs_BlockDecomposition_AlgebraEstimateForRegularity(uint8_t builtin) {
lean_object * res;
if (_G_initialized) return lean_io_result_mk_ok(lean_box(0));
_G_initialized = true;
res = initialize_Init(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_Init(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_mathlib_Mathlib(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_Development_WeilBound_RepresentationTheoryGL_ArchimedeanBaseChange_ArchimedeanBaseChangeProof_ArchimedeanGelfandKernels_WaveSt(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
return lean_io_result_mk_ok(lean_box(0));
}
#ifdef __cplusplus
}
#endif
