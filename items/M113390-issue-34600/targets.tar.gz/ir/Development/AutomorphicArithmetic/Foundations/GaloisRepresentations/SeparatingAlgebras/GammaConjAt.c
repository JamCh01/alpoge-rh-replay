// Lean compiler output
// Module: Development.AutomorphicArithmetic.Foundations.GaloisRepresentations.SeparatingAlgebras.GammaConjAt
// Imports: public import Init public meta import Init public import Mathlib public import GroundTheory.AutomorphicForms.MacdonaldWhittakerHecke
#include <lean/lean.h>
#if defined(__clang__)
#pragma clang diagnostic ignored "-Wunused-parameter"
#pragma clang diagnostic ignored "-Wunused-label"
#elif defined(__GNUC__) && !defined(__CLANG__)
#pragma GCC diagnostic ignored "-Wunused-parameter"
#pragma GCC diagnostic ignored "-Wunused-label"
#pragma GCC diagnostic ignored "-Wunused-but-set-variable"
#endif
#ifdef __cplusplus
extern "C" {
#endif
uint8_t lean_nat_dec_lt(lean_object*, lean_object*);
lean_object* l_List_finRange(lean_object*);
lean_object* lp_mathlib_Multiset_product___redArg(lean_object*, lean_object*);
lean_object* lp_mathlib_Multiset_filter___redArg(lean_object*, lean_object*);
LEAN_EXPORT uint8_t lp_tree_UpperTheory_Gal_Gen_prs___lam__0(lean_object*);
LEAN_EXPORT lean_object* lp_tree_UpperTheory_Gal_Gen_prs___lam__0___boxed(lean_object*);
static const lean_closure_object lp_tree_UpperTheory_Gal_Gen_prs___closed__0_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_closure_object) + sizeof(void*)*0, .m_other = 0, .m_tag = 245}, .m_fun = (void*)lp_tree_UpperTheory_Gal_Gen_prs___lam__0___boxed, .m_arity = 1, .m_num_fixed = 0, .m_objs = {} };
static const lean_object* lp_tree_UpperTheory_Gal_Gen_prs___closed__0 = (const lean_object*)&lp_tree_UpperTheory_Gal_Gen_prs___closed__0_value;
LEAN_EXPORT lean_object* lp_tree_UpperTheory_Gal_Gen_prs(lean_object*);
LEAN_EXPORT uint8_t lp_tree_UpperTheory_Gal_Gen_prs___lam__0(lean_object* v_a_1_){
_start:
{
lean_object* v_fst_2_; lean_object* v_snd_3_; uint8_t v___x_4_; 
v_fst_2_ = lean_ctor_get(v_a_1_, 0);
v_snd_3_ = lean_ctor_get(v_a_1_, 1);
v___x_4_ = lean_nat_dec_lt(v_fst_2_, v_snd_3_);
return v___x_4_;
}
}
LEAN_EXPORT lean_object* lp_tree_UpperTheory_Gal_Gen_prs___lam__0___boxed(lean_object* v_a_5_){
_start:
{
uint8_t v_res_6_; lean_object* v_r_7_; 
v_res_6_ = lp_tree_UpperTheory_Gal_Gen_prs___lam__0(v_a_5_);
lean_dec_ref(v_a_5_);
v_r_7_ = lean_box(v_res_6_);
return v_r_7_;
}
}
LEAN_EXPORT lean_object* lp_tree_UpperTheory_Gal_Gen_prs(lean_object* v_n_9_){
_start:
{
lean_object* v___f_10_; lean_object* v___x_11_; lean_object* v___x_12_; lean_object* v___x_13_; 
v___f_10_ = ((lean_object*)(lp_tree_UpperTheory_Gal_Gen_prs___closed__0));
v___x_11_ = l_List_finRange(v_n_9_);
lean_inc(v___x_11_);
v___x_12_ = lp_mathlib_Multiset_product___redArg(v___x_11_, v___x_11_);
v___x_13_ = lp_mathlib_Multiset_filter___redArg(v___f_10_, v___x_12_);
return v___x_13_;
}
}
lean_object* initialize_Init(uint8_t builtin);
lean_object* initialize_Init(uint8_t builtin);
lean_object* initialize_mathlib_Mathlib(uint8_t builtin);
lean_object* initialize_tree_GroundTheory_AutomorphicForms_MacdonaldWhittakerHecke(uint8_t builtin);
static bool _G_initialized = false;
LEAN_EXPORT lean_object* initialize_tree_Development_AutomorphicArithmetic_Foundations_GaloisRepresentations_SeparatingAlgebras_GammaConjAt(uint8_t builtin) {
lean_object * res;
if (_G_initialized) return lean_io_result_mk_ok(lean_box(0));
_G_initialized = true;
res = initialize_Init(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_Init(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_mathlib_Mathlib(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_GroundTheory_AutomorphicForms_MacdonaldWhittakerHecke(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
return lean_io_result_mk_ok(lean_box(0));
}
#ifdef __cplusplus
}
#endif
