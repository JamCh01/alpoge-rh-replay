// Lean compiler output
// Module: Development.AbelianVarietyTheory.Proofs.ModuliProofs.E8SharpFamilyMatrixRelationsDense
// Imports: public import Init public meta import Init public import Mathlib public import Development.AbelianVarietyTheory.Definitions.ModuliSpaces.IsGaloisCover public import ReciprocityTheory.ReductiveGroups.ArithmeticGeometry.BirationalGeometry.ToroidalCompactification.UniformisationConclusion public import ReciprocityTheory.ReductiveGroups.ArithmeticGeometry.BirationalGeometry.ToroidalCompactification.HeckeKer public import ReciprocityTheory.ReductiveGroups.ArithmeticGeometry.BirationalGeometry.ToroidalCompactification.IsHolPeriods public import ReciprocityTheory.ReductiveGroups.ArithmeticGeometry.ExtensionDescent.UnifUniqSt public import Development.AbelianVarietyTheory.Proofs.ModuliProofs.SharpRelations public import Development.AbelianVarietyTheory.Proofs.HomogeneousIdeals.IsReducedAlgebraOfSmoothOfIsNoetherianRing
#include <lean/lean.h>
#if defined(__clang__)
#pragma clang diagnostic ignored "-Wunused-parameter"
#pragma clang diagnostic ignored "-Wunused-label"
#elif defined(__GNUC__) && !defined(__CLANG__)
#pragma GCC diagnostic ignored "-Wunused-parameter"
#pragma GCC diagnostic ignored "-Wunused-label"
#pragma GCC diagnostic ignored "-Wunused-but-set-variable"
#endif
#ifdef __cplusplus
extern "C" {
#endif
lean_object* lp_mathlib_CategoryTheory_CostructuredArrow_homMk___redArg(lean_object*);
lean_object* lp_tree_CategoryTheory_CostructuredArrow_homMk___at___00CategoryTheory_Over_homMk___at___00ReciprocityTheory_ChartRestriction_G_Out_overRes_u03b9_spec__1_spec__3___redArg(lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_SharpFamRel_selfMap___redArg(lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_SharpFamRel_selfMap(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_SharpFamRel_selfMap___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_SharpFamRel_baseMap___redArg(lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_SharpFamRel_baseMap(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_SharpFamRel_baseMap___boxed(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_SharpFamRel_selfMap___redArg(lean_object* v_00_u03c6_1_){
_start:
{
lean_object* v___x_2_; 
v___x_2_ = lp_mathlib_CategoryTheory_CostructuredArrow_homMk___redArg(v_00_u03c6_1_);
return v___x_2_;
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_SharpFamRel_selfMap(lean_object* v_S_3_, lean_object* v_S_x27_4_, lean_object* v_G_5_, lean_object* v_G_x27_6_, lean_object* v_inst_7_, lean_object* v_inst_8_, lean_object* v_f_9_, lean_object* v_00_u03c6_10_, lean_object* v_h_11_){
_start:
{
lean_object* v___x_12_; 
v___x_12_ = lp_mathlib_CategoryTheory_CostructuredArrow_homMk___redArg(v_00_u03c6_10_);
return v___x_12_;
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_SharpFamRel_selfMap___boxed(lean_object* v_S_13_, lean_object* v_S_x27_14_, lean_object* v_G_15_, lean_object* v_G_x27_16_, lean_object* v_inst_17_, lean_object* v_inst_18_, lean_object* v_f_19_, lean_object* v_00_u03c6_20_, lean_object* v_h_21_){
_start:
{
lean_object* v_res_22_; 
v_res_22_ = lp_tree_GlobalTheory_SharpFamRel_selfMap(v_S_13_, v_S_x27_14_, v_G_15_, v_G_x27_16_, v_inst_17_, v_inst_18_, v_f_19_, v_00_u03c6_20_, v_h_21_);
lean_dec_ref(v_f_19_);
lean_dec_ref(v_inst_18_);
lean_dec_ref(v_inst_17_);
lean_dec_ref(v_G_x27_16_);
lean_dec_ref(v_G_15_);
lean_dec_ref(v_S_x27_14_);
lean_dec_ref(v_S_13_);
return v_res_22_;
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_SharpFamRel_baseMap___redArg(lean_object* v_f_23_){
_start:
{
lean_object* v___x_24_; 
v___x_24_ = lp_tree_CategoryTheory_CostructuredArrow_homMk___at___00CategoryTheory_Over_homMk___at___00ReciprocityTheory_ChartRestriction_G_Out_overRes_u03b9_spec__1_spec__3___redArg(v_f_23_);
return v___x_24_;
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_SharpFamRel_baseMap(lean_object* v_S_25_, lean_object* v_S_x27_26_, lean_object* v_f_27_){
_start:
{
lean_object* v___x_28_; 
v___x_28_ = lp_tree_CategoryTheory_CostructuredArrow_homMk___at___00CategoryTheory_Over_homMk___at___00ReciprocityTheory_ChartRestriction_G_Out_overRes_u03b9_spec__1_spec__3___redArg(v_f_27_);
return v___x_28_;
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_SharpFamRel_baseMap___boxed(lean_object* v_S_29_, lean_object* v_S_x27_30_, lean_object* v_f_31_){
_start:
{
lean_object* v_res_32_; 
v_res_32_ = lp_tree_GlobalTheory_SharpFamRel_baseMap(v_S_29_, v_S_x27_30_, v_f_31_);
lean_dec_ref(v_S_x27_30_);
lean_dec_ref(v_S_29_);
return v_res_32_;
}
}
lean_object* initialize_Init(uint8_t builtin);
lean_object* initialize_Init(uint8_t builtin);
lean_object* initialize_mathlib_Mathlib(uint8_t builtin);
lean_object* initialize_tree_Development_AbelianVarietyTheory_Definitions_ModuliSpaces_IsGaloisCover(uint8_t builtin);
lean_object* initialize_tree_ReciprocityTheory_ReductiveGroups_ArithmeticGeometry_BirationalGeometry_ToroidalCompactification_UniformisationConclusion(uint8_t builtin);
lean_object* initialize_tree_ReciprocityTheory_ReductiveGroups_ArithmeticGeometry_BirationalGeometry_ToroidalCompactification_HeckeKer(uint8_t builtin);
lean_object* initialize_tree_ReciprocityTheory_ReductiveGroups_ArithmeticGeometry_BirationalGeometry_ToroidalCompactification_IsHolPeriods(uint8_t builtin);
lean_object* initialize_tree_ReciprocityTheory_ReductiveGroups_ArithmeticGeometry_ExtensionDescent_UnifUniqSt(uint8_t builtin);
lean_object* initialize_tree_Development_AbelianVarietyTheory_Proofs_ModuliProofs_SharpRelations(uint8_t builtin);
lean_object* initialize_tree_Development_AbelianVarietyTheory_Proofs_HomogeneousIdeals_IsReducedAlgebraOfSmoothOfIsNoetherianRing(uint8_t builtin);
static bool _G_initialized = false;
LEAN_EXPORT lean_object* initialize_tree_Development_AbelianVarietyTheory_Proofs_ModuliProofs_E8SharpFamilyMatrixRelationsDense(uint8_t builtin) {
lean_object * res;
if (_G_initialized) return lean_io_result_mk_ok(lean_box(0));
_G_initialized = true;
res = initialize_Init(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_Init(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_mathlib_Mathlib(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_Development_AbelianVarietyTheory_Definitions_ModuliSpaces_IsGaloisCover(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_ReciprocityTheory_ReductiveGroups_ArithmeticGeometry_BirationalGeometry_ToroidalCompactification_UniformisationConclusion(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_ReciprocityTheory_ReductiveGroups_ArithmeticGeometry_BirationalGeometry_ToroidalCompactification_HeckeKer(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_ReciprocityTheory_ReductiveGroups_ArithmeticGeometry_BirationalGeometry_ToroidalCompactification_IsHolPeriods(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_ReciprocityTheory_ReductiveGroups_ArithmeticGeometry_ExtensionDescent_UnifUniqSt(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_Development_AbelianVarietyTheory_Proofs_ModuliProofs_SharpRelations(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_Development_AbelianVarietyTheory_Proofs_HomogeneousIdeals_IsReducedAlgebraOfSmoothOfIsNoetherianRing(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
return lean_io_result_mk_ok(lean_box(0));
}
#ifdef __cplusplus
}
#endif
