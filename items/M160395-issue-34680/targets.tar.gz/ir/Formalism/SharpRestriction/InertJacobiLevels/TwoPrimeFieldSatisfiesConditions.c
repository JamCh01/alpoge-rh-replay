// Lean compiler output
// Module: Formalism.SharpRestriction.InertJacobiLevels.TwoPrimeFieldSatisfiesConditions
// Imports: public import Init public meta import Init public import Formalism.SharpRestriction.InertJacobiLevels.TwoPrimeFieldMemLevelOfCoprime
#include <lean/lean.h>
#if defined(__clang__)
#pragma clang diagnostic ignored "-Wunused-parameter"
#pragma clang diagnostic ignored "-Wunused-label"
#elif defined(__GNUC__) && !defined(__CLANG__)
#pragma GCC diagnostic ignored "-Wunused-parameter"
#pragma GCC diagnostic ignored "-Wunused-label"
#pragma GCC diagnostic ignored "-Wunused-but-set-variable"
#endif
#ifdef __cplusplus
extern "C" {
#endif
lean_object* lean_nat_mul(lean_object*, lean_object*);
lean_object* lean_nat_pow(lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_Formalism_MainNotions_Inhab_Base_MT___redArg(lean_object*);
LEAN_EXPORT lean_object* lp_tree_Formalism_MainNotions_Inhab_Base_MT___redArg___boxed(lean_object*);
LEAN_EXPORT lean_object* lp_tree_Formalism_MainNotions_Inhab_Base_MT(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_Formalism_MainNotions_Inhab_Base_MT___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_Formalism_MainNotions_Inhab_Base_MT___redArg(lean_object* v_B_1_){
_start:
{
lean_object* v_toFld_2_; lean_object* v_toHostAx_3_; lean_object* v_g0_4_; lean_object* v_g1_5_; lean_object* v_q_6_; lean_object* v_d_7_; lean_object* v_QS_8_; lean_object* v___x_9_; lean_object* v___x_10_; lean_object* v___x_11_; lean_object* v___x_12_; lean_object* v___x_13_; lean_object* v___x_14_; 
v_toFld_2_ = lean_ctor_get(v_B_1_, 0);
v_toHostAx_3_ = lean_ctor_get(v_toFld_2_, 0);
v_g0_4_ = lean_ctor_get(v_B_1_, 1);
v_g1_5_ = lean_ctor_get(v_B_1_, 2);
v_q_6_ = lean_ctor_get(v_toHostAx_3_, 0);
v_d_7_ = lean_ctor_get(v_toHostAx_3_, 1);
v_QS_8_ = lean_ctor_get(v_toHostAx_3_, 2);
v___x_9_ = lean_nat_mul(v_QS_8_, v_q_6_);
v___x_10_ = lean_nat_mul(v___x_9_, v_d_7_);
lean_dec(v___x_9_);
v___x_11_ = lean_nat_mul(v_g0_4_, v_g1_5_);
v___x_12_ = lean_unsigned_to_nat(2u);
v___x_13_ = lean_nat_pow(v___x_11_, v___x_12_);
lean_dec(v___x_11_);
v___x_14_ = lean_nat_mul(v___x_10_, v___x_13_);
lean_dec(v___x_13_);
lean_dec(v___x_10_);
return v___x_14_;
}
}
LEAN_EXPORT lean_object* lp_tree_Formalism_MainNotions_Inhab_Base_MT___redArg___boxed(lean_object* v_B_15_){
_start:
{
lean_object* v_res_16_; 
v_res_16_ = lp_tree_Formalism_MainNotions_Inhab_Base_MT___redArg(v_B_15_);
lean_dec_ref(v_B_15_);
return v_res_16_;
}
}
LEAN_EXPORT lean_object* lp_tree_Formalism_MainNotions_Inhab_Base_MT(lean_object* v_R_17_, lean_object* v_x_18_, lean_object* v_eps_19_, lean_object* v_Cp_20_, lean_object* v_CT_21_, lean_object* v_B_22_){
_start:
{
lean_object* v___x_23_; 
v___x_23_ = lp_tree_Formalism_MainNotions_Inhab_Base_MT___redArg(v_B_22_);
return v___x_23_;
}
}
LEAN_EXPORT lean_object* lp_tree_Formalism_MainNotions_Inhab_Base_MT___boxed(lean_object* v_R_24_, lean_object* v_x_25_, lean_object* v_eps_26_, lean_object* v_Cp_27_, lean_object* v_CT_28_, lean_object* v_B_29_){
_start:
{
lean_object* v_res_30_; 
v_res_30_ = lp_tree_Formalism_MainNotions_Inhab_Base_MT(v_R_24_, v_x_25_, v_eps_26_, v_Cp_27_, v_CT_28_, v_B_29_);
lean_dec_ref(v_B_29_);
lean_dec(v_CT_28_);
lean_dec(v_Cp_27_);
lean_dec(v_eps_26_);
lean_dec(v_x_25_);
lean_dec_ref(v_R_24_);
return v_res_30_;
}
}
lean_object* initialize_Init(uint8_t builtin);
lean_object* initialize_Init(uint8_t builtin);
lean_object* initialize_tree_Formalism_SharpRestriction_InertJacobiLevels_TwoPrimeFieldMemLevelOfCoprime(uint8_t builtin);
static bool _G_initialized = false;
LEAN_EXPORT lean_object* initialize_tree_Formalism_SharpRestriction_InertJacobiLevels_TwoPrimeFieldSatisfiesConditions(uint8_t builtin) {
lean_object * res;
if (_G_initialized) return lean_io_result_mk_ok(lean_box(0));
_G_initialized = true;
res = initialize_Init(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_Init(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_Formalism_SharpRestriction_InertJacobiLevels_TwoPrimeFieldMemLevelOfCoprime(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
return lean_io_result_mk_ok(lean_box(0));
}
#ifdef __cplusplus
}
#endif
